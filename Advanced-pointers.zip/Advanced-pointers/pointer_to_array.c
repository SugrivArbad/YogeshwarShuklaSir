int printf(const char*, ...);

typedef int (*arr)[5];

void main(void)
{
	int n=7;
	int A[5] = {1,2,3,4,5};

	int *pi;
	int (*p)[5];
	//int (*p)[5] = &A;

	pi = &n;
	p = &A;

	printf("\n A = %llu \n &A = %llu \n", (unsigned long long)A, (unsigned long long)&A);

	printf("\n pi = %llu \n", (unsigned long long)pi);

	for(int i=0; i<5; i++)
	{
		(*p)[i] = (i+1)*10;
		printf("\n (*p)[%d] = %d", i, (*p)[i]);
	}

	printf("\n\n");

	return;
}
