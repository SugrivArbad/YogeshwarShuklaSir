#include<stdlib.h>
int printf(const char*, ...);

void main()
{
	int n=5;
	int *p = (unsigned long long)NULL;

	printf("\n Before Malloc : \n \t p = %lld \n", (unsigned long long)p);

	p = (int *)malloc(sizeof(int));
	*p = 4;
	printf("\n After Malloc and before free : \n \t p = %lld && *p = %d \n", (unsigned long long)p, *p);

	free(p);
	printf("\n After free and before NULL : \n \t p = %lld && *p = %d \n", (unsigned long long)p, *p);

	p=NULL;
	printf("\n After NULL : \n \t p = %lld \n", (unsigned long long)p);

	printf("\n\n");
}
