#include <stdio.h>

int main(void)
{
	int n = 0123;
	int i;
	printf(" %d = %o \n\n", n, n);
	for (i=0; i<4; i++)
		printf("byte %d: %hhd = %hho \n", i+1, *(unsigned char*)((char*)&n+i), *(unsigned char*)((char*)&n+i));
	return 0;
}
