#include <stdio.h>
#include <stdlib.h>

struct A1
{
	char a;
	int b;
	float c;
};

struct A2
{
	char a;
	int b;
	float c;
};

void show_A1(int*);
void show_A2(float*);

int main(void)
{
	struct A1* pA1 = (struct A1*)malloc(sizeof(struct A1));
	struct A2* pA2 = (struct A2*)malloc(sizeof(struct A2));

	pA1->a = 'A';
	pA1->b = 100;
	pA1->c = 3.14f;

	pA2->a = 'Z';
	pA2->b = 200;
	pA2->c = 6.28f;

	printf(" Size of A1: %lu\n", sizeof(struct A1));
	printf(" Size of A2: %lu\n", sizeof(struct A2));
	printf(" Size of A2: %lu\n", sizeof(float));

	show_A1(&pA1->b);
	show_A2(&pA2->c);

	return 0;
}

void show_A1(int* pi)
{
	puts("show_A1():");
	printf(" &A1->a = %llu,\t A1->a = %c \n",
			(unsigned long long int)((char*)pi-4),
			*((char*)pi-4));
	printf(" &A1->b = %llu,\t A1->b = %d \n",
			(unsigned long long int)pi,
			*pi);
	printf(" &A1->c = %llu,\t A1->c = %.2f \n",
			(unsigned long long int)(pi+1),
			*((float*)(pi+1)));
	return;
}

void show_A2(float* pf)
{
	puts("show_A2():");
	printf(" &A2->a = %llu,\t A2->a = %c \n",
			(unsigned long long int)(pf-2),
			*((char*)(pf-2)));
	printf(" &A2->b = %llu,\t A2->b = %d \n",
			(unsigned long long int)(pf-1),
			*(int*)(pf-1));
	printf(" &A2->c = %llu,\t A2->c = %.2f \n",
			(unsigned long long int)pf,
			*pf);
	return;
}
