#include <stdio.h> 
#include <stdlib.h> 

int n; 

int main(void) 
{
	printf("Enter an integer:"); 
	scanf("%d", &n); 
	printf("n = %d\n", n); 
	exit(0); 
}

// addl	src, dest # dest <- dest + src 
