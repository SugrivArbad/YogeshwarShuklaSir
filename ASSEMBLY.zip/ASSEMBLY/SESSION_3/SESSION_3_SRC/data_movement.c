#include <stdlib.h> 

char c; 
unsigned char b; 
short s; 
unsigned short us; 
int n; 
unsigned int un; 
long lng; 
unsigned long u_lng; 

int main(void) 
{
	c = 'A'; 
	b = 100; 
	s = 1000; 
	us = 10000; 
	n = -34534532; 
	un = 2564754; 
	lng = -3465253; 
	u_lng = 36235; 
	exit(0); 
}
