#include <stdio.h> 
#include <stdlib.h> 

int n = 100; 

int main(void) 
{
	printf("n = %d\n", n); 
	exit(0); 
}

/* 	
 *	How to make a function call in assembly 
 *	Step 1: Push all actual parameters from 
 *			right to left on stack! 
 *	Step 2: Call function using call instruction 
 *			and the name of the function as 
 *			operand 
 *	Step 3: Add 4 * number of actual parameters 
 *			to stack pointer 
 *	Step 4: Copy return value from eax register 
 *	---------------------------------------------
 *	ret = function_name(P1, P2, P3, ..., Pn); 
 *		
 *		pushl	Pn 
 *		pushl	Pn-1 
 *		pushl	Pn-2 
 *		.
 *		.
 *		.
 *		.
 *		pushl	P1
 *		call	function_name 
 *		addl	$4*n, %esp 
 *		movl	%eax, ret 
 */ 
 *
