char c1 = 'A';
unsigned char b1 = 30;
short s1 = 30;
unsigned short u_s1 = 234;
int n1 = -45345;
unsigned int n2 = 35475345;
long n_lng = 343545;
unsigned long un_lng = 3784343545;

int main(void)
{
	exit(0);
}
