
class Point3d
{
	private:
		float x, y, z;

	public:
		void initializePoint3d(float _x, float _y, float _z)
		{
			this->x = _x; 
			this->y = _x; 
			this->x = _x; 
		}

		float get_x()
		{
			return this->x;
		}

		float get_y()
		{
			return this->y;
		}

		float get_z()
		{
			return this->z;
		}

		void set_x(float newx)
		{
			this->x = newx;
		}

		void set_y(float newy)
		{
			this->y = newy;
		}

		void set_z(float newz)
		{
			this->z = newz;
		}
};

void main()
{
	Point3d inP;
	inP.initializePoint3d(2.1f, 3.5f, 5.7f);
	float xx = inP.get_x();
	float yy = inP.get_y();
	float xx = inP.get_z();
}
