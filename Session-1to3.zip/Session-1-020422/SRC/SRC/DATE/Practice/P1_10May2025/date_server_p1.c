#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "Date.h"

struct date* create_date()
{
	struct date* p_date = (struct date*)calloc(1, sizeof(stuct date));
	assert(p_date != NULL);
	return (p_date);
}

void init_date(struct date* p_date, int dd, int mm, int yy)
{
	assert(validate_date());
	p_date->day = dd;
	p_date->month = mm;
	p_date->year = yy;
}

int get_day(struct date* p_date)
{
	return (p_date->day);
}

