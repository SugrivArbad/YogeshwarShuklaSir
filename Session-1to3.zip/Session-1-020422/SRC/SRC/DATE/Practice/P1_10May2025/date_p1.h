#ifndef _DATE_H
#define _DATE_H

#define TRUE	1
#define FALSE	0

struct date
{
	int day;
	int month;
	int year;
};

struct date* create_date();

void init_date(struct date* p_date, int dd, int mm, int yy);

int get_day(struct date* p_date);



