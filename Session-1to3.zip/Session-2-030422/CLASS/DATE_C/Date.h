#pragma once 

struct Date
{
    int day; 
    int month; 
    int year; 
}; 

