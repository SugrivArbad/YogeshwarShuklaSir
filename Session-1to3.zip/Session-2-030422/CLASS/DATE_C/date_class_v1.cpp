#include <stdio.h> 
#include <stdlib.h> 

class Date
{
    private: 
        int day; 
        int month; 
        int year; 

    public: 
        void initialize_date(int _day, int _month, int _year)
        {
            this->day = _day; 
            this->month = _month; 
            this->year = _year;
        }

        int get_day()
        {
            return this->day; 
        }

        int get_month()
        {
            return this->month; 
        }   

        int get_year()
        {
            return this->year; 
        }
}; 

int main()
{
    Date D; 
    int dd, mm, yy; 
    
    D.initialize_date(1, 5, 2021); 
    dd = D.get_day(); 
    mm = D.get_month(); 
    yy = D.get_year(); 

    return (0); 
}
