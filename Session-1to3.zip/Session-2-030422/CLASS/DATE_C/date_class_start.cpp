#include <stdio.h> 

/* 
    struct Date
    {
        int day; 
        int month; 
        int year; 
    }; 
*/ 
class Date
{
    private: 
        int day; 
        int month; 
        int year; 
}; 

int main(void)
{
    Date my_date;
    
    my_date.day = 10; 
    my_date.month = 2; 
    my_date.year = 2020; 

    return (0); 
}