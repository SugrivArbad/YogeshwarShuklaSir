#include <stdio.h> 
#include <stdlib.h> 
#include "Date.h"

int main(void)
{
    struct Date d; 
    struct Date* p = NULL; 

    p = (struct Date*)malloc(sizeof(struct Date)); 

    /* The struct mechanims in C programmin language 
        does not have ability to PREVENT following 
        access! And therefore, coupling between the client 
        and particular version of data layout of type 
        is ALWAYS A POSSIBILITY 
    */ 
    d.day; 
    d.month; 
    d.year; 

    p->day; 
    p->month; 
    p->year; 
}