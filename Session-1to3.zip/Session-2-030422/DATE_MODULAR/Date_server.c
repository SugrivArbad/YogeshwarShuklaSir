#include <stdio.h> 
#include <stdlib.h> 

#include "Date.h"

Date_t* create_date(int init_day, int init_month, int init_year)
{
    Date_t* p_new_date = NULL; 
    int ret; 

    ret = is_date_valid(init_day, init_month, init_year); 
    if(ret == FALSE)
    {
        return (NULL); 
    }

    p_new_date = (Date_t*)malloc(sizeof(Date_t)); 
    if(p_new_date == NULL)
    {
        fprintf(stderr, "Memory allocation failed\n"); 
        exit(EXIT_FAILURE); 
    }

    p_new_date->day = init_day; 
    p_new_date->month = init_month; 
    p_new_date->year = init_year; 

    return (p_new_date); 
}

int get_day(Date_t* p_date)
{
    return (p_date->day); 
}

int get_month(Date_t* p_date)
{
    return (p_date->month); 
}

int get_year(Date_t* p_date)
{
    return (p_date->year); 
}

int set_day(Date_t* p_date, int new_day)
{
    if(!is_date_valid(new_day, p_date->month, p_date->year))
        return (INVALID_DATE); 
    p_date->day = new_day; 
    return (SUCCESS); 
}

int set_month(Date_t* p_date, int new_month)
{
    if(!is_date_valid(p_date->day, new_month, p_date->year))
        return (INVALID_DATE); 
    p_date->month = new_month; 
    return (SUCCESS); 
}

int set_year(Date_t* p_date, int new_year)
{
    if(!is_date_valid(p_date->day, p_date->month, new_year))
        return (INVALID_DATE); 
    p_date->year = new_year; 
    return (SUCCESS); 
}

void destroy_date(Date_t** pp_date)
{
    Date_t* p_date = *pp_date; 
    free(p_date); 
    p_date = 0; 
    *pp_date = NULL; 
}

static int is_date_valid(int day, int month, int year)
{
    int is_leap; 
    is_leap = is_year_leap(year); 
    
    return (
            (day >= 1) && 
            (month == 2 && ((is_leap && day <= 29) || (!is_leap && day <= 28))) 
            || 
            (
                (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || 
                month == 10 || month == 12) && day <= 31
            ) 
            || 
            ((month == 4 || month == 6 || month == 9 || month == 11) && (day <= 30))
    ); 
}

static int is_year_leap(int year)
{
    return !((year % 4) != 0 || ((year % 100) == 0 && (year % 400) != 0));  
}
