#pragma once 

#include <stdio.h> 
#include <stdlib.h> 

#define SUCCESS         1 
#define TRUE            1 
#define FALSE           0 
#define INVALID_DATE    2 

typedef struct Date Date_t; 

struct Date 
{
    int day; 
    int month; 
    int year; 
}; 

Date_t* create_date(int init_day, int init_month, int init_year); 
int get_day(Date_t* p_date); 
int get_month(Date_t* p_date); 
int get_year(Date_t* p_date); 
int set_day(Date_t* p_date, int new_day); 
int set_month(Date_t* p_date, int new_month); 
int set_year(Date_t* p_date, int new_year); 
void destroy_date(Date_t** pp_date); 

static int is_date_valid(int day, int month, int year); 
static int is_year_leap(int year); 
