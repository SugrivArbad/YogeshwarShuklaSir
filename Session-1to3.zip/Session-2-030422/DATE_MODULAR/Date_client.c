#include <stdio.h> 
#include <stdlib.h> 
#include <assert.h>
#include "Date.h"

int main(void)
{
    int dd, mm, yy; 
    int ret; 
    Date_t* p_cpa_birth_date = NULL; 
    Date_t* p_test_date = NULL; 
    
    p_cpa_birth_date = create_date(1, 12, 2009); 
    dd = get_day(p_cpa_birth_date); 
    mm = get_month(p_cpa_birth_date); 
    yy = get_year(p_cpa_birth_date); 
    printf("CPA birthday:%d-%d-%d\n", dd, mm, yy); 

    destroy_date(&p_cpa_birth_date); 
    puts("----------------------------------------------"); 
    p_test_date = create_date(43, 145, 2000); 
    if(p_test_date == NULL)
        fprintf(stderr, "Date data sent to create_date() is invalid\n"); 
    p_test_date = create_date(18, 3, 2020); 
    dd = get_day(p_test_date); 
    mm = get_month(p_test_date); 
    yy = get_year(p_test_date); 
    printf("Test Date:%d-%d-%d\n", dd, mm, yy); 

    ret = set_day(p_test_date, 35); 
    if(ret == INVALID_DATE)
        fprintf(stderr, "Day of the month field is invalid\n"); 

    ret = set_month(p_test_date, 56); 
    if(ret == INVALID_DATE)
        fprintf(stderr, "Month data is invalid\n"); 

    ret = set_month(p_test_date, 2); 
    assert(ret == SUCCESS);

    ret = set_day(p_test_date, 29); 
    assert(ret == SUCCESS); 

    dd = get_day(p_test_date); 
    mm = get_month(p_test_date); 
    yy = get_year(p_test_date); 
    printf("Test Date:%d-%d-%d\n", dd, mm, yy);

    ret = set_year(p_test_date, 2021); 
    if(ret == INVALID_DATE)
        fprintf(stderr, "2021 - Year is not leap!\n"); 

    /* 
        TODO Exercise 
        Put date 31 for any month with 30 days 
        and check whether the return value is expected 0
    */ 

    destroy_date(&p_test_date); 
    exit(0); 
}