#include <stdio.h>
#include <stdlib.h>

struct node
{
	int data;
	struct node *prev;
	struct node *next;
}

int main(void)
{
	struct node *head = NULL, *temp = NULL;
	p_list = (struct node *)malloc(sizeof(struct node));

	for(int i = 0; i < 4; ++i)
}
