#include <stdio.h> 
#include <stdlib.h> 
#include <ctype.h> 

int main (void) 
{
	char c; 

	printf ("Enter char:"); 
	scanf ("%c", &c); 

	if (isalpha (c))
	{
		printf ("%c is a character\n", c); 
	}
	else if (isdigit (c)) 
	{
		printf ("%c is a digit\n", c); 
	}

	return (0); 
}
