#include <stdio.h> 
#include <stdlib.h> 

int main (void) 
{
	int i; 

	for (i=0; i < 256; i++) 
	{
		printf ("ASCII[%d]:%c\n", i, (char)i); 
	}	

	return (0); 
}
