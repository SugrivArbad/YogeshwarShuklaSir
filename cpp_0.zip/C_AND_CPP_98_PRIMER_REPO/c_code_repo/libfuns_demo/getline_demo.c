#include <stdio.h> 
#include <stdlib.h> 

int main (void) 
{
	char *s; 
	size_t len = 0; 
	ssize_t n; 

	n = getline (&s, &len, stdin); 
	printf ("%s:s\n", s); 

	return (EXIT_SUCCESS); 
}
