#include <stdio.h> 
#include <stdlib.h> 


int main (void) 
{
	#ifdef X
	printf ("X is defined\n") 
	#endif 	

	return (EXIT_SUCCESS); 
}
