#include <stdio.h> 
#include <stdlib.h> 

int main (void) 
{
	#ifdef __LINUX__
	printf ("LINUX MACHINE\n"); 
	#endif 

	#ifdef __WIN__
	printf ("WINDOWS MACHINE\n"); 
	#endif 
	
	#ifdef __MACOSX__
	printf ("MAC MACHINE\n"); 
	#endif 

	exit (EXIT_SUCCESS); 
	
}
