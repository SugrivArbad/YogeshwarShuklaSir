#include <stdio.h> 
#include <stdlib.h> 

#define ADD(n1,n2) ((n1) + (n2))
#define MAX(n1,n2)  ((n1) < (n2) ? (n2) : (n1))

int main (void) 
{
	int num1=10, num2=20; 
	float f_num1=3.14, f_num2=6.28; 
	
	printf ("Addition:%d\n", ADD(num1, num2)); 
	printf ("Addition:%f\n", ADD(f_num1, f_num2)); 
	printf ("Max:%d\n", MAX(num1, num2)); 
	printf ("Max:%f\n", MAX(f_num1, f_num2)); 

	return (EXIT_SUCCESS); 
}
