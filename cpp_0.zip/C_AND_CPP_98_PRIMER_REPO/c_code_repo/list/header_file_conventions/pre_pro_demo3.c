#include <stdio.h> 
#include <stdlib.h> 

#define X

int main (void) 
{
	#ifdef X
	printf ("X is defined\n") 
	#endif 	

	return (EXIT_SUCCESS); 
}
