/* #define SYMBOL TEXT */ 

#include <stdio.h> 
#include <stdlib.h> 

#define N 10 


int main (void) 
{
	for (i=0; i < N; i++) 
	{
		printf ("i=%d\n", i); 
	}

	exit (EXIT_SUCCESS); 
}
