#ifndef _MY_HEADER_H 
#define _MY_HEADER_H 

/* Write your declarions */ 

#endif 
