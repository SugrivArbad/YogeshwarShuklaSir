#ifndef _LIST_H 
#define _LIST_H 

struct node; 
typedef struct node node_t
typedef node_t list_t; 
typedef int data_t; 
typedef int result_t; 

struct node 
{
	data_t data; 
	node_t *prev, *next; 
}; 

/* interface functions */ 

list_t *create_list (void); 

/* interface - insertion routines */ 
result_t insert_beg (list_t *lst, data_t new_data); 
result_t insert_end (list_t *lst, data_t new_data); 
result_t insert_after_data (list_t *lst, data_t e_data, data_t new_data); 
result_t insert_before_data (list_t *lst, data_t e_data, data_t new_data);

/* interface - deletion routines */ 

result_t del_beg (list_t *lst); 
result_t del_end (list_t *lst); 
result_t del_data (list_t *lst, data_t e_data); 

/* interface - misc */ 

result_t is_empty (list_t *lst); 
result_t search_list (list_t *lst, data_t e_data); 
void display (list_t *lst); 


/* auxillary function */ 
void *xcalloc (int nr_elements, int size_per_element); 


#endif /* _LIST_H */ 
