#include <stdio.h> 
#include <stdlib.h> 
#include <ctype.h> 
#include <string.h> 

#define MAX_VAR_LENGTH	256
#define TRUE		1 
#define	FALSE		0  

char var_name[MAX_VAR_LENGTH]; 

int main (void) 
{
	int i, len; 
	int flag=FALSE; 
	
	/* Use getline function */ 

	printf ("Enter a identifier name:"); 
	scanf ("%s", var_name); 

	len = strlen (var_name); 

	if (var_name[0] == '_' || isalpha (var_name[0]))
	{
		flag = TRUE; 

		for (i=1; i < len; i++) 
		{
			if (isalpha (var_name[i]) || isdigit (var_name[i]) || 
		    	    var_name[i] == '_')
			{
				continue; 
			}
			else
			{
				flag = FALSE; 
				break; 
			}
			/* if-else statement can be replaced by following
			 * if (!isalpha (var_name[i]) && !isdigit (var_name[i])
			 *     && var_name[i] != '_')
			 *     {
			 *     		flag = FALSE; 
			 *     		break; 
			 *     } 
			 */      
		}
	} 

	if (flag) 
	{
		printf ("%s is a valid identifier\n", var_name); 
	}
	else
	{
		printf ("%s is not a valid identifier\n", var_name); 
	}
	/* if-else can be replaced by ternary operator 
	 * flag ? printf () : printf (); 
	 */ 


	return (EXIT_SUCCESS); 
}
