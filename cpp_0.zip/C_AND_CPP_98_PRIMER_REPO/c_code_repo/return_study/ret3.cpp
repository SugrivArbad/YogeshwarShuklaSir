#include <iostream> 
#include <cstdlib> 
#include <cstring> 
#include <ctime> 

#define CAP 10000

typedef struct Input
{
	int iArr[5]; 
	double dArr[5]; 
}INPUT; 

typedef struct Output
{
	int iSum; 
	double dSum; 
}OUTPUT; 

/* Option 1 */ 
OUTPUT *CalculateSum(INPUT *pI); 
/* Option 2 */ 
bool CalculateSum(INPUT *pI, OUTPUT *pO); 

bool get_random_integer(int *piRandom); 
bool get_random_double(double *pdRandom); 

int main(void) 
{
	INPUT *pI = NULL; 
	OUTPUT *pO = NULL, *pO1 = new OUTPUT; 
	
	memset(pO1, 0, sizeof(OUTPUT)); 

	pI = new INPUT;  
	memset(pI, 0, sizeof(INPUT)); 

	for(int i = 0; i < 5; ++i)
	{
		if(get_random_integer(&pI->iArr[i]) && 
			get_random_double(&pI->dArr[i]))
			continue; 
		else
			exit(EXIT_FAILURE); 
	}
	
	for(int i = 0; i < 5; ++i)
		std::cout << "pI->iArr[" << i << "]:" << pI->iArr[i] 
				<< std::endl << "pI->dArr[" << i << "]:" << 
				pI->dArr[i] << std::endl; 

	pO = CalculateSum(pI); 
	std::cout << "pO->iSum:" << pO->iSum << std::endl
			<< "pO->dSum:" << pO->dSum << std::endl; 

	if(CalculateSum(pI, pO1))
	{
		std::cout << "pO1->iSum:" << pO1->iSum << std::endl 
				<< "pO1->dSum:" << pO1->dSum << std::endl; 
		delete pO1; 
		pO1 = NULL; 
	}
	
	delete pI; 
	pI = NULL; 
	delete pO; 
	pO = NULL; 

	return EXIT_SUCCESS; 
}

OUTPUT *CalculateSum(INPUT *pI) 
{
	OUTPUT *pO = new OUTPUT; 
	memset(pO, 0, sizeof(OUTPUT)); 
	
	for(int i = 0; i < 5; ++i)
	{
		pO->iSum += pI->iArr[i]; 
		pO->dSum += pI->dArr[i]; 
	}

	return pO; 
}

bool CalculateSum(INPUT *pI, OUTPUT *pO)
{
	memset(pO, 0, sizeof(OUTPUT)); 
	for(int i = 0; i < 5; ++i)
	{
		pO->iSum += pI->iArr[i]; 
		pO->dSum += pI->dArr[i]; 
	}

	return true; 
}

bool get_random_integer(int *piRandom) 
{
	static bool bFirstTime = true; 
	if(bFirstTime)
	{
		bFirstTime = false; 
		srand(time(0)); 
	}

	*piRandom = rand() % CAP; 

	return true; 
}

bool get_random_double(double *pdRandom) 
{
	static bool bFirstTime = true; 
	if(bFirstTime)
	{
		bFirstTime = false; 
		srand(time(0)); 
	}

	*pdRandom = static_cast<double>(rand() % CAP)/ 100.0; 

	return true; 
}
