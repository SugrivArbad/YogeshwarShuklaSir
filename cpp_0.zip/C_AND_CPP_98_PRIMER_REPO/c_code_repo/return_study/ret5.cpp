#include <iostream> 
#include <cstdio> 
#include <cstdlib> 
#include <cstring> 
#include <ctime> 

#include <errno.h> 
#include <pthread.h> 

#define CAP 10000

/* P1 : Write a function to accept any structure and print it */ 
/* P2 : Write a function which accepts address of ANY structure 
 * pointer variable and treats it as a parameterized return 
 * value */ 

/* Thread creation API: 
 * pthread_create(pthread_t *pth, pthread_attr_t *pattr, 
 * 					void*(*)(void*), void *args); 
 *
 * Synchronization of parent and child thread 
 * pthread_join(pthread_t th, void **args); 
 * */
struct input{int iarr[5]; double darr[5];};  
struct output{int sum; double dsum;}; 

void *ThreadEntry(void *); 

int main(void) 
{
	pthread_t th1;

	srand(time(0)); 
		
	struct input *pinput = (struct input*)malloc(sizeof(struct input)); 
	memset(pinput, 0, sizeof(struct input)); 
	for(int i = 0; i < 5; ++i) 
	{
		pinput->iarr[i] = rand() % CAP; 
		pinput->darr[i] = static_cast<double>(rand () % CAP) / 100.0;  
	}

	for(int i = 0; i < 5; ++i)
		std::cout << "pinput->_arr[" << i << "]:" << pinput->iarr[i] 
				<< std::endl; 
	
	for(int i = 0; i < 5; ++i)
		std::cout << "pinput->darr[" << i << "]:" << pinput->darr[i] 
				<< std::endl; 

	pthread_create(&th1, NULL, ThreadEntry, pinput); 

	struct output *poutput = NULL; 
	pthread_join(th1, (void**)(&poutput)); 
	
	std::cout << "poutput->sum:" << poutput->sum << std::endl
			<< "poutput->dsum:" << poutput->dsum << std::endl; 

	free(pinput); 
	pinput = NULL; 
	free(poutput); 
	poutput = NULL; 

	exit(EXIT_SUCCESS); 
}

void *ThreadEntry(void *args) 
{
	struct input *p = (struct input*)args; 
	struct output *po = (struct output*)malloc(sizeof(struct output)); 
	memset(po, 0, sizeof(struct output)); 

	for(int i = 0; i < 5; ++i){ 
		po->sum += p->iarr[i];  
		po->dsum += p->darr[i]; 	
	}

	return (po); 
}
