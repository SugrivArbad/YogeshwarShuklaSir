#include <iostream> 
#include <cstdlib> 
#include <ctime> 

unsigned long get_random_number(void); 

int main(void) 
{
	for(int i = 0; i < 10; ++i)
		std::cout << "Random number:" << i << ":" 
				<< get_random_number() << std::endl; 

	return 0; 
}

unsigned long int get_random_number(void) 
{
	static bool first_time = true; 
	if(first_time)
	{
		first_time = false; 
		srand(time(0)); 
	}

	return rand(); 
}

