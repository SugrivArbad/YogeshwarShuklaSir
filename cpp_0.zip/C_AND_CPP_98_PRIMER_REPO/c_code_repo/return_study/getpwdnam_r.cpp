#include <iostream> 
#include <stdexcept> 
#include <cstdlib> 
#include <cstring> 

#include <errno.h> 
#include <unistd.h> 
#include <fcntl.h> 
#include <pwd.h> 
#include <sys/types.h> 

int main(int argc, char *argv[]) 
{ 
	struct passwd *p_pwd=NULL, *p_result=NULL; 
	char *buffer=NULL; 
	size_t buffer_len = 1024; 
	int ret = -1; 

	if(argc != 2)
	{
		std::cerr << "usage:" << argv[0] << ":pathname" << std::endl; 
		exit(EXIT_FAILURE); 
	}

	buffer = new char[buffer_len]; 
	if(!buffer)
		throw std::bad_alloc(); 

	memset(buffer, 0, buffer_len); 

	p_pwd = new struct passwd; 
	if(!p_pwd)
		throw std::bad_alloc(); 

	std::cout << "p_pwd:" << std::hex << p_pwd << std::endl; 
	
	ret = getpwnam_r(argv[1], p_pwd, buffer, buffer_len, &p_result); 
	if(ret == -1) 
		throw std::runtime_error("getpwnam_r failed"); 
	
	std::cout 	<< "p_pwd:" << std::hex << p_pwd << std::endl
				<< "p_result:" << std::hex << p_result << std::endl; 

	if(!p_pwd && !p_result)
	{
		std::cerr << "No address" << std::endl; 
		exit(EXIT_FAILURE); 
	}
	
	std::cout   << "NAME:" << p_pwd->pw_name << std::endl
				<< "UID:" << p_pwd->pw_uid << std::endl
				<< "GID:" << p_pwd->pw_gid << std::endl
				<< "GECOS:" << p_pwd->pw_gecos << std::endl
			   	<< "HOME:" << p_pwd->pw_dir << std::endl
				<< "SHELL:" << p_pwd->pw_shell << std::endl;

	std::cout << "Printing string fields only" << std::endl; 
	for(char *p = buffer; *p != '\0'; p += strlen(p) + 1)
		std::cout << "Next string field:" << p << std::endl; 

	if(p_pwd == p_result)
		std::cout << "YES" << std::endl; 

	delete[] buffer; 
	delete p_pwd; 	

	buffer = NULL; 
	p_pwd = NULL; 

	exit(EXIT_SUCCESS);  
}


