#include <iostream> 
#include <cstdlib> 
#include <ctime> 

bool get_random_number(unsigned long *pRandom); 

int main(void) 
{
	unsigned long ulRandom; 

	for(int i = 0; i < 10; ++i)
		if(get_random_number(&ulRandom))
			std::cout << "Random number:" << i 
						<< ":" << ulRandom << std::endl; 
		else
			exit(EXIT_FAILURE); 

	exit(EXIT_SUCCESS); 

}

bool get_random_number(unsigned long *pRandom)
{
	static bool bFirstTime = true; 
	
	if(bFirstTime) 
	{
		bFirstTime = false; 
		srand(time(0)); 
	}
	
	*pRandom = rand(); 
	
	return (true); 
}
