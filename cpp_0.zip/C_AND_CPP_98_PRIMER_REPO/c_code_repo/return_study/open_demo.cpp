#include <iostream> 
#include <cstdlib> 
#include <cstring> 

#include <errno.h> 
#include <unistd.h> 
#include <fcntl.h> 
#include <sys/types.h> 

int main(int argc, char *argv[]) 
{
	int fd; 
	char *pathname; 
	if(argc != 2) 
	{
		std::cerr << "Usage:" << argv[0] << " pathname" << std::endl;
		exit(EXIT_FAILURE); 
	}
	
	pathname = argv[1]; 

	fd = open(argv[1], O_RDWR); 
	if(fd == -1)
	{
		std::cerr 	<< "open:" << pathname << ":" 
					<< strerror(errno) << std::endl; 
		exit(EXIT_FAILURE); 
	}

	if(close(fd) == -1)
	{
		std::cerr 	<< "close:" << pathname << ":" 
					<< strerror(errno) << std::endl; 
		exit(EXIT_FAILURE); 

	}
	
	exit(EXIT_SUCCESS); 
}
