#include <iostream> 
#include <cstdlib> 

void f1(void *args); 
void f2(void *args); 
void f3(void *args); 

struct A{
	int i_num; 
	char c_ans; 
	double d_num; 
}; 

struct B{
	int arr[2]; 
	short int s1, s2; 
	double darr[2]; 
}; 

struct C{
	char *pc; 
	int *pi; 
}; 

int main(void)
{
	struct A *ptr = (struct A*)malloc(sizeof(struct A)); 
	memset(ptr, 0, sizeof(struct A)); 
	ptr->i_num = 10; 
	ptr->c_ans = 'A'; 
	ptr->d_num = 3.14; 

	struct B *pB = (struct B*)malloc(sizeof(struct B)); 
	memset(pB, 0, sizeof(struct B)); 
	pB->arr[0] = 100; 
	pB->arr[1] = 200; 
	pB->s1 = 300; 
	pB->s2 = 400; 
	pB->darr[0] = 1.23; 
	pB->darr[1] = 2.34; 

	struct C *pC = (struct C*)malloc(sizeof(struct C)); 
	memset(pC, 0, sizeof(struct PC)); 
	pC->pc = (char*)malloc(32); 
	pC->pi = (int*)malloc(sizeof(int)); 
	memset(pC->pc, 0, 32); 
	memset(pC->pi, 0, sizeof(int)); 

	strncpy(pC->pc, "Hello,World", strlen("Hello,World")); 
	*(pC->pi) = 100; 

	f1(ptr); 
	f2(pB); 
	f3(pC); 
}

void f1(void *args)
{	
	struct A *p = (struct A*)args; 
	// Use instance of struct through p 
}

void f2(void *args)
{
	struct B *p = (struct B*)args;
	// Use instance of struct through p 
}

void f3(void *args)
{
	struct C *p = (struct C*)args; 
	// use instance of struct through p 
}


