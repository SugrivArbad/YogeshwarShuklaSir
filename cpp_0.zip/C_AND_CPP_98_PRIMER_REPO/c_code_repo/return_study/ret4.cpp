#include <iostream> 
#include <cstdlib> 
#include <cstring> 
#include <ctime> 

#define CAP 10000

struct Test
{
	int iNum; 
	char cAns; 
	double dNum; 
};

bool TestFun(struct Test **ppTest); 

int main(void) 
{
	struct Test *pTest = NULL; 

	TestFun(&pTest); 

	if(pTest)
		std::cout << "pTest->iNum:" << pTest->iNum << std::endl
					<< "pTest->cAns:" << pTest->cAns << std::endl 
					<< "pTest->dNum:" << pTest->dNum << std::endl; 

	delete pTest; 
	pTest = NULL; 

	return EXIT_SUCCESS; 
}

bool TestFun(struct Test **ppTest) 
{
	srand(time(0)); 	
	*ppTest = new struct Test; 
	memset(*ppTest, 0, sizeof(struct Test)); 
	(*ppTest)->iNum = rand() % CAP; 
	(*ppTest)->cAns = 65 + (rand() % 26); 
	(*ppTest)->dNum = static_cast<double>(rand() % CAP) / 100.0; 
	
	return (true); 
}
