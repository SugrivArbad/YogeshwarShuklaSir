int main()
{
	10;
}
