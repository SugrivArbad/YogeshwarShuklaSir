#include <stdio.h>

int main()
{
	int i = 10;
	int j = 20;
	
	char a = 'a';
	char b = 'b';

	float f1 = 3.14;
	float f2 = 6.28;

	printf("Addition of integers : %d + %d = %d\n", i, j, i + j);

	printf("Addition of characters : %c + %c = %c or  %d\n", a, b, a+b, a+b);
	
	printf("Addition of floats : %f + %f = %f\n", f1, f2, f1 + f2);
	
	printf("Addition of char and integer : %c + %d = %c or %d\n", a, i, a + i, a + i);
	
	printf("Addition of integer and character : %d + %c = %c or %d\n", i, a, i + a, i + a);
	
	printf("Addition of integers and float : %d + %f = %d or %f\n", i, f1, i + f1, i + f1);

	printf("Addition of float and integer : %f + %d = %d or %f\n", f1, i, f1 + i, f1 + i);

	return 0;

}
