#include <stdio.h>

int main(void)
{
	int *ptr = NULL;

	printf("sizeof(ptr) = %d\n", sizeof(ptr));
	
	return 0;
}
