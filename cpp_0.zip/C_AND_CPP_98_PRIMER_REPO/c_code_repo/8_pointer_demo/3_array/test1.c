#include <stdio.h>

int i_arr[5] = {10, 203, 94, 80, 30};

int* i_ptr[5];

int main(void)
{
	i_ptr[0] = i_arr;

	

	return 0;
}
