#include <stdio.h>

struct date
{
	int dd;
	int mm;
	int yy;
};

struct A
{
	char c;
	float f;
	double d;
};

int main(void)
{
	struct date start_date;
	struct A inA;

	start_date.dd = 10;
	start_date.mm = 12;
	start_date.yy = 2019;

	inA.c = 'A';
	inA.f = 3.14;
	inA.d = 6.28;

	printf("Sizeof struct : %d\n", sizeof(inA));

	printf("start_date.dd = %d : Address : %p\n", start_date.dd, &(start_date.dd));
	printf("start_date.mm = %d : Address : %p\n", start_date.mm, &(start_date.mm));
	printf("start_date.yy = %d : Address : %p\n", start_date.yy, &(start_date.yy));

	printf("inA.c = %c Address : %p\n", inA.c, &(inA.c));
	printf("inA.f = %f Address : %p\n", inA.f, &(inA.f));
	printf("inA.d = %lf Address : %p\n", inA.d, &(inA.d));


	return 0;
}
