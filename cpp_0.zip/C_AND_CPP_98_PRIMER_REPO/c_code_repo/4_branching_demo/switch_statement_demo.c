#include <stdio.h> 

int main (void) 
{
	char c;
	printf ("Enter vowel:"); 
	scanf ("%c", &c); 

	/* 
	 * if (c == 'a') 
	 * {
	 *
	 * }
	 * else if (c == 'e') 
	 * {
	 *
	 * }
	 * else if (c == 'i') 
	 * {
	 *
	 * }
	 * else if (c == 'o') 
	 * {
	 *
	 * }
	 * else if (c == 'u') 
	 * {
	 *
	 * }
	 * else
	 * {
	 *	printf ("character is not a vowel\n"); 
	 * } 
	 */ 

	 switch (c) 
	 {
	 	case 'a': 

			break; 
		case 'e': 

			break; 
		case 'i': 

			break; 
		case 'o': 

			break; 
		case 'u': 

			break; 
		default: 
			printf ("Character is not vowel\n"); 

	 }

	 return (0); 
}
