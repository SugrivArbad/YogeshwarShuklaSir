#include <stdio.h> 
#include <stdlib.h> 

int data_num=10; 
int bss_num; 

int main (void) 
{
	int local_num; 
	int *ptr = (int*) malloc (4); 
	
	if (!ptr) 
	{
		fprintf (stderr, "malloc:out of memory\n"); 
		exit (EXIT_FAILURE); 
	}
	
	printf ("Address of main      = %lx\n", (unsigned long)main); 
	printf ("Address of data_num  = %lx\n", (unsigned long)&data_num); 
	printf ("Address of bss_num   = %lx\n", (unsigned long)&bss_num); 
	printf ("Address in ptr       = %lx\n", (unsigned long)ptr); 
	printf ("Address of local_num = %lx\n", (unsigned long)&local_num); 
	printf ("Address of ptr       = %lx\n", (unsigned long)&ptr); 
	
	return (0); 
}
