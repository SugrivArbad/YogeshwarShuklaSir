#include <stdio.h> 
#include <stdlib.h> 

int main (void) 
{
	int n1, n2, n3, n4,rs, i, j, cnt; 

	n1 = 100; 
	n2 = 50; 
	n3 = 60; 
	n4 = 70; 

	if ((n1 > n2) && (n3 < n4)) 
	{
		rs = n1 > n2 && n3 < n4; 
		printf ("(n1 > n2 && n3 < n4) == TRUE\n"); 
		printf ("rs:%d\n", rs); 
	}

	n2 = 0; 
	n1 = 100; 
	n3 = 200; 
	n4 = 200; 

	if ((!n2 && (n1 > n2)) && !(n3 < n4)) 
	{
		rs = !n2 && (n1 > n2) && !(n3 < n4); 
		printf ("!n2 && (n1 > n2) && !(n3 < n4) == TRUE\n"); 
		printf ("rs:%d\n", rs); 
	}
	
	cnt = 0;
	for (i=0; i < 5; i++) 
	{
		cnt++; 
	}
	printf ("loop1:cnt:%d\n", cnt); 
	
	cnt = 0; 
	for (i=0; i < 24; i=i+3) 
	{
		cnt++; 
	}
	printf ("loop2:cnt:%d\n", cnt); 

	/*cnt = 0; 
	for (i=0; i < 30; i=i*3)
	{
		cnt++; 
	}
	printf ("loop3:cnt:%d\n", cnt); */ 

	cnt = 0; 
	for (i=1; i < 30; i=i*3) 
	{
		cnt++; 
	}
	printf ("loop4:cnt:%d\n", cnt);

	i=0; 
	j=1; 
	cnt=0; 
	while (i < 5 && j < 21) 
	{
		cnt++; 	
		i = i + 1; 
		j = j + 3; 
	}
	printf ("loop5:cnt:%d\n", cnt); 

	cnt=0; 
	for (i=0,j=1; i < 5 || j < 21; i++, j=j+3)
	{
		cnt++;	
	}
	printf ("loop6:cnt:%d\n", cnt); 

	return (0); 
}
