#include <stdio.h> 
#include <stdlib.h> 

int main (void) 
{
	long rs, n, cnt; 

	printf ("Enter n:"); 
	scanf ("%ld", &n); 
	
	rs = 1; 
	for (cnt=n; cnt; cnt--) 
	{
		rs = rs * cnt; 
	}

	printf ("factorial(%ld)=%ld\n", n, rs); 

	return (0); 
}
