#include <stdio.h> 
#include <stdlib.h> 

int main (void) 
{
	unsigned long rs, n, cnt; 

	printf ("Enter n:"); 
	scanf ("%lu", &n); 
	
	rs = 1; 
	for (cnt=n; cnt; cnt--) 
	{
		rs = rs * cnt; 
	}

	printf ("factorial(%lu)=%lu\n", n, rs); 

	return (0); 
}
