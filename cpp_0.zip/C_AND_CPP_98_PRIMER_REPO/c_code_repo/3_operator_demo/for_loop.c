#include <stdio.h>

int main()
{
	int a[] = {10, 20, 30, 40, 50, 60};
	int i = 0;
	for(i  = 0; i < 5;i++)
	{
		printf("i : %d & a[%d] = %d\n", i, i, a[++i]);
	}

	i = i++;

	printf("%d\n", i);

	return 0;
}
