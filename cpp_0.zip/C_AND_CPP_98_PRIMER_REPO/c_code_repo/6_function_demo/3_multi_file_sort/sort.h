#ifndef _SORT_H 
#define _SORT_H 

void sort (int [], int); 

#endif /* _SORT_H */ 
