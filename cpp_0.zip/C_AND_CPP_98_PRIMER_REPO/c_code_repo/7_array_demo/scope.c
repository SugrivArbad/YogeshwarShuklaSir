#include <stdio.h>
#include <stdlib.h>

int i = 10;

void main(void)
{
	int i = 30;

	if(1)
	{
		i = 40;
		printf("Inside if : i = %d\n", i);
	}

	printf("Outside if : i = %d\n", i);
	
	exit(0);
}
