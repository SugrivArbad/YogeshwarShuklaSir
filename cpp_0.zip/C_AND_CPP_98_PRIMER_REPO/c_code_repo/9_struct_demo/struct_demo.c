#include <stdio.h> 
#include <stdlib.h> 

struct A 
{
	int i_num; 
	char c_ans; 
	float f_num; 
}; 

struct A ina = {'A', 10, 3.14f}; 

int main (void) 
{
	
	printf("ina.i_num = %d\n", ina.i_num);
	printf("ina.c_ans = %c\n", ina.c_ans);

	printf ("sizeof (int):%ld\n", sizeof (int)); 
	printf ("sizeof (char):%ld\n", sizeof (char)); 
	printf ("sizeof (float):%ld\n", sizeof (float)); 
	printf ("sizeof (struct A):%ld\n", sizeof (struct A)); 
	return (EXIT_SUCCESS); 
}
