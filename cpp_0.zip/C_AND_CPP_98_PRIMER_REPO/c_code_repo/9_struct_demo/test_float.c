float pi = 3.14f; 
float f; 

int main (void) 
{
	f = pi; 
	pi = 6.28; 
	return (0); 
}
