#include <iostream>
#include <cstdlib>

class Complex{
private:
	double re, im; 
public: 
	// default constructor
	Complex() : re(0.0), im(0.0) {
	}
	
	// parameterized constructor
	Complex(double init_re, double init_im) : re(init_re), 
											  im(init_im){
	}

	// addition
	Complex operator+(const Complex &other){
		return Complex(re + other.re, im + other.im); 
	}

	// subtraction
	Complex operator-(const Complex &other){
		return Complex(re - other.re, im - other.im);
	}

	// multiplication (a+ib) * (c+id) = (a*c - b*d) + i(a*d + b*c)
	Complex operator*(const Complex &other){
		return Complex(re * other.re - im * other.im, 
					   re * other.im + im * other.re); 
	}

	// division (a+ib) / (c+id) = (a*c + b*d)/(c**2 + d**2) + 
	//							  i(b*c - a*d)/(c**2 + d**2)
	Complex operator/(const Complex &other){
		double denominator = im*im + (other.im * other.im); 
		return Complex(	(re*other.re + im*other.im) / denominator, 
						(im*other.re - re*other.im) / denominator); 
	}

	friend std::ostream& operator<<(std::ostream &out, const Complex &complex_number){
		out << "(" << complex_number.re << ")+i(" << complex_number.im << ")"; 
		return out; 
	}
	
	friend std::istream& operator>>(std::istream &in, Complex &complex_number){
		std::cout << "Enter real part of a complex number:"; 
		in >> complex_number.re; 
		std::cout << "Enter imaginary part of a complex number:"; 
		in >> complex_number.im; 
		return in;	
	}
}; 

int main(){
	Complex c1, c2; 

	std::cout << "Inputting two complex numbers:" << std::endl; 
	std::cin >> c1 >> c2; 
	
	Complex sum = c1 + c2, sub = c1 - c2, mul = c1 * c2, div = c1 / c2;
	
	std::cout 	<< "outputing the input complex numbers along with their" 
				<< " addition subtraction multiplication and division" 
				<< std::endl;

	std::cout 	<< "c1:" << c1 << std::endl << "c2:" << c2 << std::endl 
				<< "summation:" << sum << std::endl << "subtraction:"
				<< sub << std::endl << "multiplication:" << mul << std::endl 
				<< "division:" << div
				<< std::endl; 
	
	return EXIT_SUCCESS; 
}