#include <iostream> 
#include <vector>
#include <cstdlib> 
#include <ctime> 

#define NR_ELEMENTS 25 
#define CAP 1000
#define ODD 234

template <typename T> 
void insertion_sort (std::vector<T> &vec); 

int main (void) 
{
	std::vector<int> ivec; 
	std::vector<double> dvec; 
	
	srand (time (0)); 

	for (int i=0; i < NR_ELEMENTS; i++) 
	{
		ivec.push_back (rand () % CAP); 
		dvec.push_back (((double)rand ()) / ODD); 
	}
	
	std::cout << "Display integer vector before sort:" << std::endl; 
	for (std::vector<int>::size_type i=0; i != ivec.size (); i++) 
	{
		std::cout << "ivec[" << i << "]:" << ivec[i] << std::endl; 
	}

	insertion_sort (ivec); 

	std::cout << "Display integer vector after sort:" << std::endl; 
	for (std::vector<int>::size_type i=0; i != ivec.size (); i++) 
	{
		std::cout << "ivec[" << i << "]:" << ivec[i] << std::endl; 
	}

	std::cout << "Display floating vector before sort:" << std::endl; 
	for (std::vector<double>::size_type i=0; i != dvec.size (); i++) 
	{
		std::cout << "dvec[" << i << "]:" << dvec[i] << std::endl; 
	}

	insertion_sort (dvec); 

	std::cout << "Display floating vector after sort:" << std::endl; 
	for (std::vector<double>::size_type i=0; i != dvec.size (); i++) 
	{
		std::cout << "dvec[" << i << "]:" << dvec[i] << std::endl; 
	}	

	return 0; 
}

template <typename T> 
void insertion_sort (std::vector<T> &vec) 
{
	int i, j; 
	T key;  

	for (j=1; j != vec.size (); j++) 
	{
		key = vec[j]; 
		i = j - 1; 

		while (i > -1 && vec[i] > key)
		{
			vec[i+1] = vec[i]; 
			i--; 
		}

		vec[i+1] = key; 
	}	
}
