#include <stdio.h> 
#include <stdlib.h> 

int max(int n1, int n2); 
float max(float f1, float f2); 
double max(double d1, double d2); 

int main(void) 
{
	int n1, n2; 
	float f1, f2; 
	double d1, d2; 
	
	printf("Enter n1, n2:\n"); 
	scanf("%d%d", &n1, &n2); 
	printf("n1:%d n2:%d\n", n1, n2); 

	printf("Enter f1, f2:\n"); 
	scanf("%f%f", &f1, &f2); 
	printf("f1:%f f2:%f\n", f1, f2); 

	printf("Enter d1, d2:\n"); 
	scanf("%lf%lf", &d1, &d2); 
	printf("d1=%lf d2=%lf\n", d1, d2); 

	printf("max_int(n1, n2):%d\n", max(n1, n2)); 
	printf("max_float(f1, f2):%f\n", max(f1, f2)); 
	printf("max_double(d1, d2):%lf\n", max(d1, d2)); 

	return (0); 
}

int max(int n1, int n2)
{
	if (n1 > n2)
		return n1; 
	return n2; 
}

float max(float f1, float f2)
{
	if(f1 > f2)
		return f1; 
	return f2; 
}

double max(double d1, double d2)
{
	if(d1 > d2)
		return d1; 
	return d2; 
}
