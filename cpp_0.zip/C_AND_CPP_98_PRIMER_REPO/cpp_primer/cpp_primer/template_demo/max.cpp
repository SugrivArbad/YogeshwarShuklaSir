#include <iostream> 

template <typename T> 
T max (T &n1, T &n2); 

int main (void) 
{
	char c1='Z', c2='A'; 
	double d_num1=100.34, d_num2=50.32; 
	int i_num1=1000, i_num2=20; 

	char c_max  = max (c1, c2); 
	int i_max   = max (i_num1, i_num2); 
	double d_max = max (d_num1, d_num2); 
	
	std::cout << "char max:" << c_max << std::endl 
		  << "int max:" << i_max << std::endl 
		  << "double max:" << d_max << std::endl; 
		  
	return 0; 
}

template <typename T> 
T max (T &n1, T &n2) 
{
	return (n1 > n2 ? n1 : n2); 
}


