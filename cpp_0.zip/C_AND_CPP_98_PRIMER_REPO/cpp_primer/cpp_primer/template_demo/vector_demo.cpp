#include <iostream> 
#include <cstdlib> 
#include <cstdio> 
#include <vector> 

//using std::vector; 

/*namespace std
{
	template <typename T> 
	class Vector<T> 
	{
		public: 
				typedef long int size_type; 
	}; 
}; */ 

/* 
namespace X 
{
	class A 
	{
		public: 
			A () {} 
			~A () {} 
			typedef long int len_t; 
	}; 
}; 
*/ 

struct A 
{
	int i_num; 
	char c_ans; 
	double d_num; 
};  

void display (std::vector<int> &ivec); 
struct A *get_instance_A (void); 

int main (void) 
{
	std::vector<int> ivec1;  
	std::vector<int> ivec2 (10); 
	std::vector<int> ivec3 (7, 5); 
	std::vector<int> ivec4 (ivec3); 
	std::vector<char> cvec1; 
	
	std::cout << "sizeof (std::vector<int>::size_type):" 
			  << sizeof (std::vector<int>::size_type) << std::endl
			  << "sizeof (std::vector<char>::size_type):" 
			  << sizeof (std::vector<char>::size_type) << std::endl;  

//	std::vector<int> ivec5 (iter1, iter2); /
	
	// Traverse through already existing vectors 
	std::cout << "Printing ivec2" << std::endl; 
	for (std::vector<int>::size_type i=0; i != ivec2.size (); ++i) 
			std::cout << "ivec2[" << i << "]:" << ivec2[i] << std::endl; 
	
	std::cout << "Printing ivec3:" << std::endl; 
	for (std::vector<int>::size_type i=0; i != ivec3.size (); ++i) 
			std::cout << "ivec3[" << i << "]:" << ivec3[i] << std::endl; 
	
	std::cout << "Printing ivec4:" << std::endl; 
	for (std::vector<int>::size_type i=0; i != ivec4.size (); ++i) 
			std::cout << "ivec4[" << i << "]:" << ivec4[i] << std::endl; 

	int num; 
	std::cout << "Enter an integer:"; 
	while (std::cin >> num) 
	{
		ivec1.push_back (num); 
		std::cout << "Enter an integer:"; 
	}

	std::cout << std::endl; 
	for (std::vector<int>::iterator iter = ivec1.begin (); 
		 iter != ivec1.end (); 
		 iter++) 
		std::cout << "*iter:" << *iter << std::endl; 

	std::vector<int>::iterator iter1 = ivec3.begin () + 2; 
	std::vector<int>::iterator iter2 = ivec3.end () - 1; 
	std::vector<int>ivec5 (iter1, iter2); 

	std::cout <<"Displaying ivec5:" << std::endl; 
	display (ivec5); 

	std::cout << "Displaying ivec6:" << std::endl; 
	std::vector<int>ivec6; 
	for (std::vector<int>::iterator iter = iter1; iter != iter2; ++iter)
			ivec6.push_back (*iter); 
	display (ivec6); 
	
	srand (time (0)); 

	std::vector<struct A*> ivec7; 
	for (int i=0; i < 10; i++) 
			ivec7.push_back (get_instance_A()); 

	for (std::vector<struct A*>::iterator iter = ivec7.begin (); 
		 iter != ivec7.end (); ++iter) 
			std::cout << ".i_num=" << (*iter)->i_num << std::endl 
					  << ".c_ans=" << (*iter)->c_ans << std::endl
					  << ".d_num=" << (*iter)->d_num << std::endl << std::endl; 

	return 0; 
}

void display (std::vector<int> &ivec) 
{
	for (std::vector<int>::iterator iter = ivec.begin (); 
		 iter != ivec.end (); ++iter) 
			std::cout << "*iter:" << *iter << std::endl; 
}

struct A *get_instance_A (void) 
{
	struct A *ptr = (struct A*) calloc (1, sizeof (struct A)); 
	if (!ptr){
		fprintf (stderr, "calloc:fatal:out of memory\n"); 
		exit (EXIT_FAILURE); 
	}
	
	ptr->i_num = rand (); 
	ptr->c_ans = (char)(65 + rand () % 26); 
	ptr->d_num = ptr->i_num / 10; 

	return (ptr); 
}
