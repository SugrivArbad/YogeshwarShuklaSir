#include <iostream> 
#include <cstdlib> 
#include <string> 

class StudentRecord{
public:
	StudentRecord(int in_roll, std::string in_s_name) : 	roll(in_roll),
															s_name(in_s_name){}

	bool operator>(StudentRecord &other)
	{
		if(this->roll > other.roll) 
			return true; 
		return false; 
	}
	
	int get_roll(void) const {return roll;} 
	std::string get_name(void) const {return s_name;} 
private: 
	int roll; 
	std::string s_name; 
}; 

template <typename T> 
T &max(T &n1, T &n2); 

int main(void)
{
	int n1, n2; 
	float f1, f2; 
	double d1, d2; 
	std::string name1("Yogeshwar"), name2("Rohit"); 
	StudentRecord s1(10, name1), s2(20, name2); 
	StudentRecord s3(30, "FSDFSDF"); 

	std::cout << "Enter n1:"; 
	std::cin >> n1; 

	std::cout << "Enter n2:"; 
	std::cin >> n2; 

	std::cout << "Enter f1:"; 
	std::cin >> f1; 

	std::cout << "Enter f2:"; 
	std::cin >> f2; 

	std::cout << "Enter d1:"; 
	std::cin >> d1; 

	std::cout << "Enter d2:"; 
	std::cin >> d2; 

	std::cout << "n1:" << n1 << " n2:" << n2 
		<< " max(n1, n2):" << max(n1, n2) << std::endl; 	
	
	std::cout << "f1:" << f1 << " f2:" << f2 
			<< " max(f1, f2):" << max(f1, f2) << std::endl; 

	std::cout << "d1:" << d1 << " d2:" << d2 
			<< " max(d1, d2):" << max(d1, d2) << std::endl; 

	StudentRecord &rs = max(s1, s2); 
	std::cout << "rs.get_roll():" << rs.get_roll() << std::endl
			<< "rs.get_name():" << rs.get_name() << std::endl; 

}

template <typename T> 
T &max(T &n1, T &n2)
{
	if(n1 > n2) 
		return n1; 
	return n2; 
}

