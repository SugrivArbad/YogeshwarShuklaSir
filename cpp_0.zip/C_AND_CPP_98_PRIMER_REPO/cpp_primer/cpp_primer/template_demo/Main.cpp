#include "Stack.h" 

int main (void) 
{
	Stack<int>  st1(10); 
	Stack<char> st2 (15); 
	
	int i=10, c='A'; 

	int i_top; 
	char c_top; 

	st1.push (10);
	st2.push ('A'); 

	st1.push (i); 
	st1.push (c); 

	i_top = st1.top (); 
	c_top = st2.top (); 

	st1.pop (); 
	st2.pop (); 

	st1.is_empty (); 
	st2.is_empty (); 

	return (0); 
}
