#ifndef _STACK_H 
#define _STACK_H 

template <typename T> 
class Stack 
{
	public: 
		Stack (int stack_size) 
		{
			arr = new T[stack_size]; 
			max_stack_size = stack_size; 
			curr = -1; 
		}

		~Stack () {delete []arr;} 
		
		bool push (T element){
			if(curr+1 == max_stack_size)
			{
				std::cout << "push:Stack Full" << std::endl; 
				return false; 
			}
			arr[++curr] = element; 
			return true;
		} 

		bool push (T *element) 
		{ 
			if (curr+1== max_stack_size)
			{
				std::cout << "push:Stack Full" << std::endl; 
				return false; 
			}

			arr[++curr] = *element; 
			return true;
		}

		bool is_empty (void) const 
		{
			return (curr == -1);
		} 

		bool top (T *pObject) const
		{
			if (curr == -1)
			{
				std::cout << "top:Cannot top from empty stack" << std::endl; 
				return false; 
			}

			*pObject = arr[curr];
			return (true); 
		} 

		bool pop (T *pObject)
		{
			if (curr == -1)
			{
				std::cout << "pop:Cannot top from empty stack" << std::endl; 
				return false; 
			}

			*pObject = arr[curr]; 
			curr--;
			return (true); 
		} 
	private: 
		T *arr; 
		int max_stack_size; 
		int curr; 
}; 

#endif 



