#include <iostream> 
#include <cstdlib> 

int main (void) 
{
	int *ptr = new int [25]; 
	for (int i=0; i < 25; i++) 
			ptr[i] = i * 10; 
	for (int i=0; i < 25; i++) 
			std::cout << ptr[i] << std::endl; 

	delete []ptr; 


	return (0); 

}
