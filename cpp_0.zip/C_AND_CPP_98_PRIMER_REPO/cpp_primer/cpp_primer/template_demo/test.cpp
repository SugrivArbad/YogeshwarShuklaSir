int n1=100, n2=200; 
float f1=3.14f, f2=6.28f; 
double d1=3434.322, d2=23423.221; 

int main (void) 
{
	if (n1 > n2) 
		n1 = 200; 

	if (f1 < f2) 
		f1 = f2; 

	if (d1 < d2)
		d1 = d2;  

	return (0); 
}
