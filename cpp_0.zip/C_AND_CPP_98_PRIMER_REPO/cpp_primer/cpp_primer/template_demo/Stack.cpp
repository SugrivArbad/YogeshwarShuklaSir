#include <iostream> 
#include <cstdlib> 
#include "Stack.h" 

int main(void)
{
	Stack<int> iStack(10); 
	int top_element; 
	bool rs; 
	//Stack<student_record> srStack(300); 

	if((rs = iStack.is_empty()) != true)
		std::cerr << "is_empty:Unexpected Error" << std::endl; 
	std::cout << "iStack is empty initially" << std::endl; 

	if((rs = iStack.top(&top_element)) != false)
		std::cerr << "top:Unexpected Error" << std::endl; 

	if((rs = iStack.pop(&top_element)) != false)
		std::cout << "pop:Unexpected Error" << std::endl; 

	for(int i=0; i < 11; i++)
		rs = iStack.push((i+1)*10); 

	rs = iStack.top(&top_element); 
	if(rs)
		std::cout << "Top Element:" << top_element << std::endl; 

	while((rs = iStack.pop(&top_element)) != false)
	{
		std::cout << "Poped:" << top_element << std::endl; 
	}

	Stack<char> cStack(5); 

	cStack.push('A'); 
	cStack.push('B'); 
	cStack.push('C'); 
	cStack.push('D'); 
	cStack.push('E'); 
	
	char cTop = '\0'; 

	cStack.top(&cTop); 
	std::cout << "cTop:" << cTop; 

	char out; 
	while((rs = cStack.pop(&out)) != false)
		std::cout << "POP:" << out << std::endl; 

	return EXIT_SUCCESS; 
}
