#include <stdio.h> 
#include <stdlib.h> 

struct A 
{
private:
		int i_num; 
		char c_ans; 
		double d_num; 
}inA = {10, 'A', 43.221}; 

int main (void) 
{
	inA.i_num = 100; 
	return (EXIT_SUCCESS); 
}
