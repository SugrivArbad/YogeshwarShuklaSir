#include <iostream> 
#include <cstdlib> 
#include <typeinfo> 

#define NR_DERIVED_CLASSES 4 

class Base{
public: 
	Base () {} 
	virtual ~Base() {} 
	virtual void f(void) {std::cout << "Base f" << std::endl;}
	void x(void) {std::cout << "Base x" << std::endl;}
}; 

class D1 : public Base{
public:
	D1() {} 
	~D1(){} 
	void f(void) {std::cout << "D1 f" << std::endl;}
	void g1(void) {std::cout << "D1 g1" << std::endl;}
	void x(void) {std::cout << "D1 x" << std::endl;}
}; 

class D2 : public Base{
public:
	D2() {} 
	~D2(){} 
	void f(void) {std::cout << "D2 f" << std::endl;}
	void g2(void) {std::cout << "D2 g2" << std::endl;}
}; 

class D3 : public Base{
public:
	D3() {} 
	~D3(){} 
	void f(void) {std::cout << "D3 f" << std::endl;}
	void g3(void) {std::cout << "D3 g3" << std::endl;}
}; 

class D4 : public Base{
public:
	D4() {} 
	~D4(){} 
	void f(void) {std::cout << "D4 f" << std::endl;}
	void g4(void) {std::cout << "D4 g4" << std::endl;}
}; 

int main(void)
{
	Base *pB; 
	D1 *pD1 = 0; 
	D2 *pD2 = 0; 
	D3 *pD3 = 0; 
	D4 *pD4 = 0; 

	pB = new D3(); 

	pD1 = dynamic_cast<D1*>(pB); 
	pD2 = dynamic_cast<D2*>(pB); 
	pD3 = dynamic_cast<D3*>(pB); 
	pD4 = dynamic_cast<D4*>(pB); 

	if(pD1)
		pD1->g1(); 
	else if(pD2)
		pD2->g2(); 
	else if(pD3)
		pD3->g3(); 
	else if(pD4) 
		pD4->g4(); 

	return 0; 
}

