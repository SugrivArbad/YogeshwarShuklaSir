#include <stdio.h> 
#include <stdlib.h> 
	
int main(void) 
{
	int num = 0x0a0b0c0d; 

	if(*(char*)&num == 0x0d)
			printf("The processor is little endian\n"); 
	else if(*(char*)&num == 0x0a)
			printf("The processor is big endian\n"); 
	else
			printf("Stange processor\n"); 

	exit(EXIT_SUCCESS); 
}
