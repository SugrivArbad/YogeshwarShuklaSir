#include <iostream> 

class Interface
{
	public: 
	virtual void f1(void) = 0; 
	virtual void f2(void) = 0; 
	virtual void f3(void) = 0; 
}; 

class C1 : public Interface
{
	public: 
	void f1(void) { std::cout << "In C1-f1" << std::endl; }
	void f2(void) { std::cout << "In C1-f2" << std::endl; }
	void f3(void) { std::cout << "In C1-f3" << std::endl; } 
}; 

class C2 : public Interface
{
	public: 
	void f1(void) { std::cout << "In C2-f1" << std::endl; }
	void f2(void) { std::cout << "In C2-f2" << std::endl; }
	void f3(void) { std::cout << "In C2-f3" << std::endl; }
}; 

int main(void) 
{
	Interface *pI; 

	pI = new C1; 
	pI->f2(); 
	pI = new C2; 
	pI->f3(); 

	return (0); 
}
