#include <iostream>

class CHasPtr
{
	private:
		int *ptr;
		int ref_cnt;
	public:	
		CHasPtr (int ptr_val)
		{
			ptr = new int (ptr_val);
		}
		~CHasPtr ()
		{
			delete ptr;
		}
		
		int *get_ptr (void) const { return (ptr); }
		int get_ptr_val (void) const { return (*ptr); }
		int get_ref_cnt (void) const { return (ref_cnt); }
		
		void init_ref_cnt (void)  { ref_cnt = 1; }
		void add_ref_cnt (void) { ref_cnt++; }
		void release_ref_cnt (void) { ref_cnt--; }
};

class T
{
	public:
		//default contructor
		T () 
		{
			std::cout << "Default constructor" << std::endl;
		}
		// Explicite contructor
		T (int n, int ptr_val) 
		{
			std::cout << "Explicite Constructor" << std::endl;
			this->i_num = n;				
			this->hPtr = new CHasPtr (ptr_val);
			this->hPtr->init_ref_cnt ();
		}
		// copy constructor 1
		T (const T& ref) 
		{
			std::cout << "Copy constructor1" << std::endl;
			this->i_num = ref.i_num;
			this->hPtr = ref.hPtr;
			this->hPtr->add_ref_cnt ();
		}
		// operator overloade constructor
		T& operator= (const T& ref)
		{
			std::cout << "Operator overloaded constructor" << std::endl;
			this->i_num = ref.i_num;
			this->hPtr = ref.hPtr;
			this->hPtr->add_ref_cnt ();
		} 
		
		int get_int (void) const { return (this->i_num); }
		int *get_ptr (void) const {  }
		int get_ptr_val (void) const  {  }

		void set_int (int n) { i_num = n; }
		void set_ptr (int *ptr) { }
		void set_ptr_val (int new_ptr_val) { }		
		
		void display (void) const;
		
		~T() 
		{
			this->hPtr->release_ref_cnt ();
			if (this->hPtr->get_ref_cnt () < 1)
			{
				delete this->hPtr;
				std::cout << "Destructor: integer distroyed" << std::endl;
			}
			else
			{
				std::cout << "Destructor: integer can not be distroyed: shared by:" << this->hPtr->get_ref_cnt ()
					  << " objects" << std::endl;
			}
		}
	private:
		int i_num;
		CHasPtr *hPtr;
};

void T::display (void) const
{
	std::cout << "integer:" << this->get_int () << std::endl
		  << "ptr:" << this->hPtr->get_ptr () << std::endl
		  << "ptr_val:" << this->hPtr->get_ptr_val () << std::endl
		  << "->ref_cnt:" << this->hPtr->get_ref_cnt () << std::endl << std::endl;
}

int main (void)
{
	T t1(10, 20);
	t1.display ();

	T t2 (t1); 
	t2.display ();

	T t3 (t2);
	t3.display ();

	T t4 (t3);
	t4.display ();

	T t5 (t4);
	t5.display ();



/*	T *t3 = new T (100, 200);
	t3->display ();
	T *t4 = new T ();
	*t4 = *t3;
	t4->display ();	
	delete t3;
	delete t4;
*/
	return (0);
}
