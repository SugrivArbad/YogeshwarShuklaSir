#include <iostream> 
#include <string> 
#include <cstdlib> 
#include <cstdio> 

class TestClass 
{
	public:
		// Default 
		TestClass () : i_num(0), c_ans('\0'), d_num(0.0) {} 
		// Explicit 
		TestClass (int i_num, char c_ans, double d_num, std::string s_str) 
		{
			this->i_num = i_num; 
			this->c_ans = c_ans; 
			this->d_num = d_num; 
			this->s_str = s_str; 
			printf ("constructor:%p\n", this); 
		}
		// Copy 
		TestClass (const TestClass &ref_testclass_obj)
		{
			this->i_num = ref_testclass_obj.i_num; 
			this->c_ans = ref_testclass_obj.c_ans; 
			this->d_num = ref_testclass_obj.d_num; 
			this->s_str = ref_testclass_obj.s_str; 
		}
		// Destructor 
		~TestClass () 
		{
			printf ("In destuctor:this:%p\n", this); 	
		}
		// Display object state
		void display (void) const 
		{
			std::cout << "i_num:" << i_num << std::endl 
				  << "c_ans:" << c_ans << std::endl 
				  << "d_num:" << d_num << std::endl 
			 	 << "s_str:" << s_str << std::endl; 
		}
	private:
		int i_num; 
		char c_ans; 
		double d_num; 
		std::string s_str; 
}; 

void test_function_one (TestClass &ref); 
void test_function_two (TestClass *ptr); 
void test_function_three (void); 

int main (void) 
{

	std::cout << "main:Enter" << std::endl; 

	TestClass t1 (10, 'A', 3.14, std::string ("Hello")); 
	TestClass t2 (20, 'B', 6.28, std::string ("World")); 

	test_function_one (t1); 
	test_function_two (&t2); 
	test_function_three (); 

	std::cout << "main:Leave" << std::endl; 

	return (EXIT_SUCCESS); 

}

void test_function_one (TestClass &ref_testclass_obj)
{
	std::cout << "test_function_one:Enter" << std::endl; 
	ref_testclass_obj.display (); 
	std::cout << "test_function_one:Leave" << std::endl; 
}

void test_function_two (TestClass *ptr) 
{
	std::cout << "test_function_two:Enter" << std::endl; 
	ptr->display (); 
	std::cout << "test_function_two:Leave" << std::endl; 
}

void test_function_three (void) 
{
	std::cout << "test_function_three:Enter" << std::endl; 
	TestClass t3 (30, 'C', 9.42, std::string ("C++")); 
	t3.display(); 
	std::cout << "test_function_three:Leave" << std::endl; 
}

