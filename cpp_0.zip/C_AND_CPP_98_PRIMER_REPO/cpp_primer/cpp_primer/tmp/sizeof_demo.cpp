#include <iostream> 
#include <cstdlib> 

class Interface
{
	virtual void f1(void) ; 
	virtual void f2(void) ; 
}; 

class C : public Interface 
{
	private: 
			long int n1,n2; 
			char buffer[32]; 
	public: 
			C() {} 
			void f1(void) { std::cout << "n1:" << n1 << std::endl; } 
			void f2(void) { std::cout << "n2:" << n2 << std::endl; } 
}; 

int main()
{
	C inC; 
	std::cout << "sizeof(C):" << sizeof(C) << std::endl; 
	std::cout << "sizeof(inC):" << sizeof(inC) << std::endl; 
	return 0; 
}
