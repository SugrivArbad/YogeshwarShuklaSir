einclude <iostream> 
#include <cstdlib> 
#include <typeinfo> 

class X{
public:
	X() {} 
	~X() {} 
	virtual void f(void) {std::cout << "I am in X-f" << std::endl;}
}; 

class Y : public X{
public:
	Y() {} 
	~Y() {}
	void f(void) {std::cout << "I am in Y-f" << std::endl;}
	void g(void) {std::cout << "I am in Y-g" << std::endl;}
}; 

int main(void)
{
	X *ptr = new X(); 
	// ptr->g();  // Compile time error 
	std::cout << "typeid(*ptr):" << typeid(*ptr).name() << std::endl; 
	std::cout << "typeid(*(reinterpret_cast<Y*>(ptr)).name():" 	<< 
				  typeid(*(reinterpret_cast<Y*>(ptr))).name() 	<< std::endl <<
				 // "typeid(*(dynamic_cast<Y*>(ptr)).name():" 	<< 
				 // typeid(*(dynamic_cast<Y*>(ptr))).name() 	<< 
				  "typeid(*(static_cast<Y*>(ptr)).name():" 		<< 
				  typeid(*(static_cast<Y*>(ptr))).name() 		<< std::endl; 
	reinterpret_cast<Y*>(ptr)->f(); 
	reinterpret_cast<Y*>(ptr)->g(); 
	delete ptr; 
	return (EXIT_SUCCESS); 
}
