#include <iostream> 
#include <cstdlib> 
#include <typeinfo> 

#define NR_DERIVED_CLASSES 4 

class Base{
public: 
	Base () {} 
	virtual ~Base() {} 
	virtual void f(void) {std::cout << "Base f" << std::endl;}
	void x(void) {std::cout << "Base x" << std::endl;}
}; 

class D1 : public Base{
public:
	D1() {} 
	~D1(){} 
	void f(void) {std::cout << "D1 f" << std::endl;}
	void g1(void) {std::cout << "D1 g1" << std::endl;}
	void x(void) {std::cout << "D1 x" << std::endl;}
}; 

class D2 : public Base{
public:
	D2() {} 
	~D2(){} 
	void f(void) {std::cout << "D2 f" << std::endl;}
	void g2(void) {std::cout << "D2 g2" << std::endl;}
}; 

class D3 : public Base{
public:
	D3() {} 
	~D3(){} 
	void f(void) {std::cout << "D3 f" << std::endl;}
	void g3(void) {std::cout << "D3 g3" << std::endl;}
}; 

class D4 : public Base{
public:
	D4() {} 
	~D4(){} 
	void f(void) {std::cout << "D4 f" << std::endl;}
	void g4(void) {std::cout << "D4 g4" << std::endl;}
}; 

int main(void)
{
	Base *ptr1, *ptr2 = new D1(); 
	D1 *dptr = new D1(); 
	
	std::cout << "ptr2:" << std::endl; 
	ptr2->f(); 
	ptr2->x(); 

	static_cast<Base*>(ptr2)->f(); 
	static_cast<Base*>(ptr2)->x(); 
	
	dynamic_cast<Base*>(ptr2)->f(); 
	dynamic_cast<Base*>(ptr2)->x(); 
	std::cout << "ptr2 end" << std::endl; 

	static_cast<Base*>(dptr)->x(); // non polymorphic
	static_cast<Base*>(dptr)->f(); // polymorphic 
	
	srand(time(0)); 

	switch(rand() % NR_DERIVED_CLASSES){
		case 0: 
			ptr1 = new D1();
			break; 
		case 1: 
			ptr1 = new D2(); 
			break; 
		case 2: 
			ptr1= new D3(); 
			break; 
		case 3: 
			ptr1 = new D4(); 
			break; 
	}
	 

	if(typeid (*ptr1) == typeid(D1)) {
		ptr1->f(); 
		static_cast<D1*>(ptr1)->g1(); 	
	}
	else if(typeid(*ptr1) == typeid(D2)) {
		ptr1->f(); 
		dynamic_cast<D2*>(ptr1)->g2(); 
	}
	else if(typeid(*ptr1) == typeid(D3)){
		ptr1->f(); 
		dynamic_cast<D3*>(ptr1)->g3(); 
	}
	else if(typeid(*ptr1) == typeid(D4)){
		ptr1->f(); 
		dynamic_cast<D4*>(ptr1)->g4(); 
	}
	else{
		std::cout << "ERROR" << std::endl; 
	}

	delete ptr1; 

	return 0; 
}

