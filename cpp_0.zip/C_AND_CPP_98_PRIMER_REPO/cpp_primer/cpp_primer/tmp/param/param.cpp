void f(int a, int b, int c); 

int main(void) 
{
	f(10, 20, 30); 
	return (0); 
}

void f(int a, int b, int c) 
{
	int d = c - a - b; 
}
