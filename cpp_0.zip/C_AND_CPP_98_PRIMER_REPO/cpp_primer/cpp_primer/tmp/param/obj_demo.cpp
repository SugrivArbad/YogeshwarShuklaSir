#include <iostream> 

class Test
{
	private: 
			char a; 
			int b; 
			float c; 
	public: 
			Test() 
			{
			
			}

			char get_char() 
			{
				return (a); 
			}

			int get_int()
			{
				return (b); 
			}

			int get_float() 
			{
				return (c); 
			}

			void set_char(char new_char)
			{
				a = new_char; 
			}

			void set_int(int new_int) 
			{
				b = new_int; 
			}

			void set_float(float new_float) 
			{
				c = new_float; 
			}
}; 

Test t1; 
int n; 


int main(void) 
{
	t1.set_int(100); 
	n = t1.get_int(); 

	return (0); 	
}
