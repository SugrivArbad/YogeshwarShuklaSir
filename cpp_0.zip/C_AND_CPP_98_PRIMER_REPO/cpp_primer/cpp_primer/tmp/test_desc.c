#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <errno.h> 
#include <fcntl.h> 
#include <unistd.h> 

#define BUFFER_SIZE 4096
char buffer[BUFFER_SIZE]; 

int main (void) 
{
	int fd = 4, rb; 

	rb = read (fd, buffer, BUFFER_SIZE); 
	if (rb == -1) 
	{
		fprintf (stderr, "read:%s\n", strerror (errno)); 
		exit (EXIT_FAILURE); 
	}

	exit (EXIT_SUCCESS); 
}
