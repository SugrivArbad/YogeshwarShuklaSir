#include <stdio.h> 
#include <stdlib.h> 

struct A{
	int i_num; 
	unsigned char c_ans; 
	long long int ll_num; 
	double d_num; 
}; 

struct B{
	int i_arr[3]; 
	char c_ans; 
	long long int vlong_num; 
}; 

struct A inA = {10, 25, 0x0a0b0c0da0b0c0d0, 3.14}; 

void dumpA(struct A *ptr); 

int main(void) 
{
	dumpA(&inA); 	
	((struct B*)&inA)->c_ans = 0xFF; 
	dumpA(&inA); 
	return (EXIT_SUCCESS); 
}

void dumpA(struct A *ptr) 
{
	printf("ptr->i_num:%d ptr->c_ans:%d ptr->ll_num:%llx ptr->d_num:%lf\n", 
			ptr->i_num, ptr->c_ans, ptr->ll_num, ptr->d_num); 
}

#define OFFSET_OF(T,x)	(unsigned long int)&(((T*)0)->x)
