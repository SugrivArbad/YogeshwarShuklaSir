#include <iostream> 
#include <cstdlib> 

int main(void) 
{
	std::cout << "Hello,C++ World!" << std::endl; 
	return (EXIT_SUCCESS); 
}

