int printf(const char *, ...); 
void exit(int); 

void foo(void) 
{
	printf("I am in FOO\n"); 
	exit(0); 
}
