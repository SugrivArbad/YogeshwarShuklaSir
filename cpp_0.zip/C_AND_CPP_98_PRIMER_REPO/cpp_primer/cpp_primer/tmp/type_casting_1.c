#include <stdio.h> 
#include <stdlib.h> 

unsigned long long int num = 0x0a0b0c0d0a0b0c0d0; 

int main(void) 
{
	printf("num=%llx\n", num); 
	*(char*)&num = 0xFF; 
	printf("num=%llx\n", num); 
	*(short int*)((char*)&num + 1) = 0xFFFF; 
	printf("num=%llx\n", num); 
	*(int*)((char*)&num + 3) = 0xFFFFFFFF; 
	printf("num=%llx\n", num); 
	*(char*)((char*)&num + 7) = 0xFF; 
	printf("num=%llx\n", num); 

	return(EXIT_SUCCESS); 

}
