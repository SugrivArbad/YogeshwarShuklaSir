#include <iostream> 

class Base
{
	private: 
			long int n1, n2; 
	public: 
			Base() {} 
			virtual void f1(void) { std::cout << "In base f1" << std::endl; }
			void f2(void) { std::cout << "In Base f2" << std::endl; } 
}; 

class Derived : public Base
{
	public: 
			Derived() {} 
			void f1(void) { std::cout << "In derived f1" << std::endl;} 
}; 

int main(void) 
{
	std::cout << "sizeof(Base):" << sizeof(Base) << std::endl; 
	return 0; 
}
