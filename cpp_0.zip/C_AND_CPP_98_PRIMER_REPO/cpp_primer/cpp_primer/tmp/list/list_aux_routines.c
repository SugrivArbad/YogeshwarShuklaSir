#include <stdio.h> 
#include <stdlib.h> 
#include "list.h"

void g_insert(node_t *beg, node_t *mid, node_t *end)
{
	mid->prev = beg; 
	mid->next = end; 
	beg->next = mid; 
	end->prev = mid; 	
}

void g_delete(node_t *node)
{
	node->next->prev = node->prev; 
	node->prev->next = node->next; 
	free(node); 
}

node_t *search_node(list_t *lst, data_t s_data)
{
	node_t *run; 
	for(run=lst->next; run != lst; run=run->next){
		if(run->data == s_data)
			return (run); 
	}

	return(NULL); 
}

node_t *get_node(data_t new_data)
{
	node_t *new_node = (node_t*) xcalloc(1, sizeof(node_t)); 
	new_node->data = new_data; 
	return(new_node); 
}

void *xcalloc(int nr_elements, int size_per_element)
{
	void *ptr=calloc(nr_elements, size_per_element); 
	if(!ptr){
		fprintf(stderr, "xcalloc:out of memory\n"); 
		exit(EXIT_FAILURE); 
	}

	return(ptr); 
}