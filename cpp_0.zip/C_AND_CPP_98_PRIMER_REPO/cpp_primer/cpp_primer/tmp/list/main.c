// Client code 

#include <stdio.h> 
#include <stdlib.h> 
#include "list.h" 

int main(void) 
{
	int i; 
	list_t *lst = create_list(); 
	for(i=0; i < 5; i++)
			insert_beg(lst, i); 

	display_list(lst); 

	for(i=5; i < 10; i++)
			insert_end(lst, i); 
	display_list(lst); 

	insert_after_data(lst, 0, 100); 
	insert_before_data(lst, 0, 200); 
	display_list(lst); 

	del_beg(lst); 
	del_end(lst); 
	del_data(lst, 0); 
	display_list(lst); 

	if(destroy_list(&lst) == SUCCESS && lst == NULL)
		printf("List destroyed successfully\n"); 

	return EXIT_SUCCESS; 
}

