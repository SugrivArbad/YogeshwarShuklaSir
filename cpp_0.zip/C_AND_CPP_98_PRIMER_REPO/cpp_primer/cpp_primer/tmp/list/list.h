#ifndef _LIST_H 
#define _LIST_H 

#define TRUE  			1 
#define FALSE 			0 
#define SUCCESS			1 
#define FAILURE			0
#define DATA_NOT_FOUND -1 
#define LIST_EMPTY 	   -2 

/* typedefs */ 
struct node; 
typedef struct node node_t; 
typedef node_t list_t; 
typedef int data_t; 
typedef int result_t; 

/* Layout of node in a list*/ 
struct node{
	data_t data; 
	struct node *prev, *next; 
}; 

/* List interface routines */ 
list_t *create_list(void); 
result_t insert_beg(list_t *lst, data_t new_data); 
result_t insert_end(list_t *lst, data_t new_data); 
result_t insert_after_data(list_t *lst, data_t e_data, data_t new_data); 
result_t insert_before_data(list_t *lst, data_t e_data, data_t new_data); 
result_t del_beg(list_t *lst); 
result_t del_end(list_t *lst); 
result_t del_data(list_t *lst, data_t e_data); 
result_t search_list(list_t *lst, data_t s_data); 
result_t is_empty(list_t *lst); 
void	 display_list(list_t *lst); 
result_t destroy_list(list_t **pp_lst); 

/* List auxillary routines */ 
void g_insert(node_t *beg, node_t *mid, node_t *end); 
void g_delete(node_t *node); 
node_t *search_node(list_t *lst, data_t s_data); 
node_t *get_node(data_t new_data); 

/* Auxillary routines */ 
void *xcalloc(int nr_elements, int size_per_element); 

#endif /* _LIST_H */ 