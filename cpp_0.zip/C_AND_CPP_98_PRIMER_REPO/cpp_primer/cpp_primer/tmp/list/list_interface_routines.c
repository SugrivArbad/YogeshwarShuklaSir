#include <stdio.h> 
#include <stdlib.h> 
#include "list.h" 

list_t *create_list(void)
{
	list_t *lst = get_node(0); 
	lst->prev = lst->next = lst; 
	return(lst); 
}

result_t insert_beg(list_t *lst, data_t new_data)
{
	node_t *new_node = get_node(new_data);
	g_insert(lst, new_node, lst->next); 
	return(SUCCESS); 
}

result_t insert_end(list_t *lst, data_t new_data)
{
	node_t *new_node = get_node(new_data); 
	g_insert(lst->prev, new_node, lst); 
	return(SUCCESS); 
}

result_t insert_after_data(list_t *lst, data_t e_data, data_t new_data)
{
	node_t *e_node, *new_node; 
	e_node = search_node(lst, e_data); 
	if(!e_node)
		return DATA_NOT_FOUND; 
	new_node = get_node(new_data); 
	g_insert(e_node, new_node, e_node->next); 
	return(SUCCESS); 
}

result_t insert_before_data(list_t *lst, data_t e_data, data_t new_data)
{
	node_t *e_node, *new_node; 
	e_node = search_node(lst, e_data); 
	if(!e_node){
		return(DATA_NOT_FOUND); 
	}
	new_node = get_node(new_data); 
	g_insert(e_node->prev, new_node, e_node); 
	return(SUCCESS); 
}

result_t del_beg(list_t *lst)
{
	if(is_empty(lst))
		return(LIST_EMPTY); 
	g_delete(lst->next); 
	return(SUCCESS); 
}

result_t del_end(list_t *lst)
{
	if(is_empty(lst))
		return(LIST_EMPTY); 
	g_delete(lst->prev); 
	return(SUCCESS); 
}

result_t del_data(list_t *lst, data_t e_data)
{
	node_t *e_node = search_node(lst, e_data); 
	if(!e_node)
		return(DATA_NOT_FOUND); 
	g_delete(e_node); 
	return(SUCCESS);
}

result_t search_list(list_t *lst, data_t s_data)
{
	node_t *e_node = search_node(lst, s_data); 
	if(e_node)
		return(TRUE); 
	else
		return(FALSE); 
}

result_t is_empty(list_t *lst)
{
	if(lst->next == lst && lst->prev == lst)
		return(TRUE); 
	else
		return(FALSE); 
}

void display_list(list_t *lst)
{
	node_t *run; 
	printf("[beg]<->"); 
	for(run=lst->next; run != lst; run=run->next)
		printf("[%d]<->", run->data); 
	printf("[end]\n"); 
}

result_t destroy_list(list_t **pp_lst)
{
	node_t *head = *pp_lst; 
	node_t *run, *run_n; 
	for(run=head->next; run != head; run=run_n){
		run_n = run->next; 
		free(run); 
	}
	free(head); 
	*pp_lst = NULL; 
	return(SUCCESS); 
}
