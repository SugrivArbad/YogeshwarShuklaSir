#include <iostream> 
#include <cstdlib> 
#include <typeinfo> 

int main(void)
{
	int i=0; 
	std::cout << typeid(i).name() << std::endl; 
	return 0; 
}