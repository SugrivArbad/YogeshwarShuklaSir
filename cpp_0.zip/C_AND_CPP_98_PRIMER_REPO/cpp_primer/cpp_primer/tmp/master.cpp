#include <iostream> 
#include <cstdlib> 

class Interface 
{
	virtual void add (Interface *other, void **ret) = 0; 

}; 

class Complex : public Interface
{
public: 
	~Complex () {std::cout << "I am here" << std::endl; } 
	Complex (double re_in=0.0, double im_in=0.0) : re (re_in), im (im_in) {} 
	void add (Interface *other, void **ret)
	{
		double tmp_re, tmp_im; 
		tmp_re = dynamic_cast <Complex*> (this)->re + dynamic_cast <Complex *> (other)->re; 
		tmp_im = dynamic_cast <Complex*> (this)->im + dynamic_cast <Complex *> (other)->im;
		*(Complex**)ret = new Complex (tmp_re, tmp_im); 

	}
	void display (void)
	{
		std::cout << "re:" << re << " im:" << im << std::endl; 
	}
private:
	double re, im; 
}; 

class Vector : public Interface
{
private:
	double x, y, z; 
}; 

int main (void) 
{
	Complex c1(10.5, 20.5), c2(30.5, 40.5), *sum; 

	c1.display (); 
	c2.display (); 
	
	c1.add (&c2, (void**)&sum); 

	sum->display (); 
	delete (sum); 

	return (EXIT_SUCCESS); 
}
#include <iostream> 
#include <cstdlib> 

class TestClass 
{
	public: 
		// Default constructor 
		TestClass () : i_num (0), c_ans ('\0'), d_num (0.0) {} 

		// Explicit 
		TestClass (int i_num, char c_ans, double d_num) 
		{
			this->i_num = i_num; 
			this->c_ans = c_ans; 
			this->d_num = d_num; 
		} 

		// copy constructor 
		/*TestClass (const TestClass &ref_testclass_obj) 
		{
			i_num = ref_testclass_obj.i_num; 
			c_ans = ref_testclass_obj.c_ans; 
			d_num = ref_testclass_obj.d_num; 
		}*/ 

		void display (void) const 
		{
			std::cout << "i_num:" << i_num << std::endl
				  << "c_ans:" << c_ans << std::endl 
				  << "d_num:" << d_num << std::endl; 
		}

	private:
		int i_num; 
		char c_ans; 
		double d_num; 

}; 

TestClass t5 (30, 'C', 12.45); 
TestClass t1 (10, 'A', 3.14); 
TestClass t4 (20, 'B', 6.28); 

int main (void) 
{
	TestClass t2 (t1); 
	t2.display (); 
	TestClass *t3 = new TestClass (t1); 
	t3->display (); 
	return (EXIT_SUCCESS); 
}
#include <iostream> 

using namespace std; 

class X 
{
	public: 
		int a; 
		void f (int b) 
		{
			cout << b << endl; 
		}

};

int main (void) 
{
	int X::*ptr = & X::a; 

	X x1; 
	X *xptr = new X (); 

	x1.*ptr = 100; 
	xptr->*ptr = 200; 

	cout << "x1.*ptr:" << x1.*ptr << endl; 
	cout << "xptr->a:" << xptr->a << endl; 

	return (0); 
}
#include <iostream> 
#include <string> 
#include <cstdlib> 
#include <cstdio> 

class TestClass 
{
	public:
		// Default 
		TestClass () : i_num(0), c_ans('\0'), d_num(0.0) {} 
		// Explicit 
		TestClass (int i_num, char c_ans, double d_num, std::string s_str) 
		{
			this->i_num = i_num; 
			this->c_ans = c_ans; 
			this->d_num = d_num; 
			this->s_str = s_str; 
			printf ("constructor:%p\n", this); 
		}
		// Copy 
		TestClass (const TestClass &ref_testclass_obj)
		{
			this->i_num = ref_testclass_obj.i_num; 
			this->c_ans = ref_testclass_obj.c_ans; 
			this->d_num = ref_testclass_obj.d_num; 
			this->s_str = ref_testclass_obj.s_str; 
		}
		// Destructor 
		~TestClass () 
		{
			printf ("In destuctor:this:%p\n", this); 	
		}
		// Display object state
		void display (void) const 
		{
			std::cout << "i_num:" << i_num << std::endl 
				  << "c_ans:" << c_ans << std::endl 
				  << "d_num:" << d_num << std::endl 
			 	 << "s_str:" << s_str << std::endl; 
		}
	private:
		int i_num; 
		char c_ans; 
		double d_num; 
		std::string s_str; 
}; 

void test_function_one (TestClass &ref); 
void test_function_two (TestClass *ptr); 
void test_function_three (void); 

int main (void) 
{

	std::cout << "main:Enter" << std::endl; 

	TestClass t1 (10, 'A', 3.14, std::string ("Hello")); 
	TestClass t2 (20, 'B', 6.28, std::string ("World")); 

	test_function_one (t1); 
	test_function_two (&t2); 
	test_function_three (); 

	std::cout << "main:Leave" << std::endl; 

	return (EXIT_SUCCESS); 

}

void test_function_one (TestClass &ref_testclass_obj)
{
	std::cout << "test_function_one:Enter" << std::endl; 
	ref_testclass_obj.display (); 
	std::cout << "test_function_one:Leave" << std::endl; 
}

void test_function_two (TestClass *ptr) 
{
	std::cout << "test_function_two:Enter" << std::endl; 
	ptr->display (); 
	std::cout << "test_function_two:Leave" << std::endl; 
}

void test_function_three (void) 
{
	std::cout << "test_function_three:Enter" << std::endl; 
	TestClass t3 (30, 'C', 9.42, std::string ("C++")); 
	t3.display(); 
	std::cout << "test_function_three:Leave" << std::endl; 
}

#include <iostream> 
#include <string> 
#include <cstdlib> 
#include <cstdio> 

class TestClass 
{
	public:
		// Default 
		TestClass () : i_num(0), c_ans('\0'), d_num(0.0) {} 
		// Explicit 
		TestClass (int i_num, char c_ans, double d_num, std::string s_str) 
		{
			this->i_num = i_num; 
			this->c_ans = c_ans; 
			this->d_num = d_num; 
			this->s_str = s_str; 
			printf ("constructor:%p\n", this); 
		}
		// Copy 
		TestClass (const TestClass &ref_testclass_obj)
		{
			this->i_num = ref_testclass_obj.i_num; 
			this->c_ans = ref_testclass_obj.c_ans; 
			this->d_num = ref_testclass_obj.d_num; 
			this->s_str = ref_testclass_obj.s_str; 
		}
		// Destructor 
		~TestClass () 
		{
			printf ("In destuctor:this:%p\n", this); 	
			//free (this); // generates segmentation fault 
		       		     // if destructor gets invoked 
				     // because of delete function. 
				     // Explicit call to destructor 
				     // like ptr->~TestClass () will 
				     // on the other hand *REQUIRE* 
				     // call to free function in order 
				     // to reclaim heap memory 	
		}
		// Display object state
		void display (void) const 
		{
			std::cout << "i_num:" << i_num << std::endl 
				  << "c_ans:" << c_ans << std::endl 
				  << "d_num:" << d_num << std::endl 
			 	 << "s_str:" << s_str << std::endl; 
		}
	private:
		int i_num; 
		char c_ans; 
		double d_num; 
		std::string s_str; 
}; 

TestClass *get_testclass_instance (void); 
void test_function_one (TestClass *ptr); 

int main (void) 
{

	TestClass *ptr; 

	std::cout << "main:Enter" << std::endl;
	ptr = get_testclass_instance (); 
	test_function_one (ptr); 	
	std::cout << "main:Leave" << std::endl; 

	delete ptr; 

	return (EXIT_SUCCESS); 
}

TestClass *get_testclass_instance (void) 
{
	return (new TestClass (10, 'A', 3.14, std::string ("Hello"))); 
}

void test_function_one (TestClass *ptr) 
{
	std::cout << "test_function_one:Enter" << std::endl; 
	ptr->display (); 
	std::cout << "test_function_one:Leave" << std::endl; 
}
#include <iostream> 
#include <cstdlib> 
#include <typeinfo> 

#define NR_DERIVED_CLASSES 4 

class Base{
public: 
	Base () {} 
	virtual ~Base() {} 
	virtual void f(void) {std::cout << "Base f" << std::endl;}
	void x(void) {std::cout << "Base x" << std::endl;}
}; 

class D1 : public Base{
public:
	D1() {} 
	~D1(){} 
	void f(void) {std::cout << "D1 f" << std::endl;}
	void g1(void) {std::cout << "D1 g1" << std::endl;}
	void x(void) {std::cout << "D1 x" << std::endl;}
}; 

class D2 : public Base{
public:
	D2() {} 
	~D2(){} 
	void f(void) {std::cout << "D2 f" << std::endl;}
	void g2(void) {std::cout << "D2 g2" << std::endl;}
}; 

class D3 : public Base{
public:
	D3() {} 
	~D3(){} 
	void f(void) {std::cout << "D3 f" << std::endl;}
	void g3(void) {std::cout << "D3 g3" << std::endl;}
}; 

class D4 : public Base{
public:
	D4() {} 
	~D4(){} 
	void f(void) {std::cout << "D4 f" << std::endl;}
	void g4(void) {std::cout << "D4 g4" << std::endl;}
}; 

int main(void)
{
	Base *ptr1, *ptr2 = new D1(); 
	D1 *dptr = new D1(); 
	
	std::cout << "ptr2:" << std::endl; 
	ptr2->f(); 
	ptr2->x(); 

	static_cast<Base*>(ptr2)->f(); 
	static_cast<Base*>(ptr2)->x(); 
	
	dynamic_cast<Base*>(ptr2)->f(); 
	dynamic_cast<Base*>(ptr2)->x(); 
	std::cout << "ptr2 end" << std::endl; 

	static_cast<Base*>(dptr)->x(); // non polymorphic
	static_cast<Base*>(dptr)->f(); // polymorphic 
	
	srand(time(0)); 

	switch(rand() % NR_DERIVED_CLASSES){
		case 0: 
			ptr1 = new D1();
			break; 
		case 1: 
			ptr1 = new D2(); 
			break; 
		case 2: 
			ptr1= new D3(); 
			break; 
		case 3: 
			ptr1 = new D4(); 
			break; 
	}
	 

	if(typeid (*ptr1) == typeid(D1)) {
		ptr1->f(); 
		static_cast<D1*>(ptr1)->g1(); 	
	}
	else if(typeid(*ptr1) == typeid(D2)) {
		ptr1->f(); 
		dynamic_cast<D2*>(ptr1)->g2(); 
	}
	else if(typeid(*ptr1) == typeid(D3)){
		ptr1->f(); 
		dynamic_cast<D3*>(ptr1)->g3(); 
	}
	else if(typeid(*ptr1) == typeid(D4)){
		ptr1->f(); 
		dynamic_cast<D4*>(ptr1)->g4(); 
	}
	else{
		std::cout << "ERROR" << std::endl; 
	}

	delete ptr1; 

	return 0; 
}
#include <iostream> 
#include <cstdlib> 

class X{
public: 
	X() {} 
	~X() {} 
	virtual void f(void) {std::cout << "I am in X-f" << std::endl;}

}; 

class Y : public X{
public: 
	Y(){}
	~Y() {} 
	void f(void) {std::cout << "I am in Y-f" << std::endl;}
};

int main(void)
{
	Y *ptr1 = new Y(); 
	static_cast<X*>(ptr1)->f(); 

	delete ptr1; 
	return EXIT_SUCCESS; 
}#include <iostream> 

template <typename T> 
class Interface
{
	pub
}; 

class Int:public Interface
{
	public: 
			Int(int _a, int _b) : a(_a), b(_b) {} 
			void add (int &x, int &y) {std::cout << "a+b:" << x+y << std::endl;} 
	private:
			int a, b; 
}; 

int main(void) 
{
	Interface *ptr = new Int(10, 20); 
	int n1=100, n2=300; 
	ptr->add(n1, n2); 

	return(0); 
}
#include <iostream> 
#include <cstdio> 
#include <cstdlib> 

class T
{
public: 
	// Default constructor 
	T () 
	{
		std::cout << "In default constructor" << std::endl; 
	} 

	// Explicit constructor using constructor initializer list apporach 
	T (int i, char c, double d) : i_num (i), c_ans (c), d_num (d) 
	{
		std::cout << " Explicit constructor using constructor initializer list apporach"
				  << std::endl; 
	} 

	// Copy constructor 1
	T (const T &ref)
	{
		std::cout << "In Copy constructor 1" << std::endl; 
		i_num = ref.i_num; 
		c_ans = ref.c_ans; 
		d_num = ref.d_num; 
	}

	// Copy constructor 2
	T (const T *ptr)
	{
		std::cout << "In Copy constructor 2" << std::endl; 
		this->i_num = ptr->i_num; 
		this->c_ans = ptr->c_ans; 
		this->d_num = ptr->d_num; 
	}

	// overloaded assignment constructor 1 
	T &operator= (const T &ref)
	{
		std::cout << "Overloaded copy constructor 1" << std::endl; 
		this->i_num = ref.i_num; 
		this->c_ans = ref.c_ans; 
		this->d_num = ref.d_num; 
		return *this; 	
	}

	int get_int (void) const {return i_num;}

private:
	int i_num; 
	char c_ans;
	double d_num; 
}; 

int main (void)
{
	T t1 (10, 'A', 3.14); // Explicit constructor 
	T *pt = new T (100, 'Z', 6.28); // Explicit constructor 
	T t2 (t1); // Copy constructor 1 
	T t3 (*pt); // Copy constructor 1 
	T *ptr = new T (pt); // Copy constructor 2
	T t4 (pt); // Copy constructor 2 
	T t5; // Default constructor 
	T *t6 = new T (t1); // Copy Constructor 1 

	t5 = t2; // Overloaded operator 1 
	std::cout << "t5.get_int ():" << t5.get_int () << std::endl; 

	return (EXIT_SUCCESS);
}#include <iostream> 
#include <cstdlib> 

class Interface 
{
public:
	virtual Interface &add (Interface &other) = 0; 
	virtual Interface &sub (Interface &other) = 0 ; 
}; 

class Complex : public Interface 
{
	public: 
		Complex (double re=0.0, double im=0.0) : _re (re), _im (im) {}

		Complex &add (Complex &other) 
		{
			return *(new Complex (this->_re + other._re,
					      this->_im + other._im)); 
		}

		Complex &sub (Complex &other)
		{
			return *(new Complex (this->_re - other._re, 
					      this->_im - other._im)); 
		}
			
	private:
		double _re, _im; 
}; 

int main (void) 
{
	Interface *obj1 = new Complex (10.5, 12.5); 
	Interface *obj2 = new Complex (30.5, 40.5); 
	

	return (EXIT_SUCCESS); 
}

#include <iostream> 
#include <cstdio> 
#include <cstdlib> 

int swap1 (int *p1, int *p2); 
int swap2 (int &ref_n1, int &ref_n2);

int main (void)
{	
	int n1=10, n2=20; 
	printf("A(n1):%p A(n2):%p\n", &n1, &n2); 
	printf ("Before swap:n1:%d n2:%d\n", n1, n2); 
	swap1 (&n1, &n2); 
	printf ("After swap:n1:%d n2:%d\n", n1, n2); 
	swap2 (n1, n2); 
	printf ("After swap:n1:%d n2:%d\n", n1, n2); 

	return (EXIT_SUCCESS); 
}

int swap1 (int *p1, int *p2)
{
	std::cout << "Pointer swap" << std::endl; 
	printf ("A(p1):%p A(p2):%p\n", &p1, &p2);
	int tmp = *p1; 
	*p1 = *p2; 
	*p2 = tmp; 
}

int swap2 (int &ref_n1, int &ref_n2)
{
	std::cout << "Reference swap:" << std::endl; 
	printf ("ref_n1:%p, ref_n2:%p\n", &ref_n1, &ref_n2);
	int tmp = ref_n1; 
	ref_n1 = ref_n2; 
	ref_n2 = tmp;  
}
#include <iostream>

class CHasPtr
{
	private:
		int *ptr;
		int ref_cnt;
	public:	
		CHasPtr (int ptr_val)
		{
			ptr = new int (ptr_val);
		}
		~CHasPtr ()
		{
			delete ptr;
		}
		
		int *get_ptr (void) const { return (ptr); }
		int get_ptr_val (void) const { return (*ptr); }
		int get_ref_cnt (void) const { return (ref_cnt); }
		
		void init_ref_cnt (void)  { ref_cnt = 1; }
		void add_ref_cnt (void) { ref_cnt++; }
		void release_ref_cnt (void) { ref_cnt--; }
};

class T
{
	public:
		//default contructor
		T () 
		{
			std::cout << "Default constructor" << std::endl;
		}
		// Explicite contructor
		T (int n, int ptr_val) 
		{
			std::cout << "Explicite Constructor" << std::endl;
			this->i_num = n;				
			this->hPtr = new CHasPtr (ptr_val);
			this->hPtr->init_ref_cnt ();
		}
		// copy constructor 1
		T (const T& ref) 
		{
			std::cout << "Copy constructor1" << std::endl;
			this->i_num = ref.i_num;
			this->hPtr = ref.hPtr;
			this->hPtr->add_ref_cnt ();
		}
		// operator overloade constructor
		T& operator= (const T& ref)
		{
			std::cout << "Operator overloaded constructor" << std::endl;
			this->i_num = ref.i_num;
			this->hPtr = ref.hPtr;
			this->hPtr->add_ref_cnt ();
		} 
		
		int get_int (void) const { return (this->i_num); }
		int *get_ptr (void) const {  }
		int get_ptr_val (void) const  {  }

		void set_int (int n) { i_num = n; }
		void set_ptr (int *ptr) { }
		void set_ptr_val (int new_ptr_val) { }		
		
		void display (void) const;
		
		~T() 
		{
			this->hPtr->release_ref_cnt ();
			if (this->hPtr->get_ref_cnt () < 1)
			{
				delete this->hPtr;
				std::cout << "Destructor: integer distroyed" << std::endl;
			}
			else
			{
				std::cout << "Destructor: integer can not be distroyed: shared by:" << this->hPtr->get_ref_cnt ()
					  << " objects" << std::endl;
			}
		}
	private:
		int i_num;
		CHasPtr *hPtr;
};

void T::display (void) const
{
	std::cout << "integer:" << this->get_int () << std::endl
		  << "ptr:" << this->hPtr->get_ptr () << std::endl
		  << "ptr_val:" << this->hPtr->get_ptr_val () << std::endl
		  << "->ref_cnt:" << this->hPtr->get_ref_cnt () << std::endl << std::endl;
}

int main (void)
{
	T t1(10, 20);
	t1.display ();

	T t2 (t1); 
	t2.display ();

	T t3 (t2);
	t3.display ();

	T t4 (t3);
	t4.display ();

	T t5 (t4);
	t5.display ();



/*	T *t3 = new T (100, 200);
	t3->display ();
	T *t4 = new T ();
	*t4 = *t3;
	t4->display ();	
	delete t3;
	delete t4;
*/
	return (0);
}
#include <vector>
#include <iostream>
 
struct B {
    int m;
    void hello() const {
        std::cout << "Hello world, this is B!\n";
    }
};
struct D : B {
    void hello() const {
        std::cout << "Hello world, this is D!\n";
    }
};
 
 
int main()
{
    // 1: initializing conversion
    int n = static_cast<int>(3.14); 
    std::cout << "n = " << n << '\n';

    // 2: static downcast
    D d;
    B& br = d; // upcast via implicit conversion
    br.hello();
    D& another_d = static_cast<D&>(br); // downcast
    another_d.hello();
 
    return 0; 
}
einclude <iostream> 
#include <cstdlib> 
#include <typeinfo> 

class X{
public:
	X() {} 
	~X() {} 
	virtual void f(void) {std::cout << "I am in X-f" << std::endl;}
}; 

class Y : public X{
public:
	Y() {} 
	~Y() {}
	void f(void) {std::cout << "I am in Y-f" << std::endl;}
	void g(void) {std::cout << "I am in Y-g" << std::endl;}
}; 

int main(void)
{
	X *ptr = new X(); 
	// ptr->g();  // Compile time error 
	std::cout << "typeid(*ptr):" << typeid(*ptr).name() << std::endl; 
	std::cout << "typeid(*(reinterpret_cast<Y*>(ptr)).name():" 	<< 
				  typeid(*(reinterpret_cast<Y*>(ptr))).name() 	<< std::endl <<
				 // "typeid(*(dynamic_cast<Y*>(ptr)).name():" 	<< 
				 // typeid(*(dynamic_cast<Y*>(ptr))).name() 	<< 
				  "typeid(*(static_cast<Y*>(ptr)).name():" 		<< 
				  typeid(*(static_cast<Y*>(ptr))).name() 		<< std::endl; 
	reinterpret_cast<Y*>(ptr)->f(); 
	reinterpret_cast<Y*>(ptr)->g(); 
	delete ptr; 
	return (EXIT_SUCCESS); 
}
#include <iostream> 
#include <cstdlib> 

template <typename T> 
class Interface 
{
public:
	virtual  T &add (T&) = 0; 
	virtual T &sub (T&) = 0; 
}; 

class Complex : public Interface 
{
	public: 
		Complex (double re=0.0, double im=0.0) : _re (re), _im (im) {}

		Complex &add (Complex &other) 
		{
			return *(new Complex (this->re + other.re
					      this->im + other.im)); 
		}

		Complex &sub (Complex &other)
		{
			return *(new Complex (this->re - other.re, 
					      this->im - other.im)); 
		}
			
	private:
		double _re, _im; 
}; 

int main (void) 
{
	Interface *obj1 = new (Interface <Complex>) (10.5, 20.5); 
	Interface *obj2 = new (Interface <Complex>)  (30.5, 40.5); 
	

	return (EXIT_SUCCESS); 
}

#include <iostream> 
#include <cstdlib> 

class Interface 
{
public:
	template <typename T> 
	virtual T &add (T &other) = 0; 
	
	template <typename T> 
	virtual T &sub (T &other) = 0; 
}; 

class Complex : public Interface 
{
	public: 
		Complex (double re=0.0, double im=0.0) : _re (re), _im (im) {}

		Complex &add (Complex &other) 
		{
			return *(new Complex (this->_re + other._re,
					      this->_im + other._im)); 
		}

		Complex &sub (Complex &other)
		{
			return *(new Complex (this->_re - other._re, 
					      this->_im - other._im)); 
		}
			
	private:
		double _re, _im; 
}; 

int main (void) 
{
	Interface *obj1 = new Complex (10.5, 12.5); 
	Interface *obj2 = new Complex (30.5, 40.5); 
	

	return (EXIT_SUCCESS); 
}

#include <iostream> 
#include <cstdlib> 

class Interface 
{
	virtual Interface &operator+ (Interface &other) = 0; 

}; 

class Complex : public Interface
{
public: 
	~Complex () {std::cout << "I am here" << std::endl; } 
	Complex (double re_in=0.0, double im_in=0.0) : re (re_in), im (im_in) {} 
	Interface &operator+ (Interface &other)
	{
		double tmp_re, tmp_im; 
		tmp_re = dynamic_cast <Complex*> (this)->re + dynamic_cast <Complex &> (other).re; 
		tmp_im = dynamic_cast <Complex*> (this)->im + dynamic_cast <Complex &> (other).im;
		Complex *rs = new Complex (tmp_re, tmp_im); 
		return (*rs);
	}
	void display (void)
	{
		std::cout << "re:" << re << " im:" << im << std::endl; 
	}
private:
	double re, im; 
}; 

class Vector : public Interface
{
private:
	double x, y, z; 
}; 

int main (void) 
{
	Complex c1(10.5, 20.5), c2(30.5, 40.5); 
	c1.display (); 
	c2.display (); 
	Complex &sum = dynamic_cast<Complex&> (c1 + c2); 
	sum.display (); 
	delete (&sum); 
	return (EXIT_SUCCESS); 
}
#include <iostream> 
#include <cstdlib> 
#include <typeinfo> 

class Base 
{
public:
	Base () {} 
	~Base () {} 
	virtual void f (void)
	{std::cout << "I am in base" << std::endl;}

}; 

class Derived : public Base {
public:
	Derived () {} 
	~Derived() {} 
	void f (void)
	{std::cout << "I am in derived" << std::endl; }

}; 

int main(void)
{
	Base *ptr1 = new Base (), *ptr2 = new Derived(); 
	std::cout << "typeid(*ptr1).name():" << typeid(*ptr1).name() << std::endl; 
	std::cout << "typeid(*ptr2).name():" << typeid(*ptr2).name() << std::endl; 

	return 0; 
}
#include <iostream> 
#include <cstdlib> 
#include <typeinfo> 

int main(void)
{
	int i=0; 
	std::cout << typeid(i).name() << std::endl; 
	return 0; 
}