#include <iostream> 
#include <cstdlib> 

class X{
public: 
	X() {} 
	~X() {} 
	virtual void f(void) {std::cout << "I am in X-f" << std::endl;}

}; 

class Y : public X{
public: 
	Y(){}
	~Y() {} 
	void f(void) {std::cout << "I am in Y-f" << std::endl;}
};

int main(void)
{
	Y *ptr1 = new Y(); 
	static_cast<X*>(ptr1)->f(); 

	delete ptr1; 
	return EXIT_SUCCESS; 
}