#include <iostream> 
#include <cstdlib> 

template <typename T> 
class Interface 
{
public:
	virtual  T &add (T&) = 0; 
	virtual T &sub (T&) = 0; 
}; 

class Complex : public Interface 
{
	public: 
		Complex (double re=0.0, double im=0.0) : _re (re), _im (im) {}

		Complex &add (Complex &other) 
		{
			return *(new Complex (this->re + other.re
					      this->im + other.im)); 
		}

		Complex &sub (Complex &other)
		{
			return *(new Complex (this->re - other.re, 
					      this->im - other.im)); 
		}
			
	private:
		double _re, _im; 
}; 

int main (void) 
{
	Interface *obj1 = new (Interface <Complex>) (10.5, 20.5); 
	Interface *obj2 = new (Interface <Complex>)  (30.5, 40.5); 
	

	return (EXIT_SUCCESS); 
}

