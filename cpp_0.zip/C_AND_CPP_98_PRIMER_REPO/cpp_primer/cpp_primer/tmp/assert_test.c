#include <stdio.h> 
#include <stdlib.h> 
#include <assert.h> 
#include <unistd.h> 
#include <signal.h> 

void sig_handler(int sig_num); 

int main(void) 
{
	int i = 0; 

	signal(SIGABRT, SIG_IGN); 

	assert(i != 0); 

	exit(EXIT_SUCCESS); 
}

void sig_handler(int sig_num)
{
	printf("Assertion failure has occured\n"); 
}
