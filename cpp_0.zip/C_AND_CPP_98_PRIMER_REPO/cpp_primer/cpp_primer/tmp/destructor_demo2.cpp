#include <iostream> 
#include <string> 
#include <cstdlib> 
#include <cstdio> 

class TestClass 
{
	public:
		// Default 
		TestClass () : i_num(0), c_ans('\0'), d_num(0.0) {} 
		// Explicit 
		TestClass (int i_num, char c_ans, double d_num, std::string s_str) 
		{
			this->i_num = i_num; 
			this->c_ans = c_ans; 
			this->d_num = d_num; 
			this->s_str = s_str; 
			printf ("constructor:%p\n", this); 
		}
		// Copy 
		TestClass (const TestClass &ref_testclass_obj)
		{
			this->i_num = ref_testclass_obj.i_num; 
			this->c_ans = ref_testclass_obj.c_ans; 
			this->d_num = ref_testclass_obj.d_num; 
			this->s_str = ref_testclass_obj.s_str; 
		}
		// Destructor 
		~TestClass () 
		{
			printf ("In destuctor:this:%p\n", this); 	
			//free (this); // generates segmentation fault 
		       		     // if destructor gets invoked 
				     // because of delete function. 
				     // Explicit call to destructor 
				     // like ptr->~TestClass () will 
				     // on the other hand *REQUIRE* 
				     // call to free function in order 
				     // to reclaim heap memory 	
		}
		// Display object state
		void display (void) const 
		{
			std::cout << "i_num:" << i_num << std::endl 
				  << "c_ans:" << c_ans << std::endl 
				  << "d_num:" << d_num << std::endl 
			 	 << "s_str:" << s_str << std::endl; 
		}
	private:
		int i_num; 
		char c_ans; 
		double d_num; 
		std::string s_str; 
}; 

TestClass *get_testclass_instance (void); 
void test_function_one (TestClass *ptr); 

int main (void) 
{

	TestClass *ptr; 

	std::cout << "main:Enter" << std::endl;
	ptr = get_testclass_instance (); 
	test_function_one (ptr); 	
	std::cout << "main:Leave" << std::endl; 

	delete ptr; 

	return (EXIT_SUCCESS); 
}

TestClass *get_testclass_instance (void) 
{
	return (new TestClass (10, 'A', 3.14, std::string ("Hello"))); 
}

void test_function_one (TestClass *ptr) 
{
	std::cout << "test_function_one:Enter" << std::endl; 
	ptr->display (); 
	std::cout << "test_function_one:Leave" << std::endl; 
}
