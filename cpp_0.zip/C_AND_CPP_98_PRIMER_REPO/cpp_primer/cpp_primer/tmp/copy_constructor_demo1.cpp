#include <iostream> 
#include <cstdlib> 

class TestClass 
{
	public: 
		// Default constructor 
		TestClass () : i_num (0), c_ans ('\0'), d_num (0.0) {} 

		// Explicit 
		TestClass (int i_num, char c_ans, double d_num) 
		{
			this->i_num = i_num; 
			this->c_ans = c_ans; 
			this->d_num = d_num; 
		} 

		// copy constructor 
		/*TestClass (const TestClass &ref_testclass_obj) 
		{
			i_num = ref_testclass_obj.i_num; 
			c_ans = ref_testclass_obj.c_ans; 
			d_num = ref_testclass_obj.d_num; 
		}*/ 

		void display (void) const 
		{
			std::cout << "i_num:" << i_num << std::endl
				  << "c_ans:" << c_ans << std::endl 
				  << "d_num:" << d_num << std::endl; 
		}

	private:
		int i_num; 
		char c_ans; 
		double d_num; 

}; 

TestClass t5 (30, 'C', 12.45); 
TestClass t1 (10, 'A', 3.14); 
TestClass t4 (20, 'B', 6.28); 

int main (void) 
{
	TestClass t2 (t1); 
	t2.display (); 
	TestClass *t3 = new TestClass (t1); 
	t3->display (); 
	return (EXIT_SUCCESS); 
}
