#include <stdio.h> 
#include <stdlib.h> 
#include <setjmp.h> 
#include <unistd.h> 
#include <sys/time.h> 

void f1(void); 
void f2(void); 
void f3(void); 

jmp_buf jump_buffer; 
int i; 

int main(void) 
{
	int ret; 

	ret = setjmp(jump_buffer); 	
	if(ret == 0)
	{
		printf("Set Jump Location Successfully\n"); 
	}
	else if(ret == 1)
	{
		printf("From f1\n"); 	
	}
	else if(ret == 2)
	{
		printf("From f2\n"); 
	}
	else if(ret == 3)
	{
		printf("From f3\n"); 
	}

	if(ret != 0)
		goto incr_i; 

	i = 0; 
	while(i < 10000)
	{
		printf("FOR i = %d\n", i); 
		f1(); 
		sleep(3); 
	incr_i:
		i++; 
	}

	return 0; 
}


void f1(void)
{
	printf("In f1\n"); 
	if(i % 4 == 0)
		longjmp(jump_buffer, 1); 
	f2(); 
}

void f2(void)
{
	printf("In f2\n"); 
	if(i % 7 == 0)
		longjmp(jump_buffer, 2); 
	f3(); 
}

void f3(void)
{
	printf("In f3\n"); 
	if(i % 3 == 0)
		longjmp(jump_buffer, 3); 
}
