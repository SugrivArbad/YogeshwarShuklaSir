#include <iostream> 
#include <cstdlib> 
#include <typeinfo> 

class Base 
{
public:
	Base () {} 
	~Base () {} 
	virtual void f (void)
	{std::cout << "I am in base" << std::endl;}

}; 

class Derived : public Base {
public:
	Derived () {} 
	~Derived() {} 
	void f (void)
	{std::cout << "I am in derived" << std::endl; }

}; 

int main(void)
{
	Base *ptr1 = new Base (), *ptr2 = new Derived(); 
	std::cout << "typeid(*ptr1).name():" << typeid(*ptr1).name() << std::endl; 
	std::cout << "typeid(*ptr2).name():" << typeid(*ptr2).name() << std::endl; 

	return 0; 
}
