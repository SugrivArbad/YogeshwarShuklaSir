#include <iostream> 
#include <cstdlib> 

class Interface 
{
	public: 
		virtual void f (void) = 0; 
}; 

void Interface::f (void) 
{
	std::cout << "Interface::f - I am here" << std::endl; 
}

class Implementation : public Interface
{
	public:
		Implementation () {} 
		void f (void) 
		{
			Interface::f (); 
			std::cout << "Implementation::f - I am here" << std::endl; 
		}
}; 

int main (void) 
{
	Interface *ptr = new Implementation (); 
	Interface *p = new Interface (); 
	ptr->f (); 
	delete ptr; 
	return (0); 
}
