#include <iostream> 
#include <cstdlib> 

template <typename T> 
T my_add (T a, T b)
{
	return (a+b); 
}

template <typename T> 
class Interface 
{
public: 
	 virtual T& Add (T&) = 0; 
}; 

class Complex : public Interface 
{
public: 
	Complex (double i_re=0.0, double i_im=0.0) : re (i_re), im (i_im) {} 
	Complex &Add (Complex &other)
	{
		double tmp_re = re + other.re; 
		double tmp_im = im + other.im; 
		Complex *ptr = new Complex (tmp_re, tmp_im); 
		return (*ptr);
	}
private:
	double re, im; 
}; 

int main (void)
{
	int i_rs;
	double d_rs;  

	i_rs = my_add (10, 20); 
	d_rs = my_add (10.10, 20.30); 
	std::cout << "i_rs:" << i_rs << " d_rs:" << d_rs << std::endl; 

	return 0; 

}