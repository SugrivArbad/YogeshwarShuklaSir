#include <iostream> 
#include <cstdlib> 

class Interface 
{
public:
	virtual void fun1 (void) = 0; 
	virtual ~Interface () {std::cout << "FOO" << std::endl;  }
}; 

class Implementation : public Interface 
{
public: 
	~Implementation () { std::cout << "HERE" << std::endl; }
	void fun1 (void)
	{
		std::cout << "In Implementation" << std::endl; 
	}
}; 

int main (void)
{
	Interface *iptr = new Implementation ();
	iptr->fun1 (); 
	delete iptr; 

	return EXIT_SUCCESS; 
}
