#include <iostream> 
#include <cstdlib> 

class Shape 
{
public: 
	virtual void draw (void) = 0; 
}; 

class Square : public Shape
{
public:
	Square () {} 
	void draw (void) 
	{
		std::cout << "In square draw" << std::endl; 
	}
}; 

class Rectangle : public Shape
{
public: 
	Rectangle () {} 
	void draw (void)
	{
		std::cout << "In rectangle draw" << std::endl; 
	}
}; 

int main (void)
{
	Shape *s1=new Square (), *s2=new Rectangle (); 
	s1->draw (); 
	s2->draw (); 

	return (0); 
}; 