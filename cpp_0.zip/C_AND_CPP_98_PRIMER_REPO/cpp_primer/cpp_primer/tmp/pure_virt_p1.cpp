#include <iostream> 
#include <cstdlib> 

class Interface 
{
public:
	virtual Interface &add (Interface &other) = 0; 
	virtual Interface &sub (Interface &other) = 0 ; 
}; 

class Complex : public Interface 
{
	public: 
		Complex (double re=0.0, double im=0.0) : _re (re), _im (im) {}

		Complex &add (Complex &other) 
		{
			return *(new Complex (this->_re + other._re,
					      this->_im + other._im)); 
		}

		Complex &sub (Complex &other)
		{
			return *(new Complex (this->_re - other._re, 
					      this->_im - other._im)); 
		}
			
	private:
		double _re, _im; 
}; 

int main (void) 
{
	Interface *obj1 = new Complex (10.5, 12.5); 
	Interface *obj2 = new Complex (30.5, 40.5); 
	

	return (EXIT_SUCCESS); 
}

