#include <iostream> 
#include <cstdio> 
#include <cstdlib> 

class T
{
public: 
	// Default constructor 
	T () 
	{
		std::cout << "In default constructor" << std::endl; 
	} 

	// Explicit constructor using constructor initializer list apporach 
	T (int i, char c, double d) : i_num (i), c_ans (c), d_num (d) 
	{
		std::cout << " Explicit constructor using constructor initializer list apporach"
				  << std::endl; 
	} 

	// Copy constructor 1
	T (const T &ref)
	{
		std::cout << "In Copy constructor 1" << std::endl; 
		i_num = ref.i_num; 
		c_ans = ref.c_ans; 
		d_num = ref.d_num; 
	}

	// Copy constructor 2
	T (const T *ptr)
	{
		std::cout << "In Copy constructor 2" << std::endl; 
		this->i_num = ptr->i_num; 
		this->c_ans = ptr->c_ans; 
		this->d_num = ptr->d_num; 
	}

	// overloaded assignment constructor 1 
	T &operator= (const T &ref)
	{
		std::cout << "Overloaded copy constructor 1" << std::endl; 
		this->i_num = ref.i_num; 
		this->c_ans = ref.c_ans; 
		this->d_num = ref.d_num; 
		return *this; 	
	}

	int get_int (void) const {return i_num;}

private:
	int i_num; 
	char c_ans;
	double d_num; 
}; 

int main (void)
{
	T t1 (10, 'A', 3.14); // Explicit constructor 
	T *pt = new T (100, 'Z', 6.28); // Explicit constructor 
	T t2 (t1); // Copy constructor 1 
	T t3 (*pt); // Copy constructor 1 
	T *ptr = new T (pt); // Copy constructor 2
	T t4 (pt); // Copy constructor 2 
	T t5; // Default constructor 
	T *t6 = new T (t1); // Copy Constructor 1 

	t5 = t2; // Overloaded operator 1 
	std::cout << "t5.get_int ():" << t5.get_int () << std::endl; 

	return (EXIT_SUCCESS);
}