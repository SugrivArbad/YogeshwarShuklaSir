#include <iostream> 
#include <cstdlib> 

class Interface 
{
	virtual void add (Interface *other, void **ret) = 0; 

}; 

class Complex : public Interface
{
public: 
	~Complex () {std::cout << "I am here" << std::endl; } 
	Complex (double re_in=0.0, double im_in=0.0) : re (re_in), im (im_in) {} 
	void add (Interface *other, void **ret)
	{
		double tmp_re, tmp_im; 
		tmp_re = dynamic_cast <Complex*> (this)->re + dynamic_cast <Complex *> (other)->re; 
		tmp_im = dynamic_cast <Complex*> (this)->im + dynamic_cast <Complex *> (other)->im;
		*(Complex**)ret = new Complex (tmp_re, tmp_im); 

	}
	void display (void)
	{
		std::cout << "re:" << re << " im:" << im << std::endl; 
	}
private:
	double re, im; 
}; 

class Vector : public Interface
{
private:
	double x, y, z; 
}; 

int main (void) 
{
	Complex c1(10.5, 20.5), c2(30.5, 40.5), *sum; 

	c1.display (); 
	c2.display (); 
	
	c1.add (&c2, (void**)&sum); 

	sum->display (); 
	delete (sum); 

	return (EXIT_SUCCESS); 
}
