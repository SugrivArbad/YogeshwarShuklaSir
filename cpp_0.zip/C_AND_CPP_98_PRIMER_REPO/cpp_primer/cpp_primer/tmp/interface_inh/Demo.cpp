#include <iostream> 
#include <cstdlib> 
#include <ctime> 

class Operations
{
public:
	virtual void add(void) = 0; 
	virtual void sub(void) = 0; 
	virtual void mul(void) = 0; 
}; 

class Matrix : public Operations
{
private: 
		// Data required to support matrix's interpretation of add, 
		// sub, mul 
public: 
	Matrix() {} 
	void add(void) 
	{
		std::cout << "Matrix.add" << std::endl; 
	}

	void sub(void)
	{
		std::cout << "Matrix.sub" << std::endl; 
	}

	void mul(void) 
	{
		std::cout << "Matrix.mul" << std::endl; 
	}
}; 

class Vector : public Operations 
{
public:
		Vector(){}
		void add(void) 
		{
			std::cout << "Vector.add" << std::endl; 
		}

		void sub(void) 
		{
			std::cout << "Vector.sub" << std::endl; 
		}

		void mul(void) 
		{
			std::cout << "Vector.mul" << std::endl; 
		}
}; 

int main(void)
{
	Operations *p; 
	srand(time(0)); 
	for(int i = 0; i < 5; ++i)
	{
		if(rand() % 2) 
		{
			p = new Vector; 
			std::cout << "i:" << i << "Vectors turn" << std::endl; 
		}
		else
		{
			p = new Matrix; 
			std::cout << "i:" << i << "Matrix turn" << std::endl; 
		}

		p->add(); 
		p->sub(); 
		p->mul(); 
		std::cout << "----------------" << std::endl; 
	}	

	return 0; 
}
