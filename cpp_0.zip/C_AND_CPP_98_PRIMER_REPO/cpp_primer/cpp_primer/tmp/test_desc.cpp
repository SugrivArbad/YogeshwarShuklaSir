#include <iostream> 
#include <cstdlib> 

class Interface 
{
	virtual Interface &operator+ (Interface &other) = 0; 

}; 

class Complex : public Interface
{
public: 
	~Complex () {std::cout << "I am here" << std::endl; } 
	Complex (double re_in=0.0, double im_in=0.0) : re (re_in), im (im_in) {} 
	Interface &operator+ (Interface &other)
	{
		double tmp_re, tmp_im; 
		tmp_re = dynamic_cast <Complex*> (this)->re + dynamic_cast <Complex &> (other).re; 
		tmp_im = dynamic_cast <Complex*> (this)->im + dynamic_cast <Complex &> (other).im;
		Complex *rs = new Complex (tmp_re, tmp_im); 
		return (*rs);
	}
	void display (void)
	{
		std::cout << "re:" << re << " im:" << im << std::endl; 
	}
private:
	double re, im; 
}; 

class Vector : public Interface
{
private:
	double x, y, z; 
}; 

int main (void) 
{
	Complex c1(10.5, 20.5), c2(30.5, 40.5); 
	c1.display (); 
	c2.display (); 
	Complex &sum = dynamic_cast<Complex&> (c1 + c2); 
	sum.display (); 
	delete (&sum); 
	return (EXIT_SUCCESS); 
}
