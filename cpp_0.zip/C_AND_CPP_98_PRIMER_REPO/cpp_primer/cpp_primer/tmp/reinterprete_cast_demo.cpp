#include <iostream> 
#include <cstdlib> 

struct A{
	int a; 
	char b;
	int c; 
}; 

struct B{
	int A[5]; 
	long long int b; 
	int k; 
}inb; 

int main(void)
{
	(reinterpret_cast<struct A*>(&inb))->c = 500; 

	for(int i=0; i < 5; i++)
			std::cout << "inb.A[i]:" << inb.A[i] << std::endl; 

	return (EXIT_SUCCESS); 
}
