#ifndef _MY_HEADER_H 
#define _MY_HEADER_H 

#include <iostream> 

namespace X{
	int x = 10; 
	void f(void) {std::cout << "I am in f" << std::endl;} 
	class A{
		private:
				int x; 
		public: 
				A () {} 
				A (int n) : x(n) {} 
				~A() {} 
				A(const A&other) {this->x = other.x;} 
				A &operator=(const A&other) {this->x = other.x; return (*this);} 
				int get_x(void) const {return (x);} 
				void set_x(int new_x) {x = new_x;} 
	}; 
}; 


#endif /* _MY_HEADER_H */ 
