#include <iostream> 
#include <cstdlib> 
#include "my_header.h" 

int main(void)
{
	std::cout << "X::x:" << X::x << std::endl; 
	X::f(); 
	X::A *ptr = new X::A(10); 
	std::cout << "ptr->get_x():" << ptr->get_x() << std::endl; 
	ptr->set_x(100); 
	std::cout << "ptr->get_x():" << ptr->get_x() << std::endl; 
	return (0); 

}
