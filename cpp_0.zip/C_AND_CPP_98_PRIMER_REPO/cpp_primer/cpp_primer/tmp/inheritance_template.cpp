#include <iostream> 

template <typename T> 
class Interface
{
	pub
}; 

class Int:public Interface
{
	public: 
			Int(int _a, int _b) : a(_a), b(_b) {} 
			void add (int &x, int &y) {std::cout << "a+b:" << x+y << std::endl;} 
	private:
			int a, b; 
}; 

int main(void) 
{
	Interface *ptr = new Int(10, 20); 
	int n1=100, n2=300; 
	ptr->add(n1, n2); 

	return(0); 
}
