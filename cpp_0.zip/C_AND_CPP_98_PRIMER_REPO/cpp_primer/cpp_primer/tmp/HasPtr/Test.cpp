class TestClass 
{
	public:
		TestClass () {} 
		TestClass (const TestClass &ref) 
		{
			i_num = ref.i_num; 
			c_ans = ref.c_ans; 
			f_num = ref.f_num; 
		}
	private:
		int i_num; 
		char c_ans; 
		float f_num; 
}; 

int main (void) 
{
	TestClass t;  
	TestClass t1 (t); 

	return (0); 
}
