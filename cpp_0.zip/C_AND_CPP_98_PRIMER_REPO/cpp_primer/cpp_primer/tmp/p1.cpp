class Interface1{
	virtual void f1(void) = 0; 
	virtual void f2(void) = 0; 
}; 

class Interface2{
	virtual void f3(void) = 0; 
	virtual void f4(void) = 0; 
}; 

class C : public Interface1 , public Interface2
{
	private: 
			int n1, n2; 
	public: 

	void f1(void) { std::cout << "Inside f1" << std::endl; } 
	void f2(void) { std::cout << "Inside f2" << std::endl; } 
	void f3(void) { std::cout << "Inside f3" << std::endl; }
	void f4(void) { std::cout << "Inside f4" << std::endl; } 
}; 

new C ---	-------------------
			vtable ptr 				&f1 --------->  TEXT
			------------------
			n1						&f2---------->  TEXT
			------------------
			n2						&f3---------->	TEXT
			------------------
									&f4---------> 	TEXT

class Interface
{
	virtual void f1(void) = 0;
	virtual void f2(void) = 0; 
	virtual void f3(void) = 0; 
	virtual void f4(void) = 0; 
}; 

class D1 : public Interface
{
	f1() {} 
	f2() {} 
	f3() {} 
	f4() {} 
}; 

class D2 : public Interface
{
	f1() {} 
	f2() {} 
	f3() {} 
	f4() {} 

}; 


D1 *p1 = new D1;  			A(vtable ptr)-------------------
							vtable ptr
							DATA						-------------------
													D1-f1
													-------------------
													D1-f2
													-------------------
													D1-f3
													-------------------
													D1-f4
													-------------------

D2 *p2 = new D2;			A(vtable ptr)------------------
							vtable ptr
							DATA					------------------
													D2-f1
													------------------
													D2-f2
													-----------------
													D2-f3
													------------------
													D2-f4
													-----------------


Interface *p = p2; 
p = p1; 

(**p)[1](); 
