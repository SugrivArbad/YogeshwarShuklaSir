#include <iostream> 
#include <cstdio> 
#include <cstdlib> 

int swap1 (int *p1, int *p2); 
int swap2 (int &ref_n1, int &ref_n2);

int main (void)
{	
	int n1=10, n2=20; 
	printf("A(n1):%p A(n2):%p\n", &n1, &n2); 
	printf ("Before swap:n1:%d n2:%d\n", n1, n2); 
	swap1 (&n1, &n2); 
	printf ("After swap:n1:%d n2:%d\n", n1, n2); 
	swap2 (n1, n2); 
	printf ("After swap:n1:%d n2:%d\n", n1, n2); 

	return (EXIT_SUCCESS); 
}

int swap1 (int *p1, int *p2)
{
	std::cout << "Pointer swap" << std::endl; 
	printf ("A(p1):%p A(p2):%p\n", &p1, &p2);
	int tmp = *p1; 
	*p1 = *p2; 
	*p2 = tmp; 
}

int swap2 (int &ref_n1, int &ref_n2)
{
	std::cout << "Reference swap:" << std::endl; 
	printf ("ref_n1:%p, ref_n2:%p\n", &ref_n1, &ref_n2);
	int tmp = ref_n1; 
	ref_n1 = ref_n2; 
	ref_n2 = tmp;  
}
