#include <iostream> 

using namespace std; 

class X 
{
	public: 
		int a; 
		void f (int b) 
		{
			cout << b << endl; 
		}

};

int main (void) 
{
	int X::*ptr = & X::a; 

	X x1; 
	X *xptr = new X (); 

	x1.*ptr = 100; 
	xptr->*ptr = 200; 

	cout << "x1.*ptr:" << x1.*ptr << endl; 
	cout << "xptr->a:" << xptr->a << endl; 

	return (0); 
}
