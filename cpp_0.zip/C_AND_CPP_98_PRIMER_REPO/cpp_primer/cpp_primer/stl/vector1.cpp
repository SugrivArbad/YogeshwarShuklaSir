#include <iostream> 
#include <vector> 

std::vector<int> ivec; 

int main(){
	for(int i = 0; i < 10; i++){
		ivec.push_back(i * 10); 
	}

	for(int i = 0; i != ivec.size(); ++i)
		std::cout << ivec[i] << std::endl; 

	std::vector<int>::iterator iter; 
	iter = ivec.begin(); 
	while(iter != ivec.end()){
		// do something on iter 
		std::cout << *iter << std::endl; 
		++iter; 
	}

	for(std::vector<int>::iterator iter = ivec.begin(); 
		iter != ivec.end(); 
		++iter){
		std::cout << *iter << std::endl; 
	}

	return 0; 
}