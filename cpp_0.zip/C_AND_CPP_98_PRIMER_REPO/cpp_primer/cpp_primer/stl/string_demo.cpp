#include <iostream> 
#include <string> 

void display_using_index (std::string &s); 
void display_using_iterator (std::string &s); 

int main (void) 
{
	std::string s1 ("Hello"); 
	std::string s2 ("World"); 
	std::string s3 (s2); 
	std::string s5 (10, 'A'); 
	std::string line (60, '-'); 

	std::cout << line << std::endl << "Displaying s1 by index:" << std::endl; 
	display_using_index (s1); 
	std::cout << line << std::endl; 

	std::cout << "Displaying s2 by iterator" << std::endl; 
	display_using_iterator (s2);
	std::cout << line << std::endl; 
	
	std::string s6 = s1 + s2; 
	std::cout << s6 << std::endl; 
	std::cout << s5 << std::endl << line << std::endl; 

	std::string s7 (s1, 1, 4); 
	std::cout << "s7(s1, 1, 4):" << s7 << std::endl << line << std::endl; 

	std::string s8 ("This is an arbitrarily long string which does not server any purpose"); 
	std::string s9 (s8, 15, 6); 
	std::cout << "s9 (s8, 15, 6):" << s9 << std::endl << line << std::endl; 

	return 0; 
}

void display_using_index (std::string &s)
{
	for (std::string::size_type i = 0; i != s.size (); i++)
	{
		std::cout << "s[" << i << "]:" << s[i] << std::endl; 
	}

}

void display_using_iterator (std::string &s)
{
	for (std::string::iterator iter = s.begin (); iter != s.end (); ++iter)
		std::cout << "*iter:" << *iter << std::endl; 
}

/*
void display_using_index(char *s)
{
	int i; 

	for(i = 0; s[i] != '\0'; i++)
		s[i]

	for(i = 0; i < strlen(s); i++)
}
/* 
namespace std
{
	class string 
	{
		public: 
			typedef unsigned long int size_type; 
	}; 

}; 

std::string::size_type i; 

namespace std
{
	class string
	{

		class iterator
		{
			iterator() {} 
		};

		iterator &begin(void) const; 

		iterator &end(void) const; 
	}; 

}; 

void f(void)
{
	std::string s("Hello"); 
	std::string::iterator iter1, iter2; 

	iter1 = s.begin(); 
	iter2 = s.end(); 
}
*/
