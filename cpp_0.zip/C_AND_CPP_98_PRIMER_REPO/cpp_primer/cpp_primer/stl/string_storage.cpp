#include <iostream> 
#include <cstdlib> 
#include <string> 
#include <vector> 

int main(void)
{
	std::string s1("012345"); 
	std::string::iterator iter=s1.begin(); 
	std::string s2 = s1; 
	std::string &s3 = s1; 
	*iter = 'Z'; 
	std::cout << "s1:" << s1 << std::endl << "s2:" 
				<< s2 << std::endl << "s3:" << s3 << std::endl; 
	return(EXIT_SUCCESS); 
}