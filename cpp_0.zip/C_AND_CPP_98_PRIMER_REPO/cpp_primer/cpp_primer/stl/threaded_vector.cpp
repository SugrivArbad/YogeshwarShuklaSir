#include <iostream> 
#include <vector> 
#include <pthread.h> 
#include <unistd.h> 
#include <stdlib.h> 

void *thread1_entry (void*); 
void *thread2_entry (void*); 

std::vector<int> ivec(100000, 200); 

int main (void) 
{
	pthread_t th1, th2; 

	pthread_create (&th1, NULL, thread1_entry, NULL); 
	pthread_create (&th2, NULL, thread2_entry, NULL); 
	
	pthread_join (th1, NULL); 
	pthread_join (th2, NULL); 

	return 0; 
}

void *thread1_entry (void *args) 
{
	int cnt=100; 
	for (std::vector<int>::iterator iter = ivec.begin (); 
	     iter != ivec.end (); ++iter) 
	{
		*iter = cnt * 4; 
		sleep (3); 
	}
}

void *thread2_entry (void *args) 
{
	for (std::vector<int>::iterator iter = ivec.begin (); 
	     iter != ivec.end (); ++iter) 
	{
		std::cout << pthread_self ()  << ":" 
			  << *iter << std::endl; 
		sleep (2); 
	}
}
