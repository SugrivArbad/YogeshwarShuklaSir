#include <iostream> 
#include <string> 
#include <sstream> 
#include <vector> 
#include <cstdlib> 

int main (void) 
{
	std::string line; 
	while (getline (std::cin, line))
	{
		std::stringstream s_stream (line); 
		std::string word; 
		while (s_stream >> word)
		{
			std::cout << word << "\t" ; 
		}
		std::cout << std::endl; 
	}

	return (EXIT_SUCCESS); 
}
