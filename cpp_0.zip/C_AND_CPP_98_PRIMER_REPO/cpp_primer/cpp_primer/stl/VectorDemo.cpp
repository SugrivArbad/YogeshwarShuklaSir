#include <iostream>
#include <vector>
#include <string>

#define NR_INPUT_INTS 	5

void DisplayUsingIndex(std::vector<int> &iVec, const char *msg); 
void DisplayUsingIterator(std::vector<int> &iVec, const char *msg); 

int main(void)
{
	//	vector of integers 
	std::vector<int> iVec1; 
	std::vector<int> iVec2(10); 
	std::vector<int> iVec3(10, 100); 
	std::vector<int> iVec4(iVec3); 

	std::cout << "iVec1.size():" << iVec1.size() << std::endl 
				<< "iVec2.size():" << iVec2.size() << std::endl 
				<< "iVec3.size():" << iVec3.size() << std::endl 
				<< "iVec4.size():" << iVec4.size() << std::endl; 

	DisplayUsingIndex(iVec1, "iVec1:Using Index:"); 
	DisplayUsingIndex(iVec2, "iVec2:Using Index:"); 
	DisplayUsingIndex(iVec3, "iVec3:Using Index:"); 
	DisplayUsingIndex(iVec4, "iVec4:Using Index:"); 

	DisplayUsingIterator(iVec1, "iVec1:Using Iterator:"); 
	DisplayUsingIterator(iVec2, "iVec2:Using Iterator:"); 
	DisplayUsingIterator(iVec3, "iVec3:Using Iterator:"); 
	DisplayUsingIterator(iVec4, "iVec4:Using Iterator:"); 

	for(int i = 0; i != NR_INPUT_INTS; ++i)
		iVec1.push_back((i + 1) * 10); 

	DisplayUsingIndex(iVec1, "iVec1:After push_back:"); 

	return EXIT_SUCCESS: 
}

void DisplayUsingIndex(std::vector<int> &iVec, const char *msg)
{
	std::cout << msg << std::endl; 
	for(std::vector<int>::size_type i = 0; i != iVec.size(); ++i)
		std::cout << "iVec[" << i << "]:" << iVec[i] << std::endl; 
}

void DisplayUsingIterator(std::vector<int> &iVec, const char *msg)
{
	std::cout << msg << std::endl; 
	for(std::vector<int>::iterator iter = iVec.begin(); iter != iVec.end(); ++iter)
		std::cout << "*iter:" << *iter << std::endl; 
}
