#include <iostream> 
#include <vector> 

struct record 
{
	int i_num; 
	char c_ans; 
	float f_num; 
}; 

void display_vector_index (std::vector<int> &); 

int main (void) 
{
	std::vector<int> ivec1; 
	std::vector<int> ivec2(10); 

	std::cout << "ivec1:size:" << ivec1.size () << std::endl; 
	std::cout << "ivec2:size:" << ivec2.size () << std::endl; 

	for (int cnt=0; cnt < 10; cnt++) 
	{
		ivec1.push_back (cnt*4); 
		ivec2[cnt] = cnt * 5; 
	}

	std::cout << "Displaying ivec1:" << std::endl; 
	display_vector_index (ivec1); 
	std::cout << "Displaying ivec2:" << std::endl; 
	display_vector_index (ivec2); 

	std::vector<int> ivec3(ivec2); 
	std::cout << "Displaying ivec3:" << std::endl; 
	display_vector_index (ivec3); 

	std::vector<int>::iterator iter; 

	for (iter = ivec1.begin (); iter != ivec1.end (); ++iter) 
	{
		std::cout << *iter << std::endl; 
	}

	std::vector<struct record> ivec4 (3); 

	for (std::vector<struct record>::size_type ix=0; 
	     ix != ivec4.size (); ++ix) 
	{
		ivec4[ix].i_num = 100; 
		ivec4[ix].c_ans = 'A'; 
		ivec4[ix].f_num = 3.14; 
	}

	for (std::vector<struct record>::iterator iter = ivec4.begin (); 
	     iter != ivec4.end (); 
	     ++iter) 
	{
		std::cout << "Integer:" << iter->i_num << std::endl; 
		std::cout << "character:" << (*iter).c_ans << std::endl; 
		std::cout << "Float:" << iter->f_num << std::endl; 
	}

	std::vector<int>::iterator iter1 = ivec3.begin () + 1; 
	std::vector<int>::iterator iter2 = ivec3.end () - 2; 
	std::vector<int> ivec5 (iter1, iter2);  
	display_vector_index (ivec5); 


	std::vector <int> ivec6 (10, 100); 
       	display_vector_index (ivec6); 	

	std::vector<int>::iterator iter3=ivec6.begin () + 1; 
	std::vector<int>::iterator iter4=ivec3.end () - 2; 
	std::vector<int>::iterator iter5 = iter3 + iter4; 
	return 0; 
}

void display_vector_index (std::vector <int> &v)
{
	for (std::vector<int>::size_type ix=0; ix != v.size (); ++ix)
	{
		std::cout << "v[" << ix << "]:" << v[ix] << std::endl; 
	}
} 
