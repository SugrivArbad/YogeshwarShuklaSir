#include <iostream> 
#include <cstdlib> 

inline int get_num (void); 
inline int get_num (int cap); 

int main (void) 
{
	std::cout << "Printing first ten random numbers:" << std::endl; 
	for (int cnt=0; cnt < 10; cnt++) 
	{
		std::cout << get_num () << std::endl; 
	}	

	std::cout << "Printing first five random numbers with 25 cap:" << std::endl; 
	for (int cnt=0; cnt < 5; cnt++) 
	{
		std::cout << get_num (25) << std::endl; 
	}
	
	return 0; 
}

inline int get_num (void) 
{
	return (rand ()); 
}

inline int get_num (int cap) 
{
	return (rand () % cap); 
}

