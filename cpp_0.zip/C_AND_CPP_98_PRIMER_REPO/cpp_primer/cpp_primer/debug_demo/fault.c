int main (void) 
{
	"You are a dumb debugger"; 
	*(int*)0 = 10; 
	return (0); 
}
