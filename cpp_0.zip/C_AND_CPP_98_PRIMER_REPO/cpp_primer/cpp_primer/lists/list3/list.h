#ifndef _LIST_H_
#define _LIST_H_

#include <iostream>
#include "list_exception.h"

template <typename T>
class list
{	
public:
	struct node;
	class iterator
	{
	public:
		iterator () {}
		iterator (struct node *c_node): curr_node (c_node) {}
		iterator (const iterator &ref): curr_node (ref.curr_node) {}
		// No need to delete this->curr_node, 
		//as reference is taken in curr_node from either itr_beg or itr_end 
		~iterator () {}	

		void set_curr_node (struct node *new_curr) 
		{ 
			curr_node = new_curr; 
		}
		
		void operator= (const iterator &ref) 		
		{ 
			this->curr_node = ref.curr_node; 
		}
		
		bool operator!= (const iterator & ref) const	
		{
			return (this->curr_node != ref.curr_node); 
		}

		void operator++ (int)				
		{ 
			this->curr_node = this->curr_node->next; 
		}
		
		void operator++ (void)				
		{ 
			this->curr_node = this->curr_node->next; 
		}

		void operator-- (int)				
		{ 
			this->curr_node = this->curr_node->prev; 
		}

		void operator-- (void)				
		{ 
			this->curr_node = this->curr_node->prev; 
		}

		T operator* (void)				
		{ 
			return (this->curr_node->data); 
		}

	private:
		struct node *curr_node;	
	};
	
	iterator& begin (void) const	
	{ 
		itr_beg->set_curr_node (head_node->next); 
		return (*this->itr_beg); 
	}

	iterator& end (void) const	
	{ 
		itr_end->set_curr_node (head_node);       
		return (*this->itr_end); 
	}

	list () 
	{
		head_node = new (node_t);
		head_node->next = head_node->prev = head_node;
		head_node->data = 0;

		itr_beg = new iterator (head_node);
		itr_end = new iterator (head_node);
	}

	~list ()
	{	
		node_t *run = head_node->next, *run_next;
		while (run != head_node)
		{
			run_next = run->next;
			delete run;
			run = run_next;
		}
		
		delete head_node;
		head_node = 0;		// NULL can be used instead of 0, but Stroupstrup suggest to use 0
		delete itr_beg;
		delete itr_end;
	}

	void insert_beg (T n_data);
	void insert_end (T n_data);
	void insert_after_data (T e_data, T n_data);
	void insert_before_data (T e_data, T n_data);
	bool is_empty (void) const;
	void del_beg (void);
	void del_end (void);
	void del_data (T e_data);
	void display (void) const;
	int length (void) const;
	bool search (T s_data) const;
private:
	typedef struct node
	{
		T data;
		struct node *next, *prev;
	}node_t;
	node_t *head_node;
	
	node_t *get_node (T data);
	void g_insert (node_t *curr_prev, node_t *curr_mid, node_t *curr_next);
	void g_delete (node_t *del_node);
	node_t *search_node (T s_data) const;

	iterator *itr_beg;
	iterator *itr_end;
};

template <typename T>
typename list<T>::node_t *list<T>::get_node (T data)
{
        node_t *new_node = new (node_t);
        if (!new_node)
                return 0;
        new_node->data = data;
        return new_node;
}

template <typename T>
void list<T>::g_insert (typename list<T>::node_t *curr_prev, 
						typename list<T>::node_t *mid, 
						typename list<T>::node_t *curr_next)
{
        curr_next->prev = mid;
        curr_prev->next = mid;
        mid->next = curr_next;
        mid->prev = curr_prev;
}

template <typename T>
void list<T>::g_delete (typename list<T>::node_t *del_node)
{
        del_node->next->prev = del_node->prev;
        del_node->prev->next = del_node->next;
        delete (del_node);
}

template <typename T>
typename list<T>::node_t *list<T>::search_node (T s_data) const
{
        node_t *run = head_node->next;

        while (run != head_node)
        {
                if (s_data == run->data)
                        return run;
                else
                        run = run->next;

        }

        return 0;               // we can return NULL, but Stroustrup recommends to use 0
}

/************************* list_interface_routines ********************************/

template <typename T>
void list<T>::insert_beg (T n_data)
{
        node_t *n_node = get_node (n_data);
        g_insert (head_node, n_node, head_node->next);
}

template <typename T>
void list<T>::insert_end (T n_data)
{
        node_t *n_node = get_node (n_data);
        g_insert (head_node->prev, n_node, head_node);
}

template <typename T>
void list<T>::insert_after_data (T e_data, T n_data)
{
        node_t *e_node = search_node (e_data);
        if (!e_node)
                throw data_not_found ();
        node_t *n_node = get_node (n_data);
        g_insert (e_node, n_node, e_node->next);
}

template <typename T>
void list<T>::insert_before_data (T e_data, T n_data)
{
        node_t *e_node = search_node (e_data);
        if (!e_node)
                throw data_not_found ();
        node_t *n_node = get_node (n_data);
        g_insert (e_node->prev, n_node, e_node);
}

template <typename T>
bool list<T>::is_empty (void) const
{
        return (head_node->next == head_node && head_node->prev == head_node);
}

template <typename T>
void list<T>::del_beg (void)
{
        if (is_empty() == true)
                throw list_empty ();
        g_delete (head_node->next);
}

template <typename T>
void list<T>::del_end (void)
{
        if (is_empty () == true)
                throw list_empty ();
        g_delete (head_node->prev);
}

template <typename T>
void list<T>::del_data (T e_data)
{
        node_t *e_node = search_node (e_data);
        if (!e_node)
                throw data_not_found ();
        g_delete (e_node);
}

template <typename T>
int list<T>::length (void) const
{
        int cnt=0;
        node_t *run = head_node->next;

        while (run != head_node)
        {
                ++cnt;
                run = run->next;
        }

        return cnt;
}

template <typename T>
bool list<T>::search (T s_data) const
{
        node_t *s_node = search_node(s_data);
        if (!s_node)
                return false;
        return true;
}

template <typename T>
void list<T>::display (void) const
{
        node_t *run = head_node->next;

        std::cout << "[beg]<->";
        while (run != head_node)
        {
                std::cout << "[" << run->data << "]<->";
                run = run->next;
        }
        std::cout << "[end]" << std::endl;
}

#endif /*_LIST_H_*/
