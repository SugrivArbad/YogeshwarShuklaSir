#include <iostream>
#include "list.h"
#include "list_exception.h"


int main (void)
{
/* list<int> */
	std::cout << "list<int> :" << std::endl;
	list<int> *ptr = new list<int> ();
	try {
		ptr->del_beg ();
	}
	catch (list_empty &ref)
	{
		std::cout << ref.what () << std::endl;		
	}

	for (int cnt=0; cnt < 5; cnt++)
	{
		ptr->insert_beg (cnt);
	}
	ptr->display ();
	
	for (int cnt=5; cnt < 10; cnt++)
	{
		ptr->insert_end (cnt);
	}
	ptr->display ();
	
	ptr->insert_after_data(0, 100);
	ptr->display ();
	ptr->insert_before_data (0, 200);
	ptr->display ();

	ptr->del_beg ();
	ptr->display ();
	ptr->del_end ();
	ptr->display ();
	ptr->del_data (0);
	ptr->display ();
	
	std::cout << "length: " << ptr->length () << std::endl;	
	
	if (ptr->search (200) == true)
		std::cout << "search(200): present" << std::endl;
	if (ptr->search (1000) == false)
		std::cout << "search (1000): Absent" << std::endl;

	for (list<int>::iterator iter=ptr->begin (); iter != ptr->end (); iter++)
	{
		std::cout << "*iter:" << *iter << std::endl;
	}

	delete ptr;

	std::cout << std::endl;
/* list<char> */
	std::cout << "list<char> :" << std::endl;
	char ch;
        list<char> *ptr1 = new list<char> ();
        try {
                ptr1->del_beg ();
        }
        catch (list_empty &ref)
       {
                std::cout << ref.what () << std::endl;
       }

        for (char ch='A'; ch < 'E'; ch++)
        {
                ptr1->insert_beg (ch);
        }
        ptr1->display ();

        for (char ch='E'; ch < 'I'; ch++)
        {
                ptr1->insert_end (ch);
        }
        ptr1->display ();

        ptr1->insert_after_data('E', 'Y');
        ptr1->display ();
        ptr1->insert_before_data ('E', 'S');
        ptr1->display ();

        ptr1->del_beg ();
        ptr1->display ();
        ptr1->del_end ();
        ptr1->display ();
        ptr1->del_data ('E');
        ptr1->display ();

        std::cout << "length: " << ptr1->length () << std::endl;

        if (ptr1->search ('Y') == true)
                std::cout << "search('Y'): present" << std::endl;
        if (ptr1->search ('W') == false)
                std::cout << "search ('W'): Absent" << std::endl;

        for (list<char>::iterator iter=ptr1->begin (); iter != ptr1->end (); iter++)
        {
                std::cout << "*iter:" << *iter << std::endl;
        }

        delete ptr1;

	std::cout << std::endl;
/*list <long>*/
	std::cout << "list<long> :" << std::endl;

        list<long> *ptr2 = new list<long> ();
        try {
                ptr2->del_beg ();
        }
        catch (list_empty &ref)
        {
                std::cout << ref.what () << std::endl;
        }

        for (long cnt=100; cnt < 105; cnt++)
        {
                ptr2->insert_beg (cnt);
        }
        ptr2->display ();

        for (int cnt=105; cnt < 110; cnt++)
        {
                ptr2->insert_end (cnt);
        }
        ptr2->display ();

        ptr2->insert_after_data(105, 1000);
        ptr2->display ();
        ptr2->insert_before_data (105, 2000);
        ptr2->display ();

        ptr2->del_beg ();
        ptr2->display ();
        ptr2->del_end ();
        ptr2->display ();
        ptr2->del_data (105);
        ptr2->display ();

        std::cout << "length: " << ptr2->length () << std::endl;

        if (ptr2->search (2000) == true)
                std::cout << "search(200): present" << std::endl;
        if (ptr2->search (1100) == false)
                std::cout << "search (1100): Absent" << std::endl;

        for (list<long>::iterator iter=ptr2->begin (); iter != ptr2->end (); iter++)
        {
                std::cout << "*iter:" << *iter << std::endl;
        }

        delete ptr2;

	return 0;	
}
