#include <iostream> 
#include <cstdlib> 
#include "list.h" 

// Interface routines code 

int List::insert_beg(int new_data) 
{
	node_t *new_node = get_node(new_data); 
	g_insert(this->head, new_node, this->head->next);
	return (SUCCESS); 
}

int List::insert_end(int new_data) 
{
	node_t *new_node = get_node(new_data); 
	g_insert(this->head->prev, new_node, this->head); 
	return (SUCCESS); 
}

int List::insert_after_data(int e_data, int new_data) 
{
	node_t *new_node, *e_node; 
	e_node = search_node(this->head, e_data); 
	if(!e_node) 
		return DATA_NOT_FOUND; 
	new_node = get_node(new_data); 
	g_insert(e_node, new_node, e_node->next); 
	return (SUCCESS); 
}

int List::insert_before_data(int e_data, int new_data) 
{
	node_t *new_node, *e_node; 
	e_node = search_node(this->head, e_data); 
	if(!e_node) 
		return DATA_NOT_FOUND; 
	new_node = get_node(new_data); 
	g_insert(e_node->prev, new_node, e_node); 
	return (SUCCESS); 
}

int List::del_beg(void)
{
	if(this->is_empty())
		return (LIST_EMPTY); 
	g_delete(this->head->next); 
	return (SUCCESS); 
}

int List::del_end(void) 
{
	if(this->is_empty())
		return LIST_EMPTY; 
	g_delete(this->head->prev); 
	return SUCCESS; 
}

int List::del_data(int d_data) 
{
	node_t *e_node = search_node(this->head, d_data); 
	if(!e_node) 
		return DATA_NOT_FOUND; 
	g_delete(e_node); 
	return (SUCCESS); 
}

bool List::search(int s_data) 
{
	node_t *e_node = search_node(this->head, s_data); 
	if(e_node)
		return true; 
	return false; 
}

bool List::is_empty(void) 
{
	if(this->head->next == head && this->head->prev == head) 
		return true;
	return false; 
}

void List::display(void) 
{
	std::cout << "[beg]<->"; 
	for(node_t *run = this->head->next; run != this->head; run = run->next)
		std::cout << "[" << run->data << "]<->"; 
	std::cout << "[end]" << std::endl; 
	
}

// Internal routines code. (all static) 

void List::g_insert(node_t *beg, node_t *mid, node_t *end) 
{
	mid->next = end; 
	mid->prev = beg; 
	beg->next = mid; 
	end->prev = mid; 
}

void List::g_delete(node_t *node) 
{
	node->next->prev = node->prev; 
	node->prev->next = node->next; 
	delete node; 
}

node_t* List::search_node(node_t *head, int s_data)
{
	for(node_t *run = head->next; run != head; run = run->next)
			if(run->data == s_data)
				return run; 

	return NULL; 
}

node_t* List::get_node(int new_data) 
{
	node_t *new_node = new node_t; 
	new_node->data = new_data; 
	return (new_node); 
}

/*
#include <stdexcept> 
if(!new_node)
	throw std::bad_alloc(); 
*/ 

