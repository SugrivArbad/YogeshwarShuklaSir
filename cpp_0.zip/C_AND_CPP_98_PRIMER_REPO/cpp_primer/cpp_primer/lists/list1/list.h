#ifndef _LIST_H 
#define _LIST_H 
// Symbolic constant definitions 
#define SUCCESS 		1 
#define DATA_NOT_FOUND 	-1 
#define LIST_EMPTY 		-2 
// Internal layout of a node in list 
typedef struct node{
	int data; 
	struct node *prev, *next; 
}node_t; 
// Implementation of List 
class List{
	public: 
			// Constructor : create_list in C implementation 
			List() 
			{
				this->head = get_node(0); 
				this->head->next = this->head->prev = head; 
			}
			// Interface routines 
			int insert_beg(int new_data); 
			int insert_end(int new_data); 
			int insert_after_data(int e_data, int new_data); 
			int insert_before_data(int e_data, int new_data); 
			int del_beg(void); 
			int del_end(void); 
			int del_data(int e_data); 
			bool is_empty(void); 
			bool search(int s_data); 
			void display(void); 
			
			// Destructor : destroy_list in C implementation  
			~List() 
			{
				std::cout << "In destructor" << std::endl; 
				node_t *run, *run_n; 
				for(run = this->head->next; run != this->head; run = run_n){
					run_n = run->next; 
					delete run; 
				}

				delete this->head; 
				this->head = NULL; 
			}

	private: 
		node_t *head; 	
		static void g_insert(node_t *beg, node_t *mid, node_t *end); 
		static void g_delete(node_t *node); 
		static node_t *search_node(node_t *lst, int s_data); 
		static node_t *get_node(int new_data); 
}; 

#endif 
