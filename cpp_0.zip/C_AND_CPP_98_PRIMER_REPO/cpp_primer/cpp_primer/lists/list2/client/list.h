#ifndef _LIST_H 
#define _LIST_H 

class IList
{
public: 
	virtual int insert_beg(int new_data) = 0; 
	virtual int insert_end(int new_data) = 0; 
	virtual int insert_after_data(int e_data, int new_data) = 0; 
	virtual int insert_before_data(int e_data, int new_data) = 0; 
	virtual int del_beg(void) = 0; 
	virtual int del_end(void) = 0; 
	virtual int del_data(int d_data) = 0; 
	virtual bool search(int s_data) = 0; 
	virtual bool is_empty(void) = 0; 
	virtual void display(void) = 0; 
	virtual ~IList(){}  
}; 

IList *get_list_instance(void); 	

#endif // _LIST_H 

