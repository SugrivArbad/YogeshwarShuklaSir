#include <iostream> 
#include <cstdlib> 
#include "list.h" 

int main(void) 
{
	IList *lst = get_list_instance(); 

	if(lst->is_empty())
		std::cout << "List is empty" << std::endl; 
	
	for(int i=0; i < 5; i++) 
		lst->insert_beg(i); 
	lst->display(); 
	
	for(int i=5; i < 10; i++) 
		lst->insert_end(i); 
	lst->display(); 
	
	lst->insert_after_data(0, 100); 
	lst->insert_before_data(0, 200); 
	lst->display(); 
	
	lst->del_beg(); 
	lst->del_end(); 
	lst->del_data(0); 
	lst->display(); 
	
	if(lst->search(100))
		std::cout << "100 is present" << std::endl; 
	else
		std::cout << "100 is absent" << std::endl; 
	
	delete lst; 

	return EXIT_SUCCESS; 
}
