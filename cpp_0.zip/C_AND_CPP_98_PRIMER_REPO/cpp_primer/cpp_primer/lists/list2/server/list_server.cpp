#include <iostream> 
#include <cstdlib> 
#include "list.h"
#include "list_server.h" 

IList *get_list_instance(void) 
{
	return new CList; 
}

// Interface routines code 

int CList::insert_beg(int new_data) 
{
	node_t *new_node = get_node(new_data); 
	g_insert(this->head, new_node, this->head->next);
	return (SUCCESS); 
}

int CList::insert_end(int new_data) 
{
	node_t *new_node = get_node(new_data); 
	g_insert(this->head->prev, new_node, this->head); 
	return (SUCCESS); 
}

int CList::insert_after_data(int e_data, int new_data) 
{
	node_t *new_node, *e_node; 
	e_node = search_node(this->head, e_data); 
	if(!e_node) 
		return DATA_NOT_FOUND; 
	new_node = get_node(new_data); 
	g_insert(e_node, new_node, e_node->next); 
	return (SUCCESS); 
}

int CList::insert_before_data(int e_data, int new_data) 
{
	node_t *new_node, *e_node; 
	e_node = search_node(this->head, e_data); 
	if(!e_node) 
		return DATA_NOT_FOUND; 
	new_node = get_node(new_data); 
	g_insert(e_node->prev, new_node, e_node); 
	return (SUCCESS); 
}

int CList::del_beg(void)
{
	if(this->is_empty())
		return (LIST_EMPTY); 
	g_delete(this->head->next); 
	return (SUCCESS); 
}

int CList::del_end(void) 
{
	if(this->is_empty())
		return LIST_EMPTY; 
	g_delete(this->head->prev); 
	return SUCCESS; 
}

int CList::del_data(int d_data) 
{
	node_t *e_node = search_node(this->head, d_data); 
	if(!e_node) 
		return DATA_NOT_FOUND; 
	g_delete(e_node); 
	return (SUCCESS); 
}

bool CList::search(int s_data) 
{
	node_t *e_node = search_node(this->head, s_data); 
	if(e_node)
		return true; 
	return false; 
}

bool CList::is_empty(void) 
{
	if(this->head->next == head && this->head->prev == head) 
		return true;
	return false; 
}

void CList::display(void) 
{
	std::cout << "[beg]<->"; 
	for(node_t *run = this->head->next; run != this->head; run = run->next)
		std::cout << "[" << run->data << "]<->"; 
	std::cout << "[end]" << std::endl; 
	
}

// Internal routines code. (all static) 

void CList::g_insert(node_t *beg, node_t *mid, node_t *end) 
{
	mid->next = end; 
	mid->prev = beg; 
	beg->next = mid; 
	end->prev = mid; 
}

void CList::g_delete(node_t *node) 
{
	node->next->prev = node->prev; 
	node->prev->next = node->next; 
	delete node; 
}

node_t* CList::search_node(node_t *head, int s_data)
{
	for(node_t *run = head->next; run != head; run = run->next)
			if(run->data == s_data)
				return run; 

	return NULL; 
}

node_t* CList::get_node(int new_data) 
{
	node_t *new_node = new node_t; 
	new_node->data = new_data; 
	return (new_node); 
}

/*
#include <stdexcept> 
if(!new_node)
	throw std::bad_alloc(); 
*/ 

