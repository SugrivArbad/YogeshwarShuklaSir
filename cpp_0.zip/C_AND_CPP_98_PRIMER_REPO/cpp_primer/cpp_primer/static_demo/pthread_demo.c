#include <stdio.h> 
#include <stdlib.h> 
#include <errno.h> 
#include <string.h> 
#include <unistd.h> 
#include <pthread.h> 

void *thread_func (void*); 

int main (void)
{
	pthread_t th1, th2; 

	pthread_create (&th1, NULL, thread_func, NULL); 
	pthread_create (&th2, NULL, thread_func, NULL); 
	pthread_join (th1, NULL); 
	pthread_join (th2, NULL);

	exit (EXIT_SUCCESS);
}

void *thread_func (void *arg) 
{
	int num; 
	while (1)
	{
		printf("THREAD:%lx\n", (unsigned long int)pthread_self()); 
		sleep(rand() % 4); 
	}
}

