int num = 10; 

int main (void) 
{
	int i, j, k; 
	static int local_static_num; 

	for (i=0; i < 10; i++) 
	{
		for (j=0; j < 10; j++)
		{
			k = i * j; 
			local_static_num++; 
		}
	}
}
