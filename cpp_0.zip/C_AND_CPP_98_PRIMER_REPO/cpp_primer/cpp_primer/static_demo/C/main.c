#include <stdio.h> 
#include <stdlib.h> 

extern static int n1, n2; 

int main(void) 
{
	printf("n1+n2:%d\n", n1+n2); 
	exit(EXIT_SUCCESS); 
}
