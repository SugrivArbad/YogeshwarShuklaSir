static int n1=10, n2=20; 
