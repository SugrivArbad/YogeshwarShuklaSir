#include <stdio.h> 
#include <stdlib.h> 

void f(void); 
void g(void); 

int main(void) 
{
	int i; 

	for(i = 0; i < 5; i++)
			f(); 
	
	for(i = 0; i < 5; i++)
			g(); 

	exit(EXIT_SUCCESS); 
}

void f(void)
{
	static int n = 10; 
	n++; 
	printf("n=%d\n", n); 
}

void g(void)
{
	static int n = 20; 
	n = n + 2; 
	printf("n=%d\n", n); 
}


