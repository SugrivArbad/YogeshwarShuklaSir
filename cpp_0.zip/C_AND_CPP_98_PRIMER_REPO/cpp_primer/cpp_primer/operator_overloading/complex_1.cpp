#include <iostream> 
#include <cstdlib> 

class Complex
{
	private: 
			double re, im;
	public: 
			Complex() : re(0.0), im(0.0) {} 
			
			Complex(double in_re, double in_im) : re(in_re), im(in_im) {} 
			
			bool operator==(const Complex *other)
			{
				return ((this->re == other->re) && (this->im == other->im)); 
			}
			
			void dump()const 
			{
				std::cout << "(" << re << ")+i(" << im << ")" << std::endl; 
			}
}; 

int main(void) 
{
	Complex *c1 = new Complex(1.1, 2.2); 
	Complex *c2 = new Complex(*c1); 

	c1->dump(); 
	c2->dump(); 

	if(c1 == c2) 
	{
		std::cout << "c1 and c2 are equal" << std::endl; 
	}
	else
	{
		std::cout << "c1 and c2 are not equal" << std::endl; 
	}

	delete c1; 
	c1 = 0; 

	delete c2; 
	c2 = 0; 

	return EXIT_SUCCESS; 
}
