#include <iostream>

class Complex
{
	private: 
		double re, im; 
	public: 
		Complex(double init_re, double init_im) : re(init_re), im(init_im) {} 
		Complex() : re(0.0), im(0.0) {} 

		bool operator==(const Complex &other)
		{
			std::cout << "IN OPERATOR==" << std::endl; 
			return ((this->re == other.re) && (this->im == other.im)); 
		}
}; 

int main(void)
{
	Complex *c1 = new Complex(10.5, 20.5); 
	Complex *c2 = new Complex(10.5, 20.5); 

	if(*c1 == *c2)
	{
		std::cout << "EQUAL" << std::endl; 
	}
	else
	{
		std::cout << "NOT EQUAL" << std::endl; 
	}

	delete c1; 
	c1 = NULL; 

	delete c2; 
	c2 = NULL; 

	return EXIT_SUCCESS; 
}

/*
c1 + c2 

c1.add(c2)

c1 == c2 

c1->operator==(c2); 

c1: Complex*
c2: Complex* 

*/ 