#include <stdio.h>
#include <stdlib.h> 

struct String{
	char *str_arr; 
}; 

typedef struct StrVector
{
	struct String *arr; 
}

typedef struct Vector
{
	int *arr; 
	int size; 
	int capacity; 
	int curr; 
}vecint_t; 

vecint_t *create_vecint(int size);
int insert(vecint_t *arr, int element); 
void *xcalloc(int nr_element, int size_per_element); 

int main(void) 
{

}

void insert(vecint_t *arr, int element) 
{
	// This is to be absolutely sure that we do not 
	// run into segementation fault *EVER* 
	if(++arr->curr == arr->size)
		exit(-1); 
	arr[arr->curr] = element; 
	if(--arr->capacity < arr->size/2)
	{
		arr->arr = xrealloc(arr->arr, 2*size*sizeof(int)); 
	}

	arr->capacity = size + size - arr->capacity; 
	
}

vecint_t *create_vecint(int size) 
{
	vecint_t *new_vec = (vecint_t*)xcalloc(1, sizeof(vecint)); 
	new_vec->size = size; 
	new_vec->arr = (int*)xcalloc(size, sizeof(int)); 
	new_vec->capacity = size; 
	new->vec->curr = -1; 
}

void *xcalloc(int nr_element, int size_per_element) 
{
	void *ptr = calloc(nr_element, size_per_element); 
	if(!ptr)
	{
		fprintf(stderr, "calloc:fatal:Out of virtual memory\n"); 
		exit(EXIT_FAILURE); 
	}
	return (ptr); 
}
