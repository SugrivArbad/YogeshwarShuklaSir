#include <iostream> 

class Complex{
private:
	double re, im; 
public: 
	Complex() : re(0.0), im(0.0) {} 
	Complex(double init_re, double init_im) : re(init_re), im(init_im) {}

	Complex(const Complex &other){
		std::cout << "cc:this:" << this << " &other:" << &other << std::endl; 
	}

	Complex operator+(Complex &other){
		double sum_re, sum_im; 

		sum_re = this->re + other.re; 
		sum_im = this->im + other.im; 

		Complex summation(sum_re, sum_im); 
		std::cout << "operator+:&summation:" << &summation << std::endl; 
		return summation; 
	}

}; 

int main(){
	Complex c1(1.0, 2.2), c2(2.0, 3.3); 
	Complex sum = c1 + c2; 
	std::cout << "main:&sum:" << &sum << std::endl; 
	return 0; 
}