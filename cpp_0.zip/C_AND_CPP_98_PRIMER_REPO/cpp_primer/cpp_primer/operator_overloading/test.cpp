#include <iostream> 
#include <cstdlib> 

class Test
{
	private: 
		int i_num; 

	public: 
		Test() : i_num(0) {} 
		~Test() 
		{
			std::cout << "Recursive call" << std::endl; 
			std::cout << "++i_num:" << ++i_num << std::endl; 
			delete this; 
		}
}; 

int main()
{
	Test *t = new Test(); 

	delete t; 

	return (0); 
}
