#include <iostream> 
#include <cstdlib> 
#include "list.h" 
#include "list_exceptions.h" 

list::node_t *list::get_node(int n_data)
{
	list::node_t *node; 
	try
	{
		node = new (node_t); 
	}
	catch (std::exception &e)
	{
		throw std::bad_alloc(); 	
	}

	node->data = n_data; 
	return node; 
}

void list::g_insert(list::node_t *beg, list::node_t *mid, list::node_t *end) 
{
	mid->next = end; 
	mid->prev = beg; 
	beg->next = mid; 
	end->prev = mid; 
}

void list::g_delete(list::node_t *node) 
{
	list::node_t *beg = node->prev, *end = node->next; 
	beg->next = end; 
	end->prev = beg; 
	delete node; 
}

list::node_t *list::search_node (int s_data)
{
	list::node_t *run = head_node->next; 
	while (run != head_node)
	{
		if (s_data == run->data) 
			return run; 
		else
			run = run->next; 
	}

	return 0; 
}


