#include <iostream> 
#include <cstdlib> 

class Outer
{
	public:
			class Inner; 
			Outer(int x, int y) : start(x), end(y) {} 
			int public_num; 
			struct A {int a; char b; float c;} ina; 
			/*Inner &begino(void)const
			{
				return *(new Inner(this->start));  
			}

			Inner &endo(void) const
			{
				return *(new Inner(this->end));
			}*/

			/*class Inner 
			{
				public:
						Inner(){}
						Inner(int in) 
						{
								current = in;
						} 
						void operator=(const Inner &other)
						{
							this->current = other.current;
						}
						
						void operator++()
						{
							++this->current; 
						}

						void operator++(int)
						{
							this->current++; 
						}
						
						int get_val(void) const
						{
							return current; 
						}


						void display(void) const 
						{
								std::cout << "current:" << current << std::endl;
						}
				private:
						int current; 
			};*/ 
	private:
			int start; 
			int end; 
}; 

int main(void) 
{
	std::cout << "sizeof (class Outer):" << sizeof (class Outer) << std::endl; 
/*	Outer *obj = new Outer(10,20); 
	Outer::Inner in1; 
	Outer::Inner in2;
	in1 = obj->begino(); 
	in2 = obj->endo(); 
	for(int i=in1.get_val(); i != in2.get_val(); )
	{
		std::cout << i << std::endl; 
		in1++; 
		i = in1.get_val(); 

	}*/ 
	return 0; 

}
