#include <iostream> 
#include <cstdlib> 
#include "list.h" 
#include "list_exceptions.h" 

void list::insert_beg(int n_data) 
{
	node_t *node = get_node(n_data); 
	g_insert(head_node, node, head_node->next); 
}

void list::insert_end(int n_data) 
{
	node_t *node = get_node(n_data); 
	g_insert(head_node->prev, node, head_node); 
}

void list::insert_after_data(int e_data, int n_data)
{
	node_t *e_node = search_node(e_data); 
	if (!e_node)
		throw data_not_found(); 
	node_t *new_node = get_node(n_data); 
	g_insert(e_node, new_node, e_node->next); 
}

void list::insert_before_data(int e_data, int n_data)
{
	node_t *e_node = search_node(e_data); 
	if (!e_node)
		throw data_not_found(); 
	node_t *new_node = get_node(n_data); 
	g_insert(e_node->prev, new_node, e_node); 
}

void list::del_beg(void) 
{
	if (head_node->prev == head_node && head_node->next == head_node)
		throw list_empty(); 
	g_delete(head_node->next); 	
}

void list::del_end(void) 
{
	if (head_node->prev == head_node && head_node->next == head_node) 
		throw list_empty();  
	g_delete(head_node->prev); 
}

void list::del_data(int e_data) 
{
	node_t *node = search_node(e_data); 
	if (!node)
		throw data_not_found(); 
	g_delete(node); 
}

int list::length(void) const
{
	int cnt=0; 
	node_t *run = head_node->next; 
	while (run != head_node)
	{
		++cnt; 
		run = run->next; 
	}
	return cnt; 
}

bool list::is_empty(void) const
{
	return (head_node->next == head_node && head_node->prev == head_node);	
}

bool list::search(int s_data) const
{
	node_t *run=head_node->next; 
	while (run != head_node)
	{
		if (run->data == s_data)
			return true; 
		else
			run = run->next; 
	}

	return false; 
}

void list::display (void) const
{
	node_t *run = head_node->next; 
	std::cout << "[beg]<->"; 
	while (run != head_node)
	{
		std::cout << "[" << run->data << "]<->"; 
		run = run->next; 
	}
	std::cout << "[end]" << std::endl; 
}
