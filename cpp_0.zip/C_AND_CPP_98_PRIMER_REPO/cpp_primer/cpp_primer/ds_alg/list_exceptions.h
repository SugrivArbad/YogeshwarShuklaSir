#include <stdexcept> 

using std::runtime_error; 

class data_not_found : public runtime_error
{
	public: 
			data_not_found () : runtime_error ("Given data not existing") {} 
}; 

class list_empty : public runtime_error
{
	public: 
			list_empty () : runtime_error("List is empty") {}  
};
