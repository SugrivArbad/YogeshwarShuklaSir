#ifndef _LIST_H 
#define _LIST_H 


/* namespace ds
{
	namespace list 
	{
		class snode
		{
			friend class slist; 
			friend class sclist; 
			private: 
					// Everything private 
		}; 

		class dnode
		{
			friend class dlist; 
			friend class dclist; 
			private:
					//everything private
		}; 

		class slist 
		{
			public: 
					slist ()
					{
						head_node = new snode(0); 
					}
			private:
					snode *head_node; 

		}; 

		class sclist
		{
		
		}; 

		class dlist
		{
		
		}; 

		class dclist 
		{
		
		}; 
	}; 

}; */

class list
{
public: 
		list()
		{
			head_node = new (node_t); 
			head_node->prev = head_node->next = head_node; 
		}

		~list()
		{
			node_t *run=head_node->next, *run_n;
			while (run != head_node)
			{
				run_n = run->next; 
				delete run; 
				run = run_n; 
			}

			delete head_node; 
		}
		void insert_beg(int n_data); 
		void insert_end(int n_data); 
		void insert_after_data(int e_data, int n_data); 
		void insert_before_data(int e_data, int n_data); 
		void del_beg(void); 
		void del_end(void); 
		void del_data(int e_data); 
		bool is_empty(void) const; 
		bool search(int s_data) const; 
		int  length(void) const; 
		void display(void) const; 

private: 
		typedef struct node 
		{
			int data; 
			struct node *prev, *next; 
		}node_t;

		node_t *head_node; 

		void g_insert(node_t *beg, node_t *mid, node_t *end); 
		void g_delete(node_t *node); 
		node_t *search_node(int s_data); 
		node_t *get_node(int n_data); 
}; 

#endif /* _LIST_H */ 
