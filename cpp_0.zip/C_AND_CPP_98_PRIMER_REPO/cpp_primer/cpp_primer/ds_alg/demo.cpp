#include <iostream> 
#include <cstdlib> 

class Outer
{
	public:
			class Inner; 
			Outer(int x, int y) : start(x), end(y), b(new Inner(x)), e(new Inner(y)) 
			{
	
			} 
			~Outer()
			{
				delete b; 
				delete e; 
			}
			Inner &begino(void)const
			{
				return *b;
			}

			Inner &endo(void) const
			{
				return *e;
			}

			class Inner 
			{
				public:
						~Inner() {std::cout << "In Inner Destruct" << std::endl;}
						Inner(){
						}
						Inner(int in) 
						{
								current = in;
						} 
						Inner (const Inner &ref)
						{
							std::cout << "CC:HERE" << std::endl; 
							this->current = ref.current; 
						}
						void operator=(const Inner &other)
						{
							this->current = other.current;
						}
						
						void operator++()
						{
							++this->current; 
						}

						void operator++(int)
						{
							this->current++; 
						}
						
						bool operator!= (const Inner &ref) 
						{
							return (this->current != ref.current); 
						}

						int operator*(void)
						{
							return (this->current); 
						}
				private:
						int current; 
			};
	private:
			int start; 
			int end; 
			Inner *b, *e; 
}; 

int main(void) 
{
	Outer obj(10,20); 
	for(Outer::Inner &in = obj.begino(); in != obj.endo(); ++in)
	{
		std::cout << *in << std::endl; 
	}
	return 0; 
}

