#include <iostream> 
#include <cstdlib> 
#include "list.h" 
#include "list_exceptions.h" 

int main (void) 
{
	int cnt; 
	list *ptr = new list(); 
	try{
		ptr->del_beg(); 
	}
	catch (list_empty &ref){
			std::cout << ref.what () << std::endl; 
			std::cout << "Unsuccessful attempt to del from empty list"
					  << std::endl; 
	}
	if (ptr->is_empty())
		std::cout << "List empty" << std::endl; 
	for(cnt=0; cnt < 5; cnt++)
		ptr->insert_beg(cnt); 
	ptr->display(); 
	for(cnt=5; cnt < 10; cnt++) 
		ptr->insert_end(cnt); 
	ptr->display(); 
	ptr->insert_after_data(0, 100); 
	ptr->display(); 
	ptr->insert_before_data(0, 200); 
	ptr->display(); 
	ptr->del_beg(); 
	ptr->display(); 
	ptr->del_end(); 
	ptr->display(); 
	ptr->del_data(0); 
	ptr->display(); 
	std::cout << "length(list):" << ptr->length() << std::endl; 
	if (ptr->search(200))
		std::cout << "200 is present" << std::endl; 
	if (!ptr->search(1000))
		std::cout << "1000 is not present" << std::endl; 
	if (!ptr->is_empty())
		std::cout << "List is not empty" << std::endl; 

	delete ptr; 

	return EXIT_SUCCESS; 
}

/*std::vector<int> ivec(10, 5); 
for(std::vector<int>::iterator iter = ivec.begin(); 
	iter != ivec.end(); 
	++iter)
	std::cout << *iter << std::endl; */ 
