#include <iostream> 

class A{
	public: 
			A() {} 
			~A() {} 
			void f(void) {std::cout << "A::f" << std::endl;}
}; 

class B{
	public: 
			B() {} 
			~B() {} 
			void g(void) {std::cout << "B::g" << std::endl;}
}; 

int main(void) 
{
	A *p = new A; 
	
	reinterpret_cast<B*>(p) -> g(); 

	delete p; 	

	return 0; 
}
