#include <iostream> 
#include <cstdlib> 

/* Syntax of casting statements 
static_cast<T>(expr); 
dynamic_cast<T>(expr);  
reinterpret_cast<T>(expr); 
*/ 

void f(void *p); 

int main(void) 
{
	double d = 0.0; 
	int p = 100; 
	long int lp; 
	short int sp = 10;  
	void *ptr = 0; 

	d = static_cast<double>(p); 

	lp = p; 

	p = sp; 

	ptr = &d; 
	ptr = &p; 
	ptr = &lp; 
	ptr = &sp; 

	d =  243.2342342; 
	p = static_cast<int>(d); 

	f(static_cast<void*>(&d)); 
	f(static_cast<void*>(&p)); 
	f(static_cast<void*>(&lp)); 
	return (0); 
}

void f(void *p) {} 
