#include <iostream> 
#include <cstdlib> 

class A{
	private: 
			int a; 
			char b; 
			double d; 
	public: 
			A() {;} 
			A(int ina, char inb, double ind) : a(ina), b(inb), d(ind) {} 
			void dump() {std::cout << "a:" << a << " b:" << b << " c:" << std::endl;}  
}; 

void f(void *p); 
void g(void **p);

int main(void) 
{
	A inA; 
	A *pA; 

	f(static_cast<void*>(&inA)); 
	g(reinterpret_cast<void**>(&pA)); 
	
	int *p = static_cast<int*>(malloc(sizeof(int))); 

	return (0); 
}

void f(void *p) 
{
		std::cout << "Inside f" << std::endl; 
}  

void g(void **pp)
{
}
