#include <iostream> 
#include <cstdlib> 
#include "base_item.h" 
#include "bulk_item.h" 

#define NR_ITEMS 	   10 
#define NR_THRESHOLD_ITEMS 5

void print_invoice (BaseItem *p_item, int nr_items); 

int main (void) 
{
	BaseItem *p_base_item = new BaseItem (std::string ("978-0-262-22069-9"), 2000); 	
	BulkItem *p_bulk_item = new BulkItem (std::string ("978-0-262-22069-9"), 2000, 
					      NR_THRESHOLD_ITEMS, 10.0);  
	print_invoice (p_base_item, 1); 
	print_invoice (p_bulk_item, NR_ITEMS); 

	return (EXIT_SUCCESS); 
}

void print_invoice (BaseItem *p_item, int nr_items) 
{
	std::cout << "ISBN\t\t\tITEMS\t\tNET PRICE" << std::endl 
		  << p_item->get_isbn () << "\t" << nr_items 
		  << "\t\t" << p_item->net_price (nr_items) << std::endl; 
}
