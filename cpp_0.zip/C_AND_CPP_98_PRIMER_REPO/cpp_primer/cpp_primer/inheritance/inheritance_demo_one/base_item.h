#ifndef _BASE_ITEM_H 
#define _BASE_ITEM_H 

#include <string> 

class BaseItem
{
	public: 
		BaseItem () {} 
		~BaseItem () {} 
		BaseItem (std::string in_isbn, double in_price_per_item): 
			  isbn (in_isbn), price_per_item (in_price_per_item) {}
		std::string get_isbn (void) const; 
		virtual double net_price (std::size_t nr_items) const; 
	private: 
		std::string isbn; 
	protected:
		double price_per_item; 
}; 

#endif 
