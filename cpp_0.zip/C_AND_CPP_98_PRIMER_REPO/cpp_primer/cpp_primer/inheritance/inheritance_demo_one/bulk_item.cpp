#include <iostream> 
#include "bulk_item.h" 

double BulkItem::net_price (std::size_t nr_items) const 
{
	double actual_price = nr_items * price_per_item; 
	double discounted_price = (actual_price - (actual_price * (discount / 100))); 

	if (nr_items > nr_threshold) 
	{
		return (discounted_price); 
	}
	else
	{
		return (actual_price); 
	}
}
