#include "base_item.h" 


std::string BaseItem::get_isbn (void) const 
{
	return (isbn); 
}

double BaseItem::net_price (std::size_t nr_elements) const 
{
	return (price_per_item * nr_elements); 	
}
