#ifndef _BULK_ITEM_H 
#define _BULK_ITEM_H 

#include "base_item.h"

class BulkItem : public BaseItem 
{
	public: 
		BulkItem (std::string in_isbn, int in_price_per_item, int in_nr_threshold, 
			  double in_discount) : BaseItem (in_isbn, in_price_per_item), 
						nr_threshold (in_nr_threshold), 
						discount (in_discount) {} 
		double net_price (std::size_t nr_items) const; 
	private: 
		int nr_threshold; 
		double discount; 
}; 

#endif 
