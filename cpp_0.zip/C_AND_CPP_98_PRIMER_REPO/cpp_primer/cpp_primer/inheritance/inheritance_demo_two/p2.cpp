#include <iostream> 
#include <cstdlib> 

class A 
{
	public: 
		A () {} 
		A (int i_in_num) : i_num (i_in_num), d_num (0.0) {} 
		A (double d_in_num) : i_num (0), d_num (d_in_num) {} 
		A (int i_in_num, double d_in_num) : i_num (i_in_num), d_num (d_in_num) {} 
		~A () {} 
		virtual void result (int multiplier, int adder=5, int divider=10) const 
		{
			std::cout << "In A::mult" << std::endl
				  << "Multiplier:" << multiplier << std::endl  
				  << "Adder:" << adder << std::endl 
				  << "Divider:" << divider << std::endl; 
		}

		virtual void test (int x) const 
		{
			std::cout << "In A::test" << std::endl; 
			std::cout << "x:" << x << std::endl; 
		}

	protected: 
		int i_num; 
		double d_num; 
}; 

class B : public A 
{
	public: 	
		B () {} 
		B (int i_in_num) : A (i_in_num) {} 
		B (double d_in_num) : A (d_in_num) {} 
		B (int i_in_num, double d_in_num) : A (i_in_num, d_in_num) {} 
		
		virtual void result (int divider, int adder, int multiplier=10) const 
		{
			std::cout << "In B::result:" << std::endl 
				  << "Multiplier:" << multiplier << std::endl  
				  << "Adder:" << adder << std::endl 
				  << "Divider:" << divider << std::endl;
		}

		void test (int x)  const 
		{
			std::cout << "In B::test" << std::endl
				  << "x:" << x << std::endl; 
				
		}

}; 


int main (void) 
{
	A *ptrA = new A (10, 3.14), *ptrA_objB = new B (13, 34.32); 
	B *ptrB = new B (12, 5.4); 
	ptrA->result (10); 
	ptrA->result (20, 25, 30); 
	ptrB->result (100, 200); 
	ptrA_objB->result (1000, 2000, 300); 
	ptrA->test (10000); 
	ptrA_objB->test (20000); 
	return (EXIT_SUCCESS); 
}
