#include <iostream>
#include <cstdlib> 

int main (void) 
{
	const int nr_elements = 10; 
	int *arr = new int [nr_elements]; 

	for (int i=0; i < nr_elements; i++) 
	{
		arr[i] = i + 10; 
	}

	for (int i=0; i < nr_elements; i++) 
	{
		std::cout << "arr[" << i << "]:" << arr[i] << std::endl; 
	}

	delete []arr;

	return EXIT_SUCCESS; 
}
