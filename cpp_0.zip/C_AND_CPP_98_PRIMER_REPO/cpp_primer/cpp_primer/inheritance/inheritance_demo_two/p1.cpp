#include <iostream> 
#include <cstdlib> 

class A 
{
	public: 
		A () {} 
		~A() {} 
		A (int i_in_num) : i_num (i_in_num) {} 
		void print_num (void) const {std::cout << "i_num:" << i_num << std::endl;} 
		virtual int get (void) const {return (i_num * 10);}
	private:
		int i_num; 
}; 

class B : public A 
{
	public: 
		B () {} 
		B (int i) : x (i) {} 
		B (int i_in_num, int i) : A(i_in_num), x (i) {} 
		void print_num (void) const {std::cout << "x:" << x << std::endl;} 
		int get (void) const {return (x * 20);} 
	private:
		int x; 
}; 

int main (void) 
{
	A *ptr1 = new A (100), *ptr2= new B (200), *ptr3 = new B (100, 300); 
	int rs; 

	ptr1->print_num (); 
	ptr2->print_num (); 

	rs = ptr1->get (); 
	std::cout << "ptr1->get ():" << rs << std::endl; 
	rs = ptr2->get (); 
	std::cout << "ptr2->get ():" << rs << std::endl; 
	rs = ptr3->A::get (); 
	std::cout << "ptr3->A::get ():" << rs << std::endl; 

	B *ptr4 = new B(200, 400); 
	rs = ptr4->A::get (); 
	std::cout << "END:" << rs << std::endl; 
	ptr4->print_num(); 
	return (0); 
}
