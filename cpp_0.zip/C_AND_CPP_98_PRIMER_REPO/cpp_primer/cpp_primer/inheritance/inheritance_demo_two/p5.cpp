#include <iostream> 
#include <cstdlib> 

class Base
{
	public: 
		Base () {} 
		~Base () {} 
		Base (int i_in_num) : i_num (i_in_num), d_num (0.0) {} 
		Base (double d_in_num) : i_num (0), d_num (d_in_num) {} 
		Base (int i_in_num, double d_in_num) : i_num (i_in_num), d_num (d_in_num) {} 
		void display (void) const 
		{
			std::cout << "i_num:" << i_num << std::endl << "d_num:" << d_num << std::endl; 
		}
		virtual void result (void) const 
		{
			std::cout << (i_num + d_num) * 10 << std::endl; 
		}
	private: 
		int i_num; 
	protected: 
		double d_num; 
}; 

class Derived : protected Base 
{
	public: 
		using Base::d_num;  
		using Base;    
		Derived (int i_in_num, double d_in_num) : Base (i_in_num, d_in_num) {} 
		void result (void) const 
		{
			std::cout << i_num + d_num << std::endl; 	
		}
};

int main (void) 
{
	Base b1, b2 (10), b3(34.12), b4 (100, 324.32); 
	b1.display (); b2.display (); b3.display (); b4.display (); 
	Base *ptrB = new Derived (10, 3.14); 
	ptrB->display (); 
	ptrB->result (); 

	return EXIT_SUCCESS; 
}
