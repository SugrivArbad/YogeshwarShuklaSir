#include <iostream> 
#include <cstdlib> 

class Base 
{
	public: 
		Base () {} 
		Base (int in_base_x) : base_x (in_base_x) {} 
		~Base () {} 
		virtual void apply (void) const 
		{
			std::cout << "In Base::apply" << std::endl 
				  << base_x * 10 << std::endl; 
		}
	protected: 
		int base_x; 
}; 

class Derived : public Base 
{
	public: 
		Derived () {} 
		Derived (int in_x)  
		{
			Base::base_x = in_x; 
		}
		void apply (void) const 
		{
			std::cout << "In Derived::apply" << std::endl 
				  << base_x + 10 << std::endl; 
		}
}; 

int main (void) 
{
	Base *ptrD = new Derived (10); 
	Base *ptrB = new Base (20); 
	ptrB->apply (); 
	ptrD->apply (); 
}
