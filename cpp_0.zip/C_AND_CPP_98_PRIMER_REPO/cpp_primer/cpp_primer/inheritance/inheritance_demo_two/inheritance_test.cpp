#include <iostream> 
#include <string> 
#include <cstdlib> 

class Base 
{
	public: 
		Base () {} 
		Base (int i_in_num, double d_in_num, long int li_in_num) : 
		      i_num (i_in_num), d_num (d_in_num), li_num (li_in_num) {} 
		~Base () {} 
		virtual double get_result (void) const 
		{
			std::cout << "In base class get_result" << std::endl; 
			return (i_num + d_num + li_num);
		}
	private: 
		int i_num; 
		double d_num; 
	protected: 
		long int li_num; 
}; 

class Derived : protected Base
{
	public: 

		Derived () {} 
		Derived (int i_in_num, double d_in_num, long int li_in_num, short int si_in_num) : 
			 Base (i_in_num, d_in_num, li_in_num), si_num (si_in_num) {} 

		double get_result (void) const 
		{
			double rs; 
			std::cout << "In derived:" << std::endl; 
			rs = Base::get_result (); 
			std::cout << "rs:" << rs << std::endl; 
		}
	private: 
		short int si_num; 
};

class DerivedTwo : public Derived 
{
	public: 
		DerivedTwo () {} 
		DerivedTwo (int i_in_num, double d_in_num, long int li_in_num, short int si_in_num, 
		    	    char c_in_ans) : Derived (i_in_num, d_in_num, li_in_num, si_in_num), 
				     c_ans (c_in_ans) {} 
		double get_result (void) const 
		{
			std::cout << "In Derived Two:" << std::endl; 
			std::cout << "li_num:" << li_num << std::endl; 
			std::cout << "c_ans:" << c_ans << std::endl; 
		}
	private:
		char c_ans; 
}; 

int main (void) 
{
	Base *p_base1 = new Derived (10, 3.14, 10000, 256); 
	Base *p_base2 = new DerivedTwo (10, 3.14, 10000, 256, 'A'); 
	Derived *p_derived = new DerivedTwo (100, 31.4, 100, 25, 'C'); 
//	std::cout << "Result:" << p_base1->get_result () << std::endl; 
	std::cout << "Result:" << p_base2->get_result () << std::endl; 
	std::cout << "Result:" << p_derived->get_result () << std::endl; 
	return (EXIT_SUCCESS); 
}
