#include <iostream> 
#include <cstdlib> 
class Base 
{
public: 
	Base (int i1=0, int i2=0) : i_num1 (i1), i_num2 (i2) {}
	~Base () {} 
	int get_num1 (void) const {return (i_num1);}
	int get_num2 (void) const {return (i_num2);}
	int set_num1 (int new_num) {i_num1 = new_num;}
	int set_num2 (int new_num) {i_num2 = new_num;}
protected: 
	int i_num2; 
private:
	int i_num1; 
}; 

class Derived : protected Base
{
public: 
	Derived (int i1=0, int i2=0, int i3=0) : Base (i1, i2), i_num3 (i3) {} 
	~Derived () {} 
	void dump (void) const 
	{
		std::cout << "i_num2:" << i_num2 << " i_num3:" << i_num3 << std::endl; 
		// Privates of base class are not accessible in derived 
		//std::cout << "i_num1:" << i_num1 << std::endl; 
	}
private: 
	int i_num3; 
}; 

class Derived2 : public Derived 
{
public:
	Derived2 (int i1=0, int i2=0, int i3=0, int i4=0) : 
			  	Derived (i1, i2, i3), i_num4 (i4) {} 
	~Derived2 () {} 

	int dump_nums (void) const 
	{
		std::cout << "i_num4:" << i_num4 << " i_num2:" << i_num2 << std::endl; 
	}
private: 
	int i_num4; 
}; 

int main (void) 
{
	// private : 10, protected : 20 
	Base *pb1 = new Base (10, 20); 
	// i_num1 : 100 i_num2 : 200 i_num3 : 300 
	Derived *pd1 = new Derived (100, 200, 300);
	pd1->dump (); 

	// Base class has been derived using protected access specifiers 
	// therefore, attributes having public and protected access specifiers 
	// in Base class will have protected access specifiers as a members of 
	// derived class. Therefore, from derived class pointer, reference 
	// get_num2 is protected. 'main' function is non-member function 
	// with respect to derived class, and therefore, does not have access 
	// to it's protected attribute. That explains why get_num2 is not 
	// accessible here. 
	std::cout << "i_num2:" << pd1->get_num2 () << std::endl; 
	
	// get_num2 is public from base class pointer perspective therefore, 
	// is accessible here. 
	std::cout << "i_num2:" << pb1->get_num2 () << std::endl; 

	// assigning derive d object's address to base class pointer 
	// DOES NOT change the scenario. get_num2 will not be accessible 
	// through pb2 because pd1 is of derived class. 
	//Base *pb2 = pd1; 
	//pb2->get_num2 ();

	Derived2 *pd2 = new Derived2 (10, 20, 30, 40); 
	pd2->dump_nums (); 
	//pd2->get_num2(); 
	delete pb1; 
	delete pd1; 
	delete pd2; 

	return (EXIT_SUCCESS); 
}
