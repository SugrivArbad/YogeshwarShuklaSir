#include <iostream> 
#include <cstdlib> 

class Base 
{
public: 
	Base (int i1=0, int i2=0) : i_num1 (i1), i_num2 (i2) {} 
	~Base () {} 
	int get_num1 (void) const {return (i_num1);}
	int get_num2 (void) const {return (i_num2);}
	void set_num1 (int new_num) {i_num1 = new_num;}
	void set_num2 (int new_num) {i_num2 = new_num;}
protected:
	int i_num2; 
private: 
	int i_num1; 
}; 

class Derived : private Base 
{
public: 
	Derived (int i1=0, int i2=0, int i3=0) : Base (i1, i2), i_num3 (i3) 
	{
		i_protected = -100; 
	}
	~Derived () {} 
	void dump (void) const 
	{
		std::cout << "i_num2:" << i_num2 << " i_num3:" << i_num3 << std::endl; 
	}
protected: 
	int	i_protected; // LEVEL 1 PROTECTED, NOT PROTECTED OF BASE  
private:
	int i_num3; 
}; 

class Derived2 : public Derived 
{
public: 
	Derived2 (int i1=0, int i2=0, int i3=0, int i4=0) : Derived (i1, i2, i3), 
				i_num4 (i4) {} 
	~Derived2 () {} 
	void dump_nums () const 
	{
		std::cout << "i_num4:" << i_num4 << std::endl; 
		std::cout << "i_protected:" << i_protected << std::endl; 
		// Dervied has derived Base class using private access specifier 
		// therefore, all protected and public members of base class appear 
		// private to Derived Object's observer. Therefore, this context, (member
		// function of derived class) has i_num2 as private member, therefore, 
		// cannot access in this context
		//std::cout << "i_num2:" << i_num2 << std::endl; 
	}
private: 
	int i_num4; 
}; 

int main (void)
{
	Base *pb1 = new Base (10, 20); 
	std::cout << "main:i_num1:" << pb1->get_num1 () << " i_num2:"
				 << pb1->get_num2 () << std::endl;

	Derived *pd1 = new Derived (100, 200, 300); ; 
	pd1->dump (); 
	
	// get_num2 is private when it becomes part of derived object 
	// pointed to by pd1 and main being a non-member function of 
	// Derived class, it's privates are NOT accessible in main. 
	// std::cout << "pd1->get_num2 ():" << pd1->get_num2 () << std::endl; 

	Derived2 *pd2 = new Derived2 (1000, 2000, 3000, 4000); 
	pd2->dump_nums (); 

	delete pb1;  
	delete pd1; 
	delete pd2; 

	return (EXIT_SUCCESS); 
}
