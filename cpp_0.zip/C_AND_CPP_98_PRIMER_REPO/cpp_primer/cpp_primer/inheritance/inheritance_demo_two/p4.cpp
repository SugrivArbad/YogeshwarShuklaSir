#include <iostream> 
#include <cstdlib> 

#define INDEX_ERROR 1 

class Base 
{
	protected:
		int *i_arr; 
		int nr_elements; 

		int get_element (int index) const 
		{
			if (index < 0 || index >= nr_elements)
				return INDEX_ERROR; 	
			return (i_arr[index]); 
		}

		int set_element (int index, int new_element) 
		{
			if (index < 0 || index >= nr_elements) 
				return INDEX_ERROR; 
			i_arr[index] = new_element; 
		}
		Base (int in_nr_elements) : nr_elements (in_nr_elements), 
					    i_arr (new int[in_nr_elements]) {}  
		Base () {} 
		~Base () 
		{
			std::cout << "In ~Base()" << std::endl; 
		} 

}; 

class Derived : protected Base 
{
	public: 
		Derived () {} 
		~Derived () 
		{
			std::cout << "In ~Derived" << std::endl; 
			delete [] i_arr; 
		}
		Derived (int in_nr_elements) : Base (in_nr_elements) {}  
		int get_element (int index) const 
		{
			return (Base::get_element (index)); 
		}
		void set_element (int index, int new_element) 
		{
			Base::set_element (index, new_element); 
		}
}; 

int main (void) 
{
	Derived *ptrD = new Derived (10); 
	Base *p = new Base();
	for (int i=0; i < 10; i++) 
	{
		ptrD->set_element (i, i*10); 
	}

	for (int i=0; i < 10; i++) 
	{
		std::cout << i << "th element:" << ptrD->get_element (i) << std::endl; 
	}
	
	delete ptrD; 

	return EXIT_SUCCESS; 
}
