#include <iostream> 
#include <cstdlib> 

class Interface{
	public: 
		virtual void f1(void) = 0; 
		virtual void f2(void) = 0; 
}; 

class Derived : public Interface{
	public:
	Derived() {} 

	void f1(void) { std::cout << "I am in derived f1" << std::endl; } 
	void f2(void) { std::cout << "I am in derived f2" << std::endl; } 
}; 

int main(void) 
{
	Interface *I = new Derived(); 
	I->f1(); 
	I->f2(); 
	delete I; 

	return 0; 
}
