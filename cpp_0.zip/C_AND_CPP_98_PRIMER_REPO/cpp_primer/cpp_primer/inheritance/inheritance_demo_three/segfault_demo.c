#include <stdio.h> 
#include <stdlib.h> 
#include <errno.h> 
#include <string.h> 
#include <unistd.h> 
#include <signal.h> 
#include <setjmp.h> 

void segfault_handler(int sig_num); 
jmp_buf jmp_buffer; 

int main(void){
	int *ptr = NULL, ret; 
	signal(SIGSEGV, segfault_handler);
	ret = setjmp(jmp_buffer);
	if(ret == 1)
		goto out;
	*ptr = 10; 
out: 
	printf("I am here\n"); 
	return (EXIT_SUCCESS);
} 

void segfault_handler(int sig_num){
	printf("I am in segfault_handler\n"); 
	longjmp(jmp_buffer, 1);
}
