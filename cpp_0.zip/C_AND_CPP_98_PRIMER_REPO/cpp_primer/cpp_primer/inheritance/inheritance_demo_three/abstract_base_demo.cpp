#include <iostream> 
#include <cstdlib> 

class Interface{
public:
	virtual void f1(void) = 0; 
	virtual void f2(void) = 0; 
	virtual void f3(void) = 0; 
	virtual void f4(void) = 0; 
}; 

class D1 : public Interface{
public:
	void f1(void) {std::cout << "This is D1's f1" << std::endl;}
	void f2(void) {std::cout << "This is D1's f2" << std::endl;}
}; 

class D2 : public D1
{
public: 	
	void f3(void) {std::cout << "This is D2's f3" << std::endl;}
	void f4(void) {std::cout << "This is D2's f4" << std::endl;}

};

int main(void){
	Interface *ptr = new D2(); 
	//Interface *ptr1 = new D1(); 
	ptr->f1(); 
	ptr->f2(); 
	ptr->f3(); 
	ptr->f4(); 
	delete ptr; 
	return (EXIT_SUCCESS); 
}
