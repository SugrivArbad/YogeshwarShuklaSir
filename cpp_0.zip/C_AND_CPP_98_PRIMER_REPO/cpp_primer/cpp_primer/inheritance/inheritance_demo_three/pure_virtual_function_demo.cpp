#include <iostream> 
#include <cstdlib> 
#include <ctime> 

#define SINGLY_LINKED_LIST 0 
#define DOUBLY_LINKED_LIST 1 

class ListInterface {
public:
	virtual void InsertBeg(void)=0; 
	virtual void InsertEnd(void)=0; 
	virtual void DeleteByPos(void)=0; 
	void normal_function(void) {std::cout << "I am not virtual" << std::endl;}
	int get_protected(void) const {return i_protected;}
protected: 
	int i_protected; 
}; 

class SinglyLinkedList : public ListInterface {
public: 
	SinglyLinkedList() {i_protected = 10;} 
	void InsertBeg(void) {std::cout << "Singly Linked List InsertBeg" << std::endl;}
	void InsertEnd(void) {std::cout << "Singly Linked List InsertEnd" << std::endl;}
	void DeleteByPos(void) {std::cout << "Singly Linked List DeleteByPos" << std::endl;}

private:
	//Singly Linked List Data 
}; 

class DoublyLinkedList : public ListInterface {
public: 
	DoublyLinkedList() {i_protected = 20;} 
	void InsertBeg(void) {std::cout << "Doubly Linked List InsertBeg" << std::endl;}
	void InsertEnd(void) {std::cout << "Doubly Linked List InsertEnd" << std::endl;}
	void DeleteByPos(void) {std::cout << "Doubly Linked List DeleteByPos" << std::endl;}
private:
	//Singly Linked List Data 
}; 

ListInterface *ChooseList(int param){
	if(param == SINGLY_LINKED_LIST)
		return new SinglyLinkedList(); 
	else if(param == DOUBLY_LINKED_LIST)
		return new DoublyLinkedList(); 
}

int main(void){
	srand(time(0));
	ListInterface *ptr = ChooseList(rand() % 2); 
	//ListInterface *ptr1 = new ListInterface(); 
	
	ptr->InsertBeg(); 
	ptr->InsertEnd(); 
	ptr->DeleteByPos(); 
	ptr->normal_function(); 
	std::cout << "ptr->get_protected():" << ptr->get_protected() << std::endl; 
	
	return EXIT_SUCCESS; 
}
