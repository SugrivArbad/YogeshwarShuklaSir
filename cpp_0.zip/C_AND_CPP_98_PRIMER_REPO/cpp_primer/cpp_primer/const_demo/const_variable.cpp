#include <iostream> 

int main (void) 
{
	// const int i_num; // This generates compile time error 
	// must initialize const object
	const int i_num=100; 
	std::cout << "i_num:" << i_num << std::endl; 
	// i_num = 200; //This generates compile time error
	
	// Try to access const object through non const pointer 
	 int *ptr = &i_num; // This generates compiler time error 
	// cannot assign const int * to int *
		

	const int *c_ptr = &i_num; 
	// c_ptr can be used to read data from i_num
	// i_num can be made visible in other function scope depending 
	std::cout << "*c_ptr=" << *c_ptr << std::endl; 
	// Cannot write upon the same. 
	// *c_ptr = 200; // Generates a compile time erorr 
	
	// Create  non const data elements 
	int i_num2=200, i_num3=300; 
	// Create constant pointer 
	int *const ptr = &i_num2; 
	// Read i_num2 through ptr 
	std::cout << "*ptr:" << *ptr << std::endl; 
	*ptr = 500; 
	std::cout << "i_num2:" << i_num2 << std::endl; 
	const int *const ptr1 = &i_num; 
	//*ptr1 = 600;  // Compilation error
	const int ci_num = 800; 
	// ptr1 = &ci_num; // compilation error 
	return 0; 
}
