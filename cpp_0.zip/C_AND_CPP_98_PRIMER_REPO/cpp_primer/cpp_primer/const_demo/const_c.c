#include <stdio.h> 
#include <stdlib.h> 

const int global_const_int = 100; 

int main (void) 
{	
	int *ptr; 
	const int i_num=100; 
//	int printf (const char *fmt, ...); 
	ptr = &i_num; 
	*ptr = 200; 
	printf ("*ptr=%d\n", *ptr); 
	ptr = &global_const_int; 
	*ptr = 300; 
	return (0); 
}
