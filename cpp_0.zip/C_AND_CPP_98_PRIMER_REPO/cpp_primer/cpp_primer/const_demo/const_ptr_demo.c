#include <stdio.h> 
#include <stdlib.h> 

int main(void) 
{
	int num = 10; 
	int num1 = 500; 
	int *const ptr = &num; 
	
	printf("*ptr = %d\n", *ptr); 
	*ptr = 200; 
	printf("*ptr = %d\n", *ptr); 
	ptr = &num1; 
	return EXIT_SUCCESS; 
}
