#include <stdio.h> 
#include <stdlib.h> 

const int num = 100; 

int main (void) 
{
	printf ("num:%d\n", num); 
	num = 200; /* Expected compile time error */ 

	exit (EXIT_SUCCESS); 
}
