int main(void) 
{
	const int n; 
	int const n; 
		
	const int *p; 
	int const *p;ear
	int n; 
	int const *p = &n; 

	return (0); 
}
