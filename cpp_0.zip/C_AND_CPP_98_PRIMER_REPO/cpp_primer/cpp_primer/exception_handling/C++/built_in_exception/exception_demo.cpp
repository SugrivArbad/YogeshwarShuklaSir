#include <iostream> 
#include <stdexcept> 
#include <cstdlib> 

typedef int index_t; 
typedef int data_t; 

class Array 
{
	public: 
		Array(size_t size) 
		{
			length = size; 
			array = new int[length]; 
		}

		~Array()
		{
			delete[] array; 
		}

		int get(index_t index) const 
		{
			if (index < 0 || index >= length)
					throw std::out_of_range("get:Array out of range"); 
			return (array[index]); 
		}

		void set(index_t index, data_t data)
		{
			if (index < 0 || index >= length) 
					throw std::out_of_range("set:Array out of range"); 
			array[index] = data; 
		}
	
		int len(void)const
		{
			return (length); 
		}
			
		void display(void) const 
		{
			for(int i=0; i < length; ++i)
					std::cout << "array[" << i << "]:" << array[i] << std::endl; 
		}
	
	private:
		int *array; 
		size_t length; 
}; 

int main(void) 
{
	Array *A = new Array(10); 
	
	for(int i=0; i < A->len(); i++) 
		A->set(i, (i+1)*10); 
	
 	try{
		std::cout << "A->get(15):" << A->get(15) << std::endl; 
	}catch(std::out_of_range &e)
	{
		std::cout << "Tried to access element out of range" << std::endl; 
	}
	
	std::cout << "I can still continue with the program" << std::endl; 

	return (EXIT_SUCCESS);  
}
