#include <iostream> 
#include <cstdlib> 
#include <cstring> 
#include <stdexcept> 

void *xcalloc(unsigned long int, unsigned long int); 

int main(void) 
{
	try{
	int *arr = (int*)xcalloc(1000000000UL, 1000000000UL);
	}catch(std::bad_alloc &e){
		std::cout << e.what() << std::endl; 
	}
	return (EXIT_SUCCESS); 
}

void *xcalloc(unsigned long int nr_elements, unsigned long int size_per_element) 
{
	void *ptr = calloc(nr_elements, size_per_element); 
	if(!ptr) 
		throw std::bad_alloc(); 
	return (ptr); 
}
