#include <stdio.h> 
#include <stdlib.h> 
#include <setjmp.h> 

jmp_buf buffer; 

void f1 (void); 
void f2 (void); 
void f3 (void); 

void g1 (void); 
void g2 (void); 
void g3 (void); 
void g4 (void); 

int main (void) 
{ 
	int ret; 

	ret = setjmp (buffer); 
	switch (ret) 
	{
		case 0: 
				printf ("Just set a jump\n"); 
				break; 
		case 1: 
				printf ("Returned from f3\n"); 
				goto handler1
		case 2: 
				printf ("Returned from g4\n"); 
				goto handler2 
		default: 
				printf ("Grave error\n"); 
				exit (EXIT_FAILURE); 
	}
	
	if (ret == 0) 
		f1 (); 
	if (ret != 2)  
		g1 (); 


		goto out_success
handler1:
	// handler
		goto out
handler2: 
	// handler 
		goto out 

out: 
	exit(EXIT_FAILURE); 
out_success: 
	exit (EXIT_SUCCESS); 
}

void f1 (void) 
{
	f2 (); 
}

void f2 (void) 
{
	f3 (); 
}

void f3 (void)
{
	longjmp (buffer, 1); 
}

void g1 (void) 
{
	g2 (); 
}

void g2 (void) 
{
	g3 (); 
}

void g3 (void) 
{
	g4 (); 
}

void g4 (void)
{
	longjmp (buffer, 2); 
}


try{
	st1; 
	st2; 
	st3;f()

	stn; 
}
catch (Exception &e){
	st1; 
	st2; 
	st3; 
}	




void f(void) 
{
	f1(); 
}

void f1(void) 
{
	f2(); 
}

void f2(void)
{
	f3(); 
}

void f3(void) 
{

	if(error)
		throw runtime_error("Something went wrong"); 
}





