#include <iostream> 
#include <cstdlib> 
#include <typeinfo> 

char c_ans; 
unsigned char uc_ans; 
short int si_num; 
unsigned short int usi_num; 
int i_num; 
unsigned int ui_num; 
long int li_num; 
unsigned long int uli_num; 
long long int lli_num; 
unsigned long long int ulli_num; 
float f_num; 
double d_num; 
long double ld_num; 

int i_arr[10]; 

class Base1
{
public:
	Base1() {}
	~Base1() {}
}; 

class Derived1 : public Base1
{
public:
	Derived1() {} 
	~Derived1() {} 
}; 

class Base2
{
	public:
		Base2() {} 
		~Base2() {} 
		virtual void f(void) {std::cout << "Base2" << std::endl;} 
}; 

class Derived2 : public Base2
{
	public:
		Derived2() {} 
		~Derived2() {} 
		void f(void) {std::cout << "Derived2" << std::endl;} 
};

struct A 
{
	int i_num; 
	char c_ans; 
	double d_num; 
}inA; 

int main(void) 
{
	std::cout << "typeid(c_ans):" << typeid(c_ans).name() << std::endl
		  << "typeid(uc_ans):" << typeid(uc_ans).name() << std::endl
		  << "typeid(si_num):" << typeid(si_num).name() << std::endl
		  << "typeid(usi_num):" << typeid(usi_num).name() << std::endl
		  << "typeid(i_num):" << typeid(i_num).name() << std::endl 
		  << "typeid(ui_num):" << typeid(ui_num).name() << std::endl 
		  << "typeid(li_num):" << typeid(li_num).name() << std::endl
		  << "typeid(uli_num):" << typeid(uli_num).name() << std::endl 
		  << "typeid(lli_num):" << typeid(lli_num).name() << std::endl 
		  << "typeid(ulli_num):" << typeid(ulli_num).name() << std::endl
		  << "typeid(f_num):" << typeid(f_num).name() << std::endl 
		  << "typeid(d_num):" << typeid(d_num).name() << std::endl 
		  << "typeid(ld_num):" << typeid(ld_num).name() << std::endl; 

	std::cout << "typeid(&c_ans):" << typeid(&c_ans).name() << std::endl
		  << "typeid(&uc_ans):" << typeid(&uc_ans).name() << std::endl
		  << "typeid(&si_num):" << typeid(&si_num).name() << std::endl
		  << "typeid(&usi_num):" << typeid(&usi_num).name() << std::endl
		  << "typeid(&i_num):" << typeid(&i_num).name() << std::endl 
		  << "typeid(&ui_num):" << typeid(&ui_num).name() << std::endl 
		  << "typeid(&li_num):" << typeid(&li_num).name() << std::endl
		  << "typeid(&uli_num):" << typeid(&uli_num).name() << std::endl 
		  << "typeid(&lli_num):" << typeid(&lli_num).name() << std::endl 
		  << "typeid(&ulli_num):" << typeid(&ulli_num).name() << std::endl
		  << "typeid(&f_num):" << typeid(&f_num).name() << std::endl 
		  << "typeid(&d_num):" << typeid(&d_num).name() << std::endl 
		  << "typeid(&ld_num):" << typeid(&ld_num).name() << std::endl; 

	std::cout << "typeid(i_arr):" << typeid(i_arr).name() << std::endl; 
	std::cout << "typeid(inA):" << typeid(inA).name() << std::endl; 
	std::cout << "typeid(&i_arr):" << typeid(&i_arr).name() << std::endl; 
	std::cout << "typeid(&inA):" << typeid(&inA).name() << std::endl; 

	Base1 *ptr1=new Base1(), *ptr2=new Derived1(); 
	Derived1 *ptr3=new Derived1(); 

	std::cout << "typeid(*ptr1):" << typeid(*ptr1).name() << std::endl
		  << "typeid(*ptr2):" << typeid(*ptr2).name() << std::endl 
		  << "typeid(*ptr3):" << typeid(*ptr3).name() << std::endl; 

	Base2 *ptr11=new Base2(), *ptr22=new Derived2(); 
	Derived2 *ptr33=new Derived2(); 

	std::cout << "typeid(*ptr11):" << typeid(*ptr11).name() << std::endl
		  << "typeid(*ptr22):" << typeid(*ptr22).name() << std::endl 
		  << "typeid(*ptr33):" << typeid(*ptr33).name() << std::endl; 

	return EXIT_SUCCESS; 
}
