int my_add (int, int); 

int my_add (int n1, int n2) 
{
	return (n1+n2); 
}

int sum = my_add (10, 20); 
