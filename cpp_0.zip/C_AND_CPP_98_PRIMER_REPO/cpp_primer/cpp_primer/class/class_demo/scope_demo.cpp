#include <iostream> 

using namespace std; 

int x = 1000; 

namespace test 
{
	int x; 
}; 

int main (void) 
{
	int x = 100; 
	int y=10; 

	cout << "::x=" << ::x << endl; 
	cout << "x=" << x << endl; 
	
	if (y > 0) 
	{
		int x = 500; 
		cout << "x=" << x << endl; 
		cout << "::x=" << ::x << endl; 
	}

	test::x = 10000; 
	cout << "test::x=" << test::x << endl; 
	
	return (0); 
} 
