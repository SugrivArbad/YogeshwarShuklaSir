#include <iostream> 
#include <cstdlib> 

class IntPtr
{
    friend class HasPtr; 
    private:
        int* ptr; 
        unsigned int ref_count; 
        
        IntPtr(int _ptr_val) : ptr(new int(_ptr_val)), ref_count(1)
        {
        }

        ~IntPtr()
        {
            delete ptr; 
        }
}; 

class HasPtr
{
    private: 
        int n; 
        IntPtr* p; 
    
    public: 
        HasPtr(int _n, int _ptr_val): n(_n), p(new IntPtr(_ptr_val))
        {

        }

        HasPtr(const HasPtr& other) : n(other.n), p(other.p)
        {
            ++p->ref_count; 
        }

        HasPtr& operator=(const HasPtr& other)
        {
            this->n = other.n; 
            if(--this->p->ref_count == 0)
                delete this->p; 
            this->p = other.p; 
            ++this->p->ref_count; 
            return *this; 
        }
}; 

//  Dynamic Memory Allocation & Pointer 
//  Understanding & Using C Pointers -> Richard Reese -> Oreilly Public
