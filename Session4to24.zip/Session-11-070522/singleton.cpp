#include <stdio.h> 
#include <stdlib.h> 
#include <stdexcept>

class Singleton
{
    private: 
        int m, n; 
        static int obj_count; 
        Singleton(int _m, int _n) : m(_m), n(_n)
        {
            // what if friend betrays you! 
            if(obj_count > 0)
                throw std::runtime_error("SINGLETON!!");             
        }

    public: 
        static Singleton* get_singleton_object(int m, int n)
        {
            if(obj_count == 0)
            {
                Singleton* p = new Singleton(m, n); 
                obj_count = 1;
                return p; 
            }
            else 
            {
                puts("Only one object can be created of this class\n"); 
                return (NULL); 
            }
        }
}; 

int Singleton::obj_count = 0; 

int main(void)
{
    Singleton* p1 = Singleton::get_singleton_object(100, 200); 
    if(p1 != NULL)
        puts("Only one object that can be created has been created"); 

    Singleton* p2 = Singleton::get_singleton_object(300, 400); 
    if(p2 == NULL)
        puts("Singleton property is enforcing!"); 

    delete p1; 
    p1 = NULL; 

    return (0); 
}