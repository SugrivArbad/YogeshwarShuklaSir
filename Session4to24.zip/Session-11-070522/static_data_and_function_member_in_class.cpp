#include <stdio.h> 
#include <stdlib.h> 

class Test 
{
    private: 
        int m, n;   // non-static data members  
    public: 
        static int p, q;    // static data members 
        
        Test() : m(0), n(0) 
        {
            
        }  
        
        int get_m() 
        {   
            return m; 
        }
        
        int get_n() 
        { 
            return n; 
        }
        
        void set_m(int new_m) 
        { 
            m = new_m; 
        }
        
        void set_n(int new_n) 
        { 
            n = new_n; 
        }
        
        void test_non_static_function()
        {
            m = 100; 
            n = 200; 
            p = 300; 
            q = 400; 
        }

        static void test_static_function(void)
        {
            printf("p = %d, q=%d\n", p, q); 
            // cannot access m & n 
        }
};  

int Test::p = 20; 
int Test::q = 30; 

int main(void)
{
    Test t; 
    t.get_m();  // &t implicitly sent parameter 
    t.get_n();  // &t implicitly sent parameter
    t.set_m(100);   // &t implicitly sent parameter
    t.set_n(200);   // &t implicitly sent parameter
    t.test_non_static_function();   // &t implicitly sent parameter
    t.test_static_function(); // &t IS NOT sent as implicit parameter 
    Test::test_static_function(); // class name can be used to reach 
                                    // to a static function 
    // Test::get_m();   // ERROR. Class name cannot be used to access 
                        // non-static members

    t.p = 1000; // ok 
    t.q = 2000; // ok 
    Test::p = 10000; //ok 
    Test::q = 20000; // ok                         
}

//  nonstatic data member: non-static function can access 
//  static data member : static + non static functions can acces 

//  static member function : can access static data 
//  non-static member function : can static + non-static data 

//  Object Name or Object Ptr Or Object Ref is MUST for accessing non-static function
//  Object Name, Object Ptr, Object Ref, OR CLASS NAME can be used for 
//  accessing static function 

//  d.set_day(25); 

//  Date::set_day(&d); 