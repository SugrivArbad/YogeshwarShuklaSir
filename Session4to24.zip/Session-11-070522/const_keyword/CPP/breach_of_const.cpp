#include <stdio.h> 
#include <stdlib.h> 

//  CTE -> Compile Time Error 
//  CTW -> Compile Time Warning 
//  RTE -> Run Time Error 

const int g_num = 100; 

int main(void)
{
    const int l_num = 200; 
    int* p1 = NULL; 
    int* p2 = NULL; 

    printf("Initial:g_num=%d, l_num=%d\n", g_num, l_num); 

    //  g_num = 1000;   // CTE 
    //  l_num = 2000;   // CTE 
    p1 = &l_num;    // CTE
    p2 = &g_num;    // CTE

    *p1 = 2000;     // l_num (200->2000)
    //*p2 = 1000;     //  Memory violation exeption RTE (RunTimeError)
    printf("Final:g_num=%d, l_num=%d\n", g_num, l_num); 
    return (0); 
}



