#include <stdio.h> 
#include <stdlib.h> 

//  const T v_name = compulsory_initializer; 

const int global_data = 10; 

int main(void)
{
    const int local_data = 100; 

    //  global_data = 1000;    // CTE 
    //  local_data = 1000;  // CTE 

    int* p1; 
    int* p2; 

    p1 = &global_data; 
    p2 = &local_data; 

    //*p1 = 1000;     // an attempt will be made to write on data data
    *p2 = 1000;     // an attempt will be made to write on local data 

    return (0); 
}