#include <stdio.h> 
#include <stdlib.h> 

struct T {
    // some members 
    int n; 
}; 

void read_write(struct T* p); 
void read_only(const struct T* p); 

int main(void)
{
    struct T instance_of_T; 

    //  state before 
    read_write(&instance_of_T); 
    //  state after 
    //  change cannot be predicted 
    //  unless source code of function read_write() 
    //  is known OR the documentation of read_write() function 
    //  documents the change! 

    // before 
    read_only(&instance_of_T); 
    // after == before is guaranteed 
}