#include <stdio.h> 
#include <stdlib.h> 

//  CTE -> Compile Time Error 
//  CTW -> Compile Time Warning 
//  RTE -> Run Time Error 

const int g_num = 100; 

int main(void)
{
    const int l_num = 200; 
    int* p1 = NULL; 
    int* p2 = NULL; 

    printf("Initial:g_num=%d, l_num=%d\n", g_num, l_num); 

    //  g_num = 1000;   // CTE 
    //  l_num = 2000;   // CTE 
    p1 = &l_num;    // CTW 
    p2 = &g_num;    // CTW

    *p1 = 2000;     // l_num (200->2000)
    //*p2 = 1000;     //  Memory violation exeption RTE (RunTimeError)
    printf("Final:g_num=%d, l_num=%d\n", g_num, l_num); 
    return (0); 
}

//  lhs = rhs 
//  rhs evaluate 
//  lhs evaluate 

// rhs & lhs type evaluate 

//  int a=10, b=20, c; 
//  c = a + b; 

//  a:int 
//  b:int 
//  a + b: int  (inference)
//  c:int 
//  rhs type, lhs type comatibility 
//  rhs type = lhs type -> well and good 
//  rhs type != lhs type (Implicit type conversion will be attempted)
//  if implicity type conversion is not possible then 
//  depending on the severity, compile time warning or error will be issued

//  struct Date d; 
//  int* p; 
//  p = &d; 
//  rhs -> struct Date* 
//  lhs -> int* 

//  short s; 
//  long l; 
//  l = s; 
//  rhs type -> short int 
//  lhs type -> long int 

//  const int g_num = 100; 
//  int* p; 
//  p = &g_num;     
//  type of rhs = const int* 
//  type of lhs = int* 

