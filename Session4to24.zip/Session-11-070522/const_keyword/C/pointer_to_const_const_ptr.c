#include <stdio.h> 
#include <stdlib.h> 

void case_1(void); 
void case_2(void); 
void case_3(void); 
void case_4(void); 

int main(void)
{
    case_1(); 
    case_2(); 
    case_3(); 
    case_4(); 
    return (0); 
}

void case_1(void)
{
    int* p; 
    int* p1; 

    int m; 
    int n; 

    p = &m;     // p can be written to 
    p = &n; 
    p1 = p;     // p can be read from 

    *p = 100;   //  through p, n can be written to 
    m = *p;     //  through p, n can read from    
}

void case_2(void)
{
    int m = 10; 
    int n = 20; 
    const int* p1; 
    const int* p;   // p is pointer to const int 
    // here the const is applied to pointee
    //  pointer p can be read from 
    //  pointer p can be written to 
    //  through p, pointee can be read from 
    //  through p, the pointee CANNOT BE WRITTEN TO ! 

    p = &m;     // p can be written to 
    p1 = p;     // p can be read from 

    n = *p;     // through p, m can be read from 
    //*p = 500;   // through p, m CANNOT BE WRITTEN TO! // CTE 
}

void case_3(void)
{
    int m = 100; 
    int n = 200; 
    int* p1; 
    int* const p = &m;  // p is const pointer to int 
    //  here, const property is applied to pointer p 
    //  consequences 
    //  p must be initialized, because we cannot modify it later using assignment 
    //  p cannot change the address within itself 
    //  p can be read from 
    p1 = p;     // p can be read from 
    n = *p;     // through p, m can be read from 
    *p = 500;   // through p, m can be written to 

    //p = &n;     //  p CANNOT BE WRITTEN TO // CTE 

}

void case_4(void)
{
    int m = 10; 
    const int *const p = &m; 
    //  p cannot be written to 
    //  p can be read from 
    //  through p, m CANNOT be written to 
    //  through p, m can be read from 
    //  const T* const p = address of instance of T 
    //  p cannot pointe to any other instance of T 
    //  through p, you cannot modify the instance of T 
    //  whose address is  in p 
}

/* 
    A word about pointer syntax 

    int* p; 

    int *p; 

    *p = rhs;   // through p, write on pointee 
    lhs = *p;   // through p, read from pointee

    int* p -> type(p) = pointer to int 
            -> type(*p) = int 

    const int* p; 

    type(*p) -> const int 
    lhs = *p; // ok 
    *p = rhs; // error 

    lhs = p; // ok 
    p = rhs; //ok 

    int *const p = &n; 

    const T* p; 
    T* const p = init_compulsory; 
*/ 