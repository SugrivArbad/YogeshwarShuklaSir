class Base
{
	protected:
		int data;
	
	public:
		Base(int _data): data(_data){}

	protected:
		void f1()
		{
			std::cout << "In Base::f1()" << std::endl;
			std::cout << "In Base::f1()" << std::endl;
		}
};

class Derived
{
	public:
		void 


}
