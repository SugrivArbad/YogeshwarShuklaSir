#include <iostream> 

// NOT RECOMMENDED 
class Base 
{
    public: 
    // default CC
    Base()
    {
        std::cout << "Inside Base::Base" << std::endl; 
    }
}; 

class Derived : public Base 
{
    public: 
        // default CC 
        Derived() : Base()
        {
            std::cout << "Inside Derived::Derived" << std::endl; 
        }
}; 

// RECOMMENDED 
class B1 
{
    public: 
        B1()
        {
            std::cout << "In default CC of B1" << std::endl; 
        }

        B1(int x, int y)
        {
            std::cout << "In Parameterized CC of B1" << std::endl; 
        }
}; 

class D1: public B1 
{
    private: 
        double x, y; 
    public: 
        D1(double _x, double _y) : B1(), x(_x), y(_y)
        {

        }

        D1() : B1(100, 200), x(1.1), y(2.2)
        {

        }
}; 

int main(void)
{
    Derived d; 

    return 0; 
}

/* 
    Option 1: Not recommended: 
        Do not place a call to base class constructor through 
        the constructor initializer list of ther derived class. 

        This will compel compiler to synthesize a call to Base 
        class constructor. 

        But such synthesized call can be made to Base default 
        constructor only (because compiler is in no position to 
        generate parameters for parameterized constructor of Base)

        Therefore, the base class should have a default constructor 
        for this option to work 

        (Summary: Dont call Base class constructor thorugh the initlaizer 
        list of derived class constructor and keep a default 
        constructor in Base)

    Option 2: [STRONGLY RECOMMENDED]
        The base class may have only default, only parameterized, 
        or both constructors. 

        Make an EXPLICIT call to desired constructor through 
        derived class's constructor initializer list 

    Rule: 
    While writing the consturctor of derived class, first make an 
    explicit call to Base class constructor in the initializer list 
    and then initialize derived class specific data members 
*/ 