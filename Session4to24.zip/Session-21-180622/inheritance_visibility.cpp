#include <iostream> 
#include <cstdlib> 

void test_case_1(void); 
void test_case_2(void); 

class Employee
{
    private: 
        int emp_id; 
        static int id; 
    public: 
        Employee() : emp_id(id++)
        {

        }

        int get_id() const 
        {
            return emp_id; 
        }
}; 

int Employee::id = 1; 

class Manager : public Employee
{
    private: 
        int team_size; 
    public: 
        Manager(int _team_size): Employee(), team_size(_team_size)
        {

        }

        int get_team_size() const 
        {
            return team_size; 
        }
}; 

void test_case_1(void)
{
    Employee* pEmp = NULL; 
    Manager* pMan = NULL; 

    pEmp = new Manager(4); 
    pMan = new Manager(8); 

    std::cout << "ID:" << pEmp->get_id() << std::endl
            << "ID:" << pMan->get_id() << std::endl; 

    delete pEmp; 
    delete pMan; 
}

void test_case_2(void)
{
    Employee* pEmp = NULL; 
    Manager* pMan = NULL; 

    pEmp = new Manager(4); 
    pMan = new Manager(8);

    pMan->get_team_size(); // allowed 
    pEmp->get_team_size(); // CTE 

    reinterpret_cast<Manager*>(pEmp)->get_team_size();  // allowed 

    delete pEmp; 
    delete pMan; 
}