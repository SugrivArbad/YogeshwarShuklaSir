#include <iostream> 
#include <cstdlib> 

class A 
{
    private: 
        int a, b; 
}; 

class B : public A
{
    private: 
        double x, y; 
}; 

int main(void) 
{
    std::cout << "sizeof(A):" << sizeof(A) << std::endl; 
    std::cout << "2 * sizeof(double):" << 2 * sizeof(double) << std::endl; 
    std::cout << "sizeof(A) + 2 * sizeof(double):" << sizeof(A) + 2 * sizeof(double) << std::endl;
    std::cout << "Sizeof(B):" << sizeof(B) << std::endl; 

    return 0; 
}