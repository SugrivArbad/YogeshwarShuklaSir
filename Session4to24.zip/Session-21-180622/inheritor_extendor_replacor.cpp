#include <iostream> 
#include <cstdlib> 

class B1
{    
    public: 
        B1() 
        {

        }

        void f1()
        {
            std::cout << "In B1::f1()" << std::endl; 
        }

        void f2()
        {
            std::cout << "In B1::f2()" << std::endl; 
        }

        void f3()
        {
            std::cout << "In B1::f3()" << std::endl; 
        }
}; 

class D1 : public B1 
{
    public: 
        D1() : B1() 
        {

        }

        void f2()
        {
            B1::f2(); 
            std::cout << "In D1::f2()" << std::endl; 
        }

        void f3()
        {
            std::cout << "In D1::f3()" << std::endl; 
        }

        void g()
        {
            std::cout << "In D1::g()" << std::endl; 
        }
}; 

int main(void) 
{
    D1 objD1; 

    objD1.f1();     // Inherit
    objD1.f2();     // Extend 
    objD1.f3();     // Replace 
    objD1.g();      // Derived specific method 

    return 0; 
}

// If Derived class re-implements one of the member functions 
// in base class then it is known as overriding the member function of the base 
// overridden method 

// extending 
// replacing 

/* 
class Employee 
{
    private: 
        double salary; 
    public: 
        double getSalary() const 
        {
            return salary; 
        }
}; 

class Manager : public Employee
{
    public: 
    // extension 
        double getSalary()
        {
            double baseSal; 
            double effectiveSal; 
            baseSal = Employee::getSalary(); 
            effectiveSal = applyAllowances(baseSal); 
            return effectiveSal; 
        }
}; 

class Architect: public Employee 
{
    public: 
        double getSalary()
        {
            // total new computation of salary 
        }
}; 
*/ 

//  objD1.f1();     // Inherit