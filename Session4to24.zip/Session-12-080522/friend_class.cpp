#include <stdio.h> 
#include <stdlib.h> 

class Test
{
private: 
    int m, n; 

public: 
    Test(int _m, int _n) : m(_m), n(_n) 
    {

    }

    friend class X; 
};

class X
{
    public: 
        void f1()
        {
            Test t1(1, 2); 
            t1.m = -1; 
            t1.n = -2; 
        }

        void f2()
        {
            Test* pT = new Test(10, 20); 
            pT->m = -10; 
            pT->n = -20; 
            delete pT; 
            pT = 0; 
        }

        void f3()
        {
            Test& ref = *(new Test(100, 200)); 
            ref.m = -100; 
            ref.n = -200; 
            delete &ref; 
        }
}; 

int main(void)
{
    
}
