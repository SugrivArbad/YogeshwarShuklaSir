#include <stdio.h> 
#include <stdlib.h> 

/* A word about mutable keyword 
    1]  The object must be in read/write area 
        for it to work
*/  

class Date
{
    private: 
        int day, month, year; 
        mutable int nr_get_day_calls; 
    public: 
        Date(int _day, int _month, int _year) : day(_day), 
                                                month(_month), 
                                                year(_year)
        {

        }

        int get_day() const 
        {
            //  nr_get_day_calls can be modified 
            //  in const member function due to 
            //  keyword mutable! 
            nr_get_day_calls = nr_get_day_calls + 1; 

            // mutable keyword is a replacement for 
            //  repeatedly writing const cast 
            //  to achieve the same result. 
            //  const_cast expression whch is required 
            //  to achieve the effect is show below 
            // const_cast<Date*>(this)->nr_get_day_calls += 1; 
            return day; 
        }

}; 

int main(void)
{

}