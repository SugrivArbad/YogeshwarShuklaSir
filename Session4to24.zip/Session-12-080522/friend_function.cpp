#include <stdio.h> 
#include <stdlib.h> 

class Test
{
private: 
    int m, n; 

public: 
    Test(int _m, int _n) : m(_m), n(_n) 
    {

    }

    friend void test_function(void); 
}; 

void test_function(void)
{
    Test t(111, 222); 
    printf("t.m=%d\tt.n=%d\n", t.m, t.n); 
    // t.test_function();   // NOT ALLOWED 
    //  friend function is not a member function of a class! 
}

int main(void)
{
    Test t1(1, 2); 
    Test* pT = new Test(10, 20); 

    // all four expressions are not 
    //  allowed either on LHS or RHS 
    //t1.m; 
    //t1.n; 
    //pT->n; 
    //spT->m; 
    delete pT; 
    pT = 0; 
    ///////////////////////////////////

    test_function(); 
    return (0); 
}

//  BODY -> DECAY 
//  OXIDATION PROCESS 
//  OXYGEN 
//  शरीर = शीरयते इति शरीराम