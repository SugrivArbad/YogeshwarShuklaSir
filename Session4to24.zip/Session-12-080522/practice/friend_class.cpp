#include <stdlib.h>
#include <stdio.h>

class Test
{
	private:
		int m;
		int n;
	
	public:
		Test(int _m, int _n): m(_m), n(_n){}

		int get_m()
		{
			return m;
		}

		int get_n()
		{
			return n;
		}

		void set_m(int _m)
		{
			m = _m;
		}

		void set_n(int _n)
		{
			n = _n;
		}
};

class X
{
	public:
		void f1(Test inT)
		{
			printf("\n Using object passing: Before: f1 inT m & n: %d & %d", inT.get_m(), inT.get_n());
		
			inT.set_m(10);
			inT.set_n(20);
		
			printf("\n Using object passing: After: f1 inT m & n: %d & %d", inT.get_m(), inT.get_n());
		}
};

int main()
{
	Test T(1, 2);
	
	X inX;
	inX.f1(T);

	printf("\n\n");
}
