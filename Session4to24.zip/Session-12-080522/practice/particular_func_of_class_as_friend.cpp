#include <stdlib.h>
#include <stdio.h>

class X
{
	public:
		void f1();
};

class Test
{
	private:
		int m;
		int n;
	
	public:
		Test(int _m, int _n): m(_m), n(_n){}

		friend void X::f1();
};

void X::f1()
{
	Test inT(1, 2);
	printf("\n Before: f1 inT m & n: %d & %d", inT.m, inT.n);

	inT.m = 10;
	inT.n = 20;

	printf("\n After: f1 inT m & n: %d & %d", inT.m, inT.n);
}

int main()
{
	X inX;
	inX.f1();

	printf("\n\n");
}
