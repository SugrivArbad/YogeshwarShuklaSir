1] Design 

Read a single file implementation of dcll_1.c given in DCLL_C folder 

and modularize code as follows 

list.h 

list_server.cpp 

list_client.cpp 

Decide and implement the code in each file. 

Use all features of class statement so far. 

HINT: 
Split struct node in two classes 
class list_node -> struct node 
class list      -> a class containing pointer to head/dummy node 

You will have occasion to use 

private data 
private member functions 
public member functions 

non-static member functions 
static member functions 
const member functions 

friend class 


//  Saturday -> destructor 
//  list 