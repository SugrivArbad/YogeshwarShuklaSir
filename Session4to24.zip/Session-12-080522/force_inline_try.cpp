#include <stdio.h> 
#include <stdlib.h> 

// 'inline' removes prologue and epilogue from assembly
inline int max(int a, int b)
{
    return (a > b) ? (a) : (b); 
}

int main(void)
{
    int m; 
    m = max(10, 20); 
    return (0); 
}
