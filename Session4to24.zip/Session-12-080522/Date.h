#pragma once 

typedef int day_t; 
typedef int month_t; 
typedef int year_t; 

class Date
{
    private: 
        day_t day; 
        month_t month; 
        year_t year; 
        
        static bool is_year_leap(year_t year); 
        static bool is_date_valid(day_t day,  month_t month, year_t year);

    public: 

        Date(int day, int month, int year); 
        Date(); 
        Date(char* date_str); 

        day_t get_day() const; 
        month_t get_month() const; 
        year_t get_year() const; 

        void set_day(day_t new_day); 
        void set_month(month_t new_month); 
        void set_year(year_t new_year); 

        void show() const; 
}; 

// exercise: 
//  1: Write Server and Client of this header file 
