

class Base
{
	public:
		int aB;
	protected:
		int bB;
	public:
		int cB;
		void func()
		{
			std::cout << "In Base::func()" << std::endl;
			std::cout << "  aB = " << aB << "  bB = " << bB << "  cB = " << cB << std::endl;
		}
};

class Derived_1 : public Derived
{
	public:
		int aD_1;
	protected:
		int bD_1;
	public:
		int cD_1;
		void func()
		{
			std::cout << "In Derived_1::func()" << std::endl;
			std::cout << "  bB = " << bB << "  cB = " << cB << std::endl;
			std::cout << "  aD_1 = " << aD_1 << "  bD_1 = " << bD_1 << "  cD_1 = " << cD_1 << std::endl;
		}
};

class Derived_2 : protected Derived
{
	public:
		int aD_2;
	protected:
		int bD_2;
	public:
		int cD_2;
		void func()
		{
			std::cout << "In Derived_2::func()" << std::endl;
			std::cout << "  cB = " << cB << std::endl;
			std::cout << "  aD_1 = " << aD_1 << "  bD_1 = " << bD_1 "  cD_1 = " << cD_1 << std::endl;
		}
};

class Derived_3 : private Derived
{
	public:
		int aD_3;
	protected:
		int bD_3;
	public:
		int cD_3;
		void func()
		{
			std::cout << "In Derived_2::func()" << std::endl;
			std::cout << "  aD_1 = " << aD_1 << "  bD_1 = " << bD_1 "  cD_1 = " << cD_1 << std::endl;
			std::cout << "  aD_1 = " << aD_1 << "  bD_1 = " << bD_1 "  cD_1 = " << cD_1 << std::endl;
		}
};

/*
class Derived : public Base
{
	public:
		int aD;
		void f1()
		{
			std::cout << "In Derived::f1()" << std::endl;
			std::cout << "In Derived::f1()" << std::endl;
		}
	protected:
		int bD;
		void f2()
		{
			std::cout << "In Derived::f2()" << std::endl;
		}
	public:
		int cD;
		void f3()
		{
			std::cout << "In Derived::f3()" << std::endl;
		}
};
*/

