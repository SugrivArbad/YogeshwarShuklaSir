#include <iostream>

class HasPtr
{
	private:
		int n;
		int* ptr;
	
	public:
		HasPtr(int _n, int _ptr): n(_n), *ptr(new int(_ptr)){}

		HasPtr operator=(const HasPtr& other)
		{
			this->n = other.n;
			this->(*ptr) = other.(*ptr);
		}

		void get_all(const char* msg = 0)
		{
			if (msg)
				std::cout << msg << std::endl;
			std::cout << "this: " << std::hex << this << std::endl
					<< "ptr: " << std::hex << ptr << std::endl;
					<< "*ptr: " << std::dec << *ptr << std::endl
		}
};

int main(void)
{
	HasPtr hp1(10, 20);
	HasPtr hp2;
	hp2 = hp1;
	hp1.get_all("hp1:");
	hp2.get_all("hp2:");

}
