#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <assert.h> 

struct Date
{
    int day, month, year; 
}; 

struct Date* make_date(int day, int month, int year); 
struct Date* make_date(const char* p_date_string); 
struct Date* make_date(void); 

void show_date(struct Date* p_date); 
void release_date(struct Date** pp_date); 

int main(void)
{
    struct Date* p_date = NULL; 
    p_date = make_date(10, 2, 2021); 
    show_date(p_date); 
    release_date(&p_date); 
    p_date = make_date("23-4-1998"); 
    show_date(p_date); 
    release_date(&p_date); 
    p_date = make_date(); 
    show_date(p_date); 
    release_date(&p_date); 
    return (0); 
}

struct Date* make_date(int day, int month, int year)
{
    struct Date* p_date = NULL; 
    p_date = (struct Date*)malloc(sizeof(struct Date)); 
    assert(p_date); 
    p_date->day = day; 
    p_date->month = month; 
    p_date->year = year; 

    return (p_date); 
}

struct Date* make_date(const char* p_date_string)
{
    char* p_day = NULL, *p_month = NULL, *p_year = NULL; 
    char* p_str = NULL; 
    int len = 0; 
    struct Date* p_date = NULL; 

    len = strlen(p_date_string); 
    p_str = (char*)malloc(len+1); 
    assert(p_str != NULL); 
    strncpy(p_str, p_date_string, len); 
    
    p_day = strtok(p_str, "-"); 
    p_month = strtok(NULL, "-"); 
    p_year = strtok(NULL, "-"); 
    
    p_date = (struct Date*)malloc(sizeof(struct Date)); 
    assert(p_date != NULL); 

    p_date->day = atoi(p_day); 
    p_date->month = atoi(p_month); 
    p_date->year = atoi(p_year); 
    
    free(p_str); 
    p_str = NULL; 
    
    return (p_date); 
}

struct Date* make_date(void)
{
    struct Date* p_date = NULL; 
    p_date = (struct Date*)malloc(sizeof(struct Date)); 
    assert(p_date);
    p_date->day = 1; 
    p_date->month = 1; 
    p_date->year = 1970; 
    return (p_date); 
}

void show_date(struct Date* p_date)
{
    printf("%d-%d-%d\n", p_date->day, p_date->month, p_date->year); 
}

void release_date(struct Date** pp_date)
{
    free(*pp_date); 
    *pp_date = NULL; 
}

/*
// IMPLEMENT YOUR OWN VERSION OF strtok() function! 
#define NEW_STR     1 
#define OLD_STR     2 

char* my_strtok(char* my_string, char* delim)
{
    static int state; 
    static char* my_str; 
    state = OLD_STR; 
    if(state == OLD_STR && my_string != NULL)
    {
        state = NEW_STR; 
        my_str = my_string; 
        get the first token and return it 
        state = OLD_STR; 

    } 
    else if(state == OLD_STR && my_string == NULL)
    {
        get next token from my_str 
        if next token is not NULL 
            return next token 
        if its null 
            my_str = NULL; 
        return NULL; 
    }
}
*/ 

/* 
    Name mangling 

    struct Date* make_date(int, int, int); 
    struct Date* make_date(const char*); 
    struct Date* make_date(void); 

        By Abbreviating names of formal parameter type names 
        a SUFFIX string is generated 
        By Abbreviating the return type name and other qualifiers 
        such as virtual etc, a PREFIX is generated 

        PREFIX_FUNCTION_NAME_SUFFIX is a program-wide unique string 
        or it will be if functions sharing same name have 
        unambiguously distinguishable parameters! 

        At assembly level mangled names are generated and function 
        calls are directly mapped to the appropriate mangled version.  
*/ 
