#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>

typedef struct date
{
	int day;
	int month;
	int year;
}* pdate_t;

pdate_t make_date(int, int, int);
pdate_t make_date(char *);
pdate_t make_date(void);

void show_date(pdate_t);
void release_date(pdate_t *);

int main(void)
{
	pdate_t p_date=NULL;

	p_date = make_date(6, 5, 1987);
	show_date(p_date);
	release_date(&p_date);

	p_date = make_date("26-2-1998");
	show_date(p_date);
	release_date(&p_date);

	p_date = make_date();
	show_date(p_date);
	release_date(&p_date);

	printf("\n\n");

	exit(EXIT_SUCCESS);
}

pdate_t make_date(int day, int month, int year)
{
	pdate_t pDate = (pdate_t)malloc(sizeof(struct date));

	pDate->day = day;
	pDate->month = month;
	pDate->year = year;

	return pDate;
}

pdate_t make_date(char *date_string)
{
	char *day=NULL, *month=NULL, *year=NULL, *p_char=NULL;
	int length;
	pdate_t pDate = (pdate_t)malloc(sizeof(struct date));

	//length = strlen(date_string);
	//p_char = (char *)malloc(length+1);
	//strncpy(p_char, date_string, length);

	day = strtok(date_string, "-");
	month = strtok(NULL, "-");
	year = strtok(NULL, "-");

	pDate->day = atoi(day); 
	pDate->month = atoi(month);
	pDate->year = atoi(year);

	free(p_char); // making address invalid
	p_char = NULL; // making dangling pointer to NULL i.e. 0

	return pDate;
}

pdate_t make_date()
{
	pdate_t pDate = (pdate_t)malloc(sizeof(struct date));

	pDate->day = 1;
	pDate->month = 1;
	pDate->year = 1998; 	

	return pDate;
}

void show_date(pdate_t pDate)
{
	printf("\n\n Date: %d-%d-%d", pDate->day, pDate->month, pDate->year);
	return;
}

void release_date(pdate_t *ppDate)
{
	free(*ppDate);	// invalidating address
	*ppDate = NULL;	// making dangling pointer NULL
	return;
}
