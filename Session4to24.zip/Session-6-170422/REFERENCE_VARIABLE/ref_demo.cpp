/*
#include <stdio.h> 
#include <stdlib.h> 

int main(void)
{
    int n = 10; 
    int&X = n; 

    printf("Address of (n) = %p\n", &n); 
    printf("Address of (X) = %p\n", &X); 

    printf("n = %d\n", n); 
    X = 500; 
    printf("n = %d\n", n); 

    return (0); 
}
*/


#include <stdio.h>

int main(void)
{
	int n = 100;
	int &x = n;

	printf("\n Address of n : %p", &n);
	printf("\n Address of x : %p", &x);

	printf("\n value of n : %d ", n);
	x = 500;
	printf("\n value of n : %d \n\n", n);

	return 0;
}
