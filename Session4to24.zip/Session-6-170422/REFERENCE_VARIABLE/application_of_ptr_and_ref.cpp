#include <stdio.h> 
#include <stdlib.h> 

int main(void)
{
    int n = 10; 
    int* p = &n; 
    int& X = n; 

    // to write on n
    // *p = rhs; 
    // X = rhs; 
    // to read from n 
    // lhs = *p; 
    // lhs = X; 
}

void test_function()
{
    T data; // 

    f(); 
}

void f()
{
    
}