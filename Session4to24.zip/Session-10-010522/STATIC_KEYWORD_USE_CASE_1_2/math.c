#include <math.h> 

static int is_negative(double x); 
static int X; 

double cpa_sqrt(double x)
{
    if(is_negative(x))
        return NAN; 
    return sqrt(x); 
}

static int is_negative(double x)
{
    return x < 0; 
}
