#include <stdio.h> 
#include <stdlib.h> 

double cpa_sqrt(double x); 
//extern static int is_negative(double x); // not allowed 
//extern static int X; // not allowed 
// Error: more than one storage class may not be specified
// only one of extern and static can be applied to global 
// data definition statement or function 

// therefore, if a global data variable or a function is 
// qualified by keyword static then its type declaration 
// using the keyword extern cannot written in other files 
// of the same project for the reasons cited above. 

// therefore, global static variables visibity remains confined 
// to a file where it is defined 

// This protection however is a compile time protection. 
// If a function in other file manages to procure the addresses 
// of global data or function defined static in one file 
// then such indirect access via pointer cannot be stopped 


int main(void)
{
    double y = 9.0; 
    double sqrt_y; 

    sqrt_y = cpa_sqrt(y); 

	printf("\n sqrt_y: \n%.1lf \n\n", sqrt_y);

    return (0); 
}
