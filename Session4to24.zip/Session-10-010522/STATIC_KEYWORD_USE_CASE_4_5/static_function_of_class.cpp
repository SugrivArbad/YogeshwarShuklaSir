#include <stdio.h> 
#include <stdlib.h> 

class X
{
    private: 
        int m; 
        int n; 
        static int p; 

    public: 
        X() : m(0), n(0)
        {

        }

        static void test_function(void)
        {
            puts("In test_function"); 
        }
}; 

int X::p; 

void f(int, int); 

int main(void)
{

}

/* 
// ROOT OF ALL C++ EVILS 
#include <iostream> 

using namespace std; 

int main(void)
{
    cout << "HelloWorld" << num; 
}

*/ 
