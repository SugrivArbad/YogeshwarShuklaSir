#include <stdio.h> 
#include <stdlib.h> 

class X 
{
    private: 
        int p; 
        static int q; 
    public: 
        static int r; 
        X() : p(0) 
        {
        } 
        
        void addrp()
        {
            printf("addrp():addr(this):%p, addr(this->p):%p\n", this, &this->p); 
        }

        void addrq()
        {
            printf("addrq():addr(q):%p\n", &q); 
        }
}; 

int X::q = 0; 
int X::r = 10; 

int main(void) 
{
    X objX; 
    printf("main():Sizeof(objX)=%llu\n", sizeof(objX)); 

    X objX1, objX2; 
    printf("main():addr(objX1)=%p, addr(objX2)=%p\n", &objX1, &objX2); 
    objX1.addrp(); 
    objX2.addrp(); 
    objX1.addrq(); 
    objX2.addrq(); 

    objX.r = 300;   // X::r 
    X::r = 500; 


    return (0); 
}

//  class non-static data definition statement 

//  allocation time: allocation time of object which may 
//  be static or dynamic (depending how and where object is created)

//  allocation strategy: per object 

//  life-time = lifetime of object 

//  section = section of object (rodata, data, bss, stack or heap)
//  depends on how and where object is created 

//////////////////////////////////////////////////////////////////////////

//  class static data definition statement 

//  allocation time: static: created at the time of building exe 

//  allocation strategy: per class (only once) 

//  life-time = life of program (present at the start of program, 
//  destroyed at the end of program)

//  section = data or bss depending on whether it is initialized or 
//  uninitialized 

////////////////////////////////////////////////////////////////////////////

//  application 1: Shared memory area between different object of the same 
//  type! Because there is a single copy of static variable (in class)
//  between all objects of that class! 

//  application 2: If a data member is an attributed of a class rather 
//  than attribute of object then it must be made static in class! 
//  (Java Programming Languages officially attached this interpretation 
//  to a static variable in class)
//  C++ does not officially say so! But one may use static class variables 
//  in that sense ! 



