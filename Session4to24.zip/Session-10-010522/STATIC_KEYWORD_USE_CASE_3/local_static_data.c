#include <stdio.h> 
#include <stdlib.h> 

void test_function(void); 

int main(void) 
{
    int i; 
    for(i = 0; i < 5; ++i)
        test_function(); 

    return (0); 
}

void test_function(void)
{
    static int x = 0; 
    int m; 
    int k; 

    m = 0; 
    for(k = 0; k < 10; ++k)
    {
        x = x + 1; 
        m = m + 1; 
    }

    printf("test_function():values of x and m just before returning:%d, %d\n", 
            x, m); 
}

//  properties of non-static local variable 
//  allocation time: dynamic: after the function call is made 
//  allocation strategy: per call allocation 
//  lifetime = lifetime of function: created just after function call 
//  destroyed at the end of it 
//  allocation section: stack 


//  Consequence of above four points is that the local variable cannot 
//  retain the progress it made in the last call.

//  Effects on properties of local variable when it is made static 
//  effect on allocation time: static: at the time of building exe 
//  effect on allocation strategy: per definition: only once 
//  effect on lifetime: life time of local static variable = lifetime of program
//  allocation section: 
//  on windows(cl.exe): it is data or bss depending on local static variable 
//  is initialized or not 
//  on linux (GNU C compiler): a dedicated LCOMM = Local common memory area 
//  is used to store local static variable 

//  Consequence of above four points is that the local static variable can
//  retain the progress it made in the last call.

// application 1: If a function logic requires to store data across 
// its successive calls and requires that the data be visible only 
// to function then local static variable is the way 

// application 2: Common memory area for communication between 
// multiple calls to functin 

// application 3: Implement a hidden state! 