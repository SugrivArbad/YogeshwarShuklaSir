#include <stdio.h> 
#include <stdlib.h> 

class Date
{
    private: 
        int day, month, year; 

    public:
        Date(int _day, int _month, int _year)
        {
            this->day = _day; 
            this->month = _month; 
            this->year = _year;  
        }
}; 
///////////////////////////////////////////////////////////////////////
int main(void)
{
    Date d(10, 4, 2022);      // d.day, d.d.month, d.year -> Garbage 
    


    return (0); 
}


/* 
    CONSTRUCTOR CALLBACK CONTRACT: 

    PARTY TO CONTRACT 

    SERVER SIDE PROGRAMMER : Implement a class 

    CLIENT SIDE PROGAMMER : Create an object of class. 
    
    CALLBACK FUNCTION: 
        ClassName(T1 p1, ..., Tn pn)
        {

        }

    CONTRACT-
    SERVER SIDE: 
        Server should implement a class. 
        
        Server should implement initialization function 
        having the name of the class. 

        That function should not have are return type 
        annotation 

        Number of formal parameters and type of each formal
        parameter can be decided by the server programmer. 
    CLIENT SIDE: 
        Create object of class using data definition statement 
        or using new operator and provide initialization list 
        which is COMPATIBLE WITH THE FORMAL PARAMTER LIST OF A 
        CONSTRUCTOR FUNCTION. 
    COMPILER SIDE: 
        To detect creation of object of class ClassName, and 
        generate the assembly code to call constructor 
        implemented by server and send client initiliazation 
        data as an actual parameter list to the constructor 

        To detect any violation by either a client and server side 
        and emit appropriate warning, error messages and aborting 
        compilation process when needed! 
*/ 
    



