#include <stdio.h> 
#include <stdlib.h> 

class Test 
{
    public: 
        Test() 
        {
            printf("Control flow is here.\n"); 
            printf("Address of this = %p\n", this); 
        }
}; 

int main(void)
{
    Test t1; 
    Test t2; 

    printf("Address(t1):%p\n", &t1); 
    printf("Address(t2):%p\n", &t2);     
    
    return (0); 
}