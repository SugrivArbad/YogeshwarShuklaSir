#include <stdio.h> 
#include <stdlib.h> 

class Date
{
    private: 
        int day, month, year; 

    public: 
        // parameterized constructor 
        Date(int _day, int _month, int _year)
        {
            printf("Addr(this)=%p\n", this); 
            printf("_day=%d, _month=%d, _year=%d\n", _day, _month, _year); 

            this->day = _day; 
            this->month = _month; 
            this->year = _year; 
        }

        // default constructor 
        Date()
        {
            printf("In default constructor for:this=%p\n", this); 
            this->day = 1; 
            this->month = 1; 
            this->year = 1970; 
        }

        void show()
        {
            printf("%d-%d-%d\n", day, month, year); 
        }
}; 

int main(void)
{
    Date d1(11, 12, 1974); 
    Date d2; 

    printf("main:Addr(d)=%p\n", &d1); 
    printf("main:Addr(d2)=%p\n", &d2); 

    d1.show(); 
    d2.show(); 

    exit(0); 
}

