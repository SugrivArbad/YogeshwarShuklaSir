/* 
class T
{
    public: 
        T operator+(const T& other)
        {
            // this -> operator 1 
            // other -> operator 2 
            // this->mem
            // other.mem 

        }
//-----------------------------------------------
        T& operator+(const T& other)
        {
            // this -> operator 1 
            // other -> operator 2 
            // this->mem
            // other.mem 

        }
//-----------------------------------------------
        T* operator+(const T& other)
        {
            // this -> operator 1 
            // other -> operator 2 
            // this->mem
            // other.mem 

        }
}; 
*/ 

class complex1 
{
    private: 
        double re, im; 

    public: 
        complex1(double _re, double _im) : re(_re), im(_im) {} 

        complex1 operator+(const complex1& other)
        {
            double re = this->re + other.re; 
            double im = this->im + other.im; 
            complex1 rs(re, im); 
            return rs; 
        }

}; 

class complex2 
{
    private: 
        double re, im; 

    public: 
        complex2(double _re, double _im) : re(_re), im(_im) {} 

        complex2& operator+(const complex2& other)
        {
            complex2* p = new complex2(re+other.re, im+other.im); 
            return *p; 
        }

}; 

class complex3 
{
    private: 
        double re, im; 

    public: 
        complex3(double _re, double _im) : re(_re), im(_im) {} 

        complex3* operator+(const complex3& other)
        {
            return new complex3(re+other.re, im+other.im); 
        }
}; 

int main(void)
{
    complex1 c1(1.1, 2.2); 
    complex1 c2(3.3, 4.4); 
    complex1 c3 = c1 + c2; 
    ///////////////////////////////////
    complex2 c4(1.1, 2.2); 
    complex2 c5(3.3, 4.4); 
    complex2& c6 = c4 + c5; // ok: chalega 
    delete &c6; // not so intuitive 
    //////////////////////////////////
    complex3 c7(1.1, 2.2); 
    complex3 c8(3.3, 4.4); 
    complex3* c9 = c7+c8; // unintuitive 
    delete c9; // ok 
    c9 = 0; 
    ////////////////////////////////////
    complex3* p1 = new complex3(1.1, 2.2); 
    complex3* p2 = new complex3(3.3, 4.4); 

    complex3* p3 = *p1 + *p2; 
    delete p3; 
    p3 = 0; 

    delete p1; 
    p1 = 0; 

    delete p2; 
    p2 = 0; 
}

//void test(void)
//{
//    int a  = 10; 
//    int b = 20; 

//    a = a + b; 
//    a += b; 
//}

//  mov     eax, a
//  mov     ebx, b 
//  add     eax, ebx 
//  mov     a, eax 
