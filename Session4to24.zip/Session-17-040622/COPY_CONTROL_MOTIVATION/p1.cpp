#include <iostream> 

class complex 
{
    private: 
        double re, im; 
    public: 
        // parameterized cc 1 
        complex(double _re, double _im) : re(_re), im(_im) {}

        // defaulct cc 
        complex() : re(0.0), im(0.0) {}

        // operator overload member function for + 
        complex operator+(const complex& other)
        {
            complex tmp; 
            tmp.re = re + other.re; 
            tmp.im = im + other.im; 
            return (tmp);  
        }


        // operator overload member function for = 
        complex& operator=(const complex& other){
            this->re = other.re; 
            this->im = other.im; 
            return *this; 
        }


        // parameterized constructor 2 
        complex(const complex& other) : re(other.re), im(other.im)
        {
            
        }

}; 

int main(void)
{
    complex c1(1.1, 2.2);   // parameterized constructor 1 
    complex c2(3.3, 4.4);   // parameterized constructor 1 

    // c1 + c2 -> operator overload member function for + 
    // c3 can be assigned to return value of operator overload member function for + 
    //  because we have operator overload member function for = 
    complex c3 = c1 + c2;   // tmp == c1 + c2 therefore 
                            // c3 = c1 + c2 
                            // is essentially 
                            //  c3 = tmp; 
    
    // default cc 
    complex c4; // due to default constructor c4.re == 0 and c4.im == 0 

    // operator overload member function for = 
    c4 = c3; 

    // parameterized constructor 2 
    complex c5(c4);     // initialization 

    // parameterized constructor 2 
    complex c6 = c4;    // initialization 
}
