struct complex 
{
    double re; 
    double im; 
}; 

int main(void) 
{
    struct complex c1 = {1.1, 2.2}; 
    struct complex c2 = {3.3, 4.4}; 
    struct complex c3 = {0.0, 0.0}; 

    c3 = c1 + c2; // not allowed 

    c3 = c1; // now allowed 

    return 0; 
}