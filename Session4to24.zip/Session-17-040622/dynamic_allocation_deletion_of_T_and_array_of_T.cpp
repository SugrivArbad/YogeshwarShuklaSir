// Dynamic allocation and deletion of type T 
T* pT = new T(constructor data); 
delete pT; 
pT = 0; 

// Dynamic allocation and deletion of array of type T 

T* pT = new T[size]; 
delete[] pT; 
pT = 0; 