#include <cstdio>

int main()
{
	complex1 
}
