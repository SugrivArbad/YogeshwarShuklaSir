#include <iostream>

class complex2 
{
    private: 
        double re, im; 

    public: 
        complex2(double _re, double _im) : re(_re), im(_im) {} 

        complex2& operator+(const complex2& other)
        {
            //return *(new complex2(re+other.re, im+other.im)); 
            complex2 rs = complex2(re+other.re, im+other.im); 
			return rs;
        }

		double get_re()
		{
			return re;
		}

		double get_im()
		{
			return im;
		}
}; 

int main(void)
{
    complex2 c4(1.1, 2.2); 
    complex2 c5(3.3, 4.4); 
    complex2& c6 = c4 + c5;

	std::cout << "Adress of c6: "<< &c6 << std::endl;
	std::cout << c6.get_re() << " + " << c6.get_im() << "i" << std::endl;

    delete &c6;
}
