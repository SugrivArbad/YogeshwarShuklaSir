class complex1
{
	private:
		double re, im;

	public:
		complex1(double _re, double _im): re(_re), im(_im){}

		complex1 operator+(const complex1& other)
		{
			complex1 c;
			c.re = this->re + other->re;	
			c.im = this->im + other->im;	
			return c;
		}
}

class complex2
{
	private:
		double re, im;

	public:
		complex2(double _re, double _im): re(_re), im(_im){}

		complex2& operator+(const complex2& other)
		{
			complex2 c;
			c.re = this->re + other->re;	
			c.im = this->im + other->im;	
			return c;
		}
}

class complex3
{
	private:
		double re, im;

	public:
		complex3(double _re, double _im): re(_re), im(_im){}

		complex3 operator+(const complex3& other)
		{
			complex3 c;
			c.re = this->re + other->re;	
			c.im = this->im + other->im;	
			return c;
		}
}
