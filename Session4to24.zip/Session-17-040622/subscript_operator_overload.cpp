#include <iostream> 
#include <stdexcept> 
#include <cstdlib> 

class Array{
    private: 
        int* arr; 
        size_t n; 

    public: 
        Array(size_t arr_size) : n (arr_size), arr(new int[arr_size]){
        }

        void set(int index, int new_element){
            if(index < 0 || index >= n)
                throw std::out_of_range("Array index out of range"); 
            arr[index] = new_element; 
        }

        int& operator[](int index){
            if(index < 0 || index >= n)
                throw std::out_of_range("Array index out of range"); 
            return arr[index]; 
        }        

        ~Array(){
            delete[] arr; 
        }
}; 

int main(){
    Array A(10); 

    for(int i = 0; i < 10; ++i)
        A.set(i, (i+1) * 100); 

    for(int i = 0; i < 15; ++i)
        try{
            std::cout << A[i] << std::endl; 
        }catch(std::out_of_range& obj){
            std::cout << obj.what() << std::endl; 
        }

    return 0; 
}

/* 
class T
{
    public: 
        // Pointed to be noted: T& is a return value 
        // and not T. 
        // Difference will be readily understood if 
        // data type of array element is user defined 
        // rather than built in 
        T& operator[](int index)
        {

        }
}; 
*/ 

/* 
#include <string> 
#include <stdexcept>
class exception
{
    private: 
        std::string err_msg; 
    public: 
        exception(std::string& msg) : err_msg(msg) {} 
        virtual std::string& what() const 
        {
            return err_msg; 
        }
}; 

class runtime_error : public exeption
{
    public: 
        runtime_error(std::string& err_msg) : exception(err_msg) {} 

}

class out_of_range : public runtime_error
{
    public: 
        out_of_range(std::string& msg) : runtime_error(msg) {} 
}
*/ 
