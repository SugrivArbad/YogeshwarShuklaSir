#include <iostream> 
#include <cstdlib> 
#include <cassert> 

int my_add(int a, int b){
    return a+b; 
}

int my_sub(int a, int b){
    return a-b; 
}

int my_mul(int a, int b){
    return a*b; 
}

int my_div(int a, int b){
    return a/b; 
}

class CallableObject{
    private: 
        int (*pfn)(int, int); 

    public: 
        CallableObject(int(*init_fun)(int, int)) : pfn(init_fun){
        }

        void set(int(*new_pfn)(int, int)){
            pfn = new_pfn; 
        }

        int operator()(int arg1, int arg2){
            return pfn(arg1, arg2); 
        }
}; 

int main(){
    CallableObject C(my_add); 
    std::cout << C(20, 10) << std::endl; 
    C.set(my_sub); 
    std::cout << C(20, 10) << std::endl; 
    C.set(my_mul); 
    std::cout << C(20, 10) << std::endl; 
    C.set(my_div); 
    std::cout << C(20, 10) << std::endl; 

    return 0; 
} 


/* 

class Callable
{
    private: 
        float (*pfn1)(int, int, int); 
        void (*pfn2)(int*, size_t); 

    public: 
        float oprator()(int p1, int p2, int p2)
        {
            return pfn1(p1, p2, p3); 
        }

        void operator()(int* p1, size_t p2)
        {
            pfn2(p1, p2); 
        }

}; 


template <typename T1, typename retT>
class Callable
{
    private: 
        retT (*pfn)(T1 named_parameter, va_list ap); 

    public: 
        retT operator()(T1 named_param, ...)
        {
            va_start(ap, named_param); 
            return pfn(named_param, __va_args__); 
        }
}; 

float my_func1(int n1, int n2, int n3)
{

}

Callable<int, float> C(my_func_1)
*/ 
