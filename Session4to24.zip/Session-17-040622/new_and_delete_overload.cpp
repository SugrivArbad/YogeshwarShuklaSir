#include <iostream>
#include <cstdlib>
#include <cstdio> 

// new -> malloc() / calloc()/ realloc() -> mmap() GlobalAlloc() HeapAlloc() VirtualAlloc() 


class Array{
private: 
    int* p_arr; 
    size_t n; 

public: 
    Array(size_t init_size){
        puts("In Array::Array"); 
        n = init_size; 
        p_arr = new int[n];   
    }

    void* operator new(size_t size){
        std::cout << "In Array::new:size:" << size << std::endl; 
        return malloc(size);  
    }

    void operator delete(void* p){
        std::cout << "In Array::delete" << std::endl; 
        free(p); 
    }

    ~Array()
    {
        puts("In Array::~Array()"); 
        delete[] p_arr; 
    }
}; 

int main(){
    Array* pA = new Array(10); 
    delete pA; 
    return 0; 
}

/* 
mmap(NULL, ); 
GlobalAlloc

class MemoryMappedFile{
private:
    void* ptr; 
    size_t size; 
    size_t nr_of_pages; 
    const char* path_name; 
    int flags; 
    off_t off; 

public: 
    MemoryMappedFile(const char* f_path_name, size_t size_of_area, int mmap_flags, off_t starting_offset){
        // constructor 
        // mmap_flags : MAP_SHARED (COMPULSORY)
        int fd = open(f_path_name, O_RDWR); 
        this->ptr = mmap(NULL, sizeo_of_area, PROT_READ | PRTO_WRITE, mmap_flags, fd, starting_offset); 

    }

    void *operator new(size_t size){
        return malloc(size);    
    }
}; 

void* mmap(void* p, size_t size, int prot_bits, int mmap_flags, int fd, off_t offset); 


4k 

malloc(4096)

#define PAGE_SIZE 4096

main(){
    void* p = NULL; 

    p = mmap(   p,     /* NULL */ 
/*
                PAGE_SIZE, /* size */ 
/*              PROT_READ | PROT_WRITE, /* Permission */ 
/*                MAP_ANONYMOUS | MAP_PRIVATE, /* flags */ 
/*                -1, /* fd*/ 
 /*                0  /* offset */ 
 /*           ); 
 /*   assert(p); 
}


class MemoryMappedFile{
private: 
    const char* path_name; 
    size_t length; 
    int mmap_flags; 
    off_t starting_offset; 
    void *p; 
public: 
    MemoryMappedFile(const char* mapped_file_path,size_t map_length, off_t offset, int flags) : 
                    path_name(mapped_file_path), length(map_length), mmap_flags(flags), starting_offset(offset), 
                    p(NULL) 
    {
        int fd; 
        fd = open(path_name, O_RDWR); 
        assert(fd >= 0); 

        p = mmap(p, length, PROT_READ | PRTO_WRITE, mmap_flags, fd, starting_offset); 
        assert(p); 
    }

    ~MemoryMappedFile(){
        munmap(p, length); 
    }

    void* operator new(size_t size){
        return malloc(size); 
    }

    void operator delete(void* p){
        free(static_cast<MemoryMappedFile*>(p))    
    }

}; 
*/ 

/* 
HEE SAP-SHEL CHUK AHE

printf() = cout 
scanf() = cin 

new     = malloc() 
delete  = free()
*/ 
/* 
16 -> aligned 

void posix_memalign(void** pp, size_t size, size_t alignment); 

class T 
{
    private: 
        int* p; 
        size_t n; 

    public: 
        void* new(size_t size)
        {
            T* p = 0; 
            posix_memalign((void**)&p, size, 16); 
            return (p); 
        }
}; 

T objT(init_data) __attribte__(align(16)); 

T*    void*

struct T* p = malloc(sizeof(struct T)); 
*/ 

/* General pattern 

class T
{
    private: 
        // data layout 

    public: 
        T(constructor data){

        }

        ~T(){

        }

        void* operator new(size_t size){
            // overload new for T 
        }

        void operator delete(void* p){
            // overload delete for T 
        }
}; 

*/ 