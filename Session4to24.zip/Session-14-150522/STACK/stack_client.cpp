#include <stdio.h> 
#include <assert.h> 
#include "stack.h"

int main(void)
{
    stack* p_stack = 0; 
    data_t data; 

    p_stack = new stack; 
    assert(p_stack->is_empty() == true); 
    assert(p_stack->pop(&data) == STACK_EMPTY); 
    assert(p_stack->top(&data) == STACK_EMPTY); 

    for(data = 0; data < 80000; ++data)
        assert(p_stack->push((data+1) * 100)); 
    assert(p_stack->is_empty() == false); 

    assert(p_stack->top(&data) == SUCCESS); 
    printf("Top data = %d\n", data); 

    while(p_stack->is_empty() == false)
    {
        assert(p_stack->pop(&data) == SUCCESS); 
        printf("poped data = %d\n", data); 
    }

    delete p_stack; 
    p_stack = 0; 

    return 0; 
}