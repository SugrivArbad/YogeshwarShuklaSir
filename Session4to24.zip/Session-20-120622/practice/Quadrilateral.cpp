
typedef unsigned long u32;

bool satisfy_addition_of_3_side_prop(u32& s1, u32& s2, u32& s3, u32& s4)
{
	u32 big_side = s1
}

class Quadrilateral
{
	private:
		u32 side_1;
		u32 side_2;
		u32 side_3;
		u32 side_4;

	public:
		Quadrilateral(int _side_1, int _side_2, int _side_3, int _side_4)
		{
			if (satisfy_addition_of_3_side_prop(_side_1, _side_2, _side_3, _side_4))
			{
				side_1 = _side_1;
				side_2 = _side_2;
				side_3 = _side_3;
				side_4 = _side_4;
			}
		}


};
