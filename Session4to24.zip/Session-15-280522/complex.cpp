#include <stdio.h> 
#include <stdlib.h> 

class complex 
{
    private: 
        double re, im; 

    public: 
        
        complex(double _re=0.0, double _im=0.0) : re(_re), im(_im) {}
        
        void show(const char* msg = NULL)
        {
            if(msg)
                puts(msg); 
            printf("(%.3lf)+i(%.3lf)\n", re, im); 
        }

        complex add(complex& c2)
        {
            complex rs; 
            rs.re = this->re + c2.re; 
            rs.im = this->im + c2.im; 
            return rs; 
        }

}; 

int main(void)
{
    complex c1(1.1, 2.2); 
    complex c2(3.3, 4.4); 

    c1.show("c1:"); 
    c2.show("c2:"); 

    complex c3 = c1.add(c2); 
    c3.show("Addition of c1, c2"); 

    // complex c4 = c1  + c2; // wont work 
    // reason: complex.cpp(41): error C2676: binary '+': 'complex' does not define 
    //this operator or a conversion to a type acceptable to the predefined operator


    return 0; 
}
