#include <stdio.h>
#include <stdlib.h>

class Date
{
	private:
		int day;
		int month;
		int year;

	public:
		Date(int _day, int _month, int _year) : day(_day), month(_month), year(_year)
		{

		}

		void show_date(Date* pDate)
		{
			printf("\n Date by ref : %d-%d-%d", pDate->day, pDate->month, pDate->year);
		}

		void release_date(Date **ppDate)
		{
			delete *ppDate;
			ppDate = NULL:
		}
};

void accept_date_ref()
{
	int &refDate = *(new Date(10, 2, 22));
}

void accept_date_ptr()
{
	Date *pDate = new Date(30, 4, 22);
}

int main(void)
{
	
}
