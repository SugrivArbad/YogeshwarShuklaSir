#include <stdio.h> 
#include <stdlib.h> 
#include <assert.h> 
#include "list.h"

int main(void)
{
    list_t* p_list = NULL; 
    data_t data; 
    status_t status; 

    p_list = create_list(); 
    
    status = get_start(p_list, &data); 
    assert(status == LIST_EMPTY); 
    status = get_end(p_list, &data); 
    assert(status == LIST_EMPTY); 

    status = pop_start(p_list, &data); 
    assert(status == LIST_EMPTY); 
    status = pop_end(p_list, &data); 
    assert(status == LIST_EMPTY); 

    status = remove_start(p_list); 
    assert(status == LIST_EMPTY); 
    status = remove_end(p_list); 
    assert(status == LIST_EMPTY);

    if(is_list_empty(p_list) == TRUE)
        puts("List is initially empty"); 

    for(data = 0; data < 5; ++data)
    {
        status = insert_start(p_list, data); 
        assert(status == SUCCESS); 
    }

    show_list(p_list); 

    for(data = 5; data < 10; ++data)
    {
        status = insert_end(p_list, data); 
        assert(status == SUCCESS); 
    }

    show_list(p_list); 

    status = insert_after(p_list, -10, 100); 
    assert(status == LIST_DATA_NOT_FOUND); 

    status = insert_before(p_list, -10, 100); 
    assert(status == LIST_DATA_NOT_FOUND); 

    status = insert_after(p_list, 0, 100); 
    assert(status == SUCCESS); 
    show_list(p_list); 

    status = insert_before(p_list, 0, 200); 
    assert(status == SUCCESS); 
    show_list(p_list); 

    status = get_start(p_list, &data); 
    assert(status == SUCCESS); 
    printf("Start Data = %d\n", data); 
    show_list(p_list); 

    status = get_end(p_list, &data); 
    assert(status == SUCCESS); 
    printf("End Data = %d\n", data); 
    show_list(p_list);

    status = pop_start(p_list, &data); 
    assert(status == SUCCESS); 
    printf("Start Data = %d\n", data); 
    show_list(p_list);

    status = pop_end(p_list, &data); 
    assert(status == SUCCESS); 
    printf("End Data = %d\n", data); 
    show_list(p_list);

    status = remove_start(p_list); 
    assert(status == SUCCESS); 
    show_list(p_list); 

    status = remove_end(p_list); 
    assert(status == SUCCESS); 
    show_list(p_list);

    status = remove_data(p_list, -100); 
    assert(status == LIST_DATA_NOT_FOUND); 
    
    status = remove_data(p_list, 0);  
    assert(status == SUCCESS); 
    show_list(p_list);

    if(is_list_empty(p_list) == FALSE)
        puts("List is not empty now"); 

    printf("length = %d\n", get_length(p_list)); 

    destroy_list(&p_list); 
    assert(p_list == NULL); 

    return (0); 
}