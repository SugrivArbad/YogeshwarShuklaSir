#include <stdio.h> 
#include <stdlib.h> 
#include <assert.h> 

typedef struct bst_node
{
    int data; 
    int level; 
    int H; 
    struct bst_node* L, *R, *P; 
}node; 

typedef struct bst
{
    node* p_root; 
    int N; 
}bst; 

typedef struct lst_node
{
    node* p_bst_node; 
    struct lst_node* prev, *next; 
}lst_node; 

typedef lst_node queue; 

bst* create_bst(void); 
int insert_bst(bst* p_bst, int data); 
void inorder(bst* p_bst); 
void assign_heights(bst* p_bst); 
void show_levelwise(bst* p_bst); 
void destroy_bst(bst** p_bst); 

void destroy_bst_nodelevel(node* p_node); 
void assing_heights_nodelevel(node* p_node); 
void inorder_node(node* p_node); 
node* get_node(int data); 
int height(node* p_node);

lst_node* get_lst_node(node* p_bst_node); 
void generic_insert(lst_node* beg, lst_node* mid, lst_node* end); 
void generic_delete(lst_node* p_node); 
queue* create_queue(void); 
void enqueue(queue* p_queue, node* p_bst_node); 
void dequeue(queue* p_queue, node** pp_bst_node); 
int is_queue_empty(queue* p_queue); 
void destroy_queue(queue** pp_queue); 

int main(void)
{
    int arr[] = {100, 50, 150, 45, 30, 25, 20, 145, 140, 135, 175, 180, 162, 200, 110, 60, 65, 43}; 
    int i; 

    bst* p_bst = create_bst(); 
    for(i = 0; i < sizeof(arr)/sizeof(arr[0]); ++i)
        assert(insert_bst(p_bst, arr[i]));

    inorder(p_bst);
    assign_heights(p_bst);  
    show_levelwise(p_bst);  
    destroy_bst(&p_bst); 
    exit(0); 
}

bst* create_bst(void)
{
    bst* p_bst = (bst*)calloc(1, sizeof(bst)); 
    p_bst->p_root = NULL; 
    p_bst->N = 0; 
    return (p_bst); 
}

int insert_bst(bst* p_bst, int data)
{
    node* p_new_node = get_node(data); 
    node* p_run = NULL; 
    int local_level = 0; 
    if(p_bst->p_root == NULL)
    {
        p_bst->p_root = p_new_node; 
        p_new_node->P = NULL; 
        p_bst->N += 1; 
        p_new_node->level += 1; 
        return (1); 
    }

    p_run = p_bst->p_root; 
    local_level += 1; 
    while(1)
    {
        local_level += 1; 
        if(data <= p_run->data)
        {
            if(p_run->L == NULL)
            {
                p_run->L = p_new_node; 
                p_new_node->P = p_run; 
                p_new_node->level = local_level; 
                break; 
            }
            else
            {
                p_run = p_run->L; 
                continue; 
            }
        }
        else
        {
            if(p_run->R == NULL)
            {
                p_run->R = p_new_node; 
                p_new_node->P = p_run; 
                p_new_node->level= local_level; 
                break; 
            }
            else
            {
                p_run = p_run->R; 
                continue; 
            }
        }
    }

    return (1); 
}

void inorder(bst* p_bst)
{
    printf("[start]<->"); 
    inorder_node(p_bst->p_root); 
    puts("[end]"); 
}

void show_levelwise(bst* p_bst)
{
    int current_level = 1; 
    node* p_run = NULL; 
    queue* p_queue = create_queue(); 
    printf("level==%d:", current_level); 
    enqueue(p_queue, p_bst->p_root); 
    while(!is_queue_empty(p_queue))
    {
        dequeue(p_queue, &p_run); 
        if(p_run != NULL)
        {
            enqueue(p_queue, p_run->L); 
            enqueue(p_queue, p_run->R); 
            if(p_run->level > current_level)
            {
                printf("\n"); 
                current_level = p_run->level; 
                printf("level==%d:", current_level); 
                
            }    

            printf("[%d|%d]\t", p_run->data, p_run->H); 
        }
    }
    destroy_queue(&p_queue); 
}

void assign_heights(bst* p_bst)
{
    assign_heights_nodelevel(p_bst->p_root); 
}

void destroy_bst(bst** pp_bst)
{
    bst* p_bst = *pp_bst; 
    destroy_bst_nodelevel(p_bst->p_root); 
    free(p_bst); 
    *pp_bst = NULL; 
}

int height(node* p_node)
{
    if(p_node == NULL)
        return 0; 
    return max(height(p_node->L), height(p_node->R)); 
}

void inorder_node(node* p_node)
{
    if(p_node)
    {
        inorder_node(p_node->L); 
        printf("[%d]<->", p_node->data); 
        inorder_node(p_node->R); 
    }
}

void destroy_bst_nodelevel(node* p_node)
{
    if(p_node != NULL)
    {
        destroy_bst_nodelevel(p_node->L); 
        destroy_bst_nodelevel(p_node->R); 
        free(p_node); 
    }
}

int assign_heights_nodelevel(node* p_node) 
{
    int maxH; 
    if(p_node == NULL)
        return (-1); 
    p_node->H = max(assign_heights_nodelevel(p_node->L), assign_heights_nodelevel(p_node->R))+1; 
    return p_node->H; 
}

node* get_node(int data)
{
    node* p_node = (node*)calloc(1, sizeof(node)); 
    p_node->data = data; 
    p_node->L = NULL; 
    p_node->R = NULL; 
    p_node->P = NULL; 
    p_node->level = 0; 
    p_node->H = 0; 
    return (p_node); 
}

queue* create_queue(void)
{
    queue* p_queue = get_lst_node(NULL); 
    p_queue->prev = p_queue; 
    p_queue->next = p_queue; 
    return (p_queue); 
}

void enqueue(queue* p_queue, node* p_bst_node)
{
    generic_insert(p_queue->prev, get_lst_node(p_bst_node), p_queue); 
}

void dequeue(queue* p_queue, node** pp_bst_node)
{
    if(is_queue_empty(p_queue))
    {
        *pp_bst_node = NULL; 
        return; 
    }

    *pp_bst_node = p_queue->next->p_bst_node; 
    generic_delete(p_queue->next); 
}

void destroy_queue(queue** pp_queue)
{
    queue* p_queue = *pp_queue; 
    lst_node* p_run = p_queue->next; 
    lst_node* p_run_next; 
    while(p_run != p_queue)
    {
        p_run_next = p_run->next; 
        free(p_run); 
        p_run = p_run_next; 
    }
    free(p_queue); 
    *pp_queue = NULL; 
}

int is_queue_empty(queue* p_queue)
{
    return (p_queue->next == p_queue && p_queue->prev == p_queue); 
}

void generic_insert(lst_node* beg, lst_node* mid, lst_node* end)
{
    mid->next = end; 
    mid->prev = beg; 
    beg->next = mid; 
    end->prev = mid; 
}

void generic_delete(lst_node* p_node)
{
    p_node->prev->next = p_node->next; 
    p_node->next->prev = p_node->prev; 
    free(p_node); 
}

lst_node* get_lst_node(node* p_bst_node)
{
    lst_node* p_lst_node = (lst_node*)calloc(1, sizeof(lst_node)); 
    p_lst_node->p_bst_node = p_bst_node; 
    p_lst_node->prev = NULL; 
    p_lst_node->next = NULL; 
    return (p_lst_node); 
}

